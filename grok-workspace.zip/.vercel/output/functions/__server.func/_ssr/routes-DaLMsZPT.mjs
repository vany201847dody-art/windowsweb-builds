import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as create } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-DaLMsZPT.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var OS = {
	name: "AetherOS",
	version: "1.0",
	build: "10.0.26026",
	year: 2026,
	author: "Vizor",
	license: "PROPRIETARY",
	bankName: "AetherBank",
	hostname: "AETHER-PC",
	user: "User",
	storageKey: "AetherOS"
};
var ACCENTS = [
	"#0a84ff",
	"#5e5ce6",
	"#bf5af2",
	"#ff375f",
	"#ff9f0a",
	"#30d158",
	"#64d2ff",
	"#ac8e68",
	"#ffd60a",
	"#ff453a"
];
var WALLPAPERS = [
	{
		id: "summit",
		name: "Вершины",
		url: "https://images.unsplash.com/photo-1519681393784-d120267933ba?auto=format&fit=crop&w=1920&q=80"
	},
	{
		id: "aurora",
		name: "Сияние",
		url: "https://images.unsplash.com/photo-1531366936337-7c912a4589a7?auto=format&fit=crop&w=1920&q=80"
	},
	{
		id: "lake",
		name: "Озеро",
		url: "https://images.unsplash.com/photo-1501785888041-af3ef285b470?auto=format&fit=crop&w=1920&q=80"
	},
	{
		id: "dusk",
		name: "Закат",
		url: "https://images.unsplash.com/photo-1470071459604-3b5ec3a7fe05?auto=format&fit=crop&w=1920&q=80"
	},
	{
		id: "ocean",
		name: "Океан",
		url: "https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&w=1920&q=80"
	},
	{
		id: "city",
		name: "Ночной город",
		url: "https://images.unsplash.com/photo-1480714378408-67cf0d13bc1b?auto=format&fit=crop&w=1920&q=80"
	},
	{
		id: "forest",
		name: "Лес",
		url: "https://images.unsplash.com/photo-1441974231531-c6227db76b6e?auto=format&fit=crop&w=1920&q=80"
	},
	{
		id: "space",
		name: "Космос",
		url: "https://images.unsplash.com/photo-1462331947965-b7a2cfe63d3d?auto=format&fit=crop&w=1920&q=80"
	}
];
var APPS = [
	{
		id: "explorer",
		name: "Этот компьютер",
		icon: "💻",
		category: "system",
		w: 820,
		h: 540,
		minW: 520,
		minH: 360,
		desktop: true,
		description: "Файлы и диски",
		size: "18 МБ"
	},
	{
		id: "bank",
		name: "AetherBank",
		icon: "🏦",
		category: "productivity",
		w: 980,
		h: 640,
		minW: 720,
		minH: 480,
		desktop: true,
		description: "Банк и платежи",
		size: "42 МБ"
	},
	{
		id: "store",
		name: "Магазин приложений",
		icon: "🛒",
		category: "system",
		w: 900,
		h: 600,
		minW: 640,
		minH: 420,
		desktop: true,
		description: "Каталог Aether Store",
		size: "28 МБ"
	},
	{
		id: "browser",
		name: "Браузер",
		icon: "🌐",
		category: "system",
		w: 1020,
		h: 680,
		minW: 640,
		minH: 420,
		desktop: true,
		description: "Веб-обозреватель",
		size: "86 МБ"
	},
	{
		id: "camera",
		name: "Камера",
		icon: "📷",
		category: "media",
		w: 860,
		h: 560,
		minW: 560,
		minH: 400,
		desktop: true,
		description: "Фото и видео",
		size: "31 МБ"
	},
	{
		id: "clock",
		name: "Часы",
		icon: "🕐",
		category: "utilities",
		w: 720,
		h: 560,
		minW: 480,
		minH: 400,
		desktop: true,
		description: "Мировое время и таймеры",
		size: "9 МБ"
	},
	{
		id: "qr",
		name: "QR-код",
		icon: "📱",
		category: "utilities",
		w: 560,
		h: 620,
		minW: 420,
		minH: 480,
		desktop: true,
		description: "Генератор QR-кодов",
		size: "4 МБ"
	},
	{
		id: "recorder",
		name: "Диктофон",
		icon: "🎤",
		category: "media",
		w: 520,
		h: 560,
		minW: 380,
		minH: 420,
		desktop: true,
		description: "Запись голоса",
		size: "12 МБ"
	},
	{
		id: "notepad",
		name: "Блокнот",
		icon: "📝",
		category: "productivity",
		w: 640,
		h: 480,
		minW: 420,
		minH: 280,
		desktop: true,
		description: "Простой текстовый редактор",
		size: "3 МБ"
	},
	{
		id: "calculator",
		name: "Калькулятор",
		icon: "🧮",
		category: "utilities",
		w: 340,
		h: 500,
		minW: 300,
		minH: 440,
		desktop: true,
		description: "Инженерные вычисления",
		size: "2 МБ"
	},
	{
		id: "paint",
		name: "Paint",
		icon: "🎨",
		category: "media",
		w: 860,
		h: 580,
		minW: 560,
		minH: 400,
		desktop: true,
		description: "Рисование",
		size: "15 МБ"
	},
	{
		id: "music",
		name: "Музыка",
		icon: "🎵",
		category: "media",
		w: 420,
		h: 640,
		minW: 360,
		minH: 520,
		desktop: true,
		description: "Плеер Aether Music",
		size: "54 МБ"
	},
	{
		id: "photos",
		name: "Фотографии",
		icon: "🖼️",
		category: "media",
		w: 860,
		h: 580,
		minW: 560,
		minH: 400,
		desktop: true,
		description: "Галерея",
		size: "22 МБ"
	},
	{
		id: "terminal",
		name: "Терминал",
		icon: "⌨️",
		category: "system",
		w: 720,
		h: 460,
		minW: 480,
		minH: 280,
		desktop: true,
		description: "Командная строка",
		size: "6 МБ"
	},
	{
		id: "settings",
		name: "Параметры",
		icon: "⚙️",
		category: "system",
		w: 900,
		h: 600,
		minW: 640,
		minH: 420,
		desktop: true,
		description: "Настройки системы",
		size: "19 МБ"
	},
	{
		id: "weather",
		name: "Погода",
		icon: "☁️",
		category: "utilities",
		w: 640,
		h: 520,
		minW: 420,
		minH: 360,
		desktop: true,
		description: "Прогноз по Москве",
		size: "11 МБ"
	},
	{
		id: "about",
		name: "О системе",
		icon: "ℹ️",
		category: "system",
		w: 520,
		h: 560,
		minW: 400,
		minH: 420,
		desktop: true,
		description: "Сведения об AetherOS",
		size: "1 МБ"
	},
	{
		id: "notes",
		name: "Заметки",
		icon: "📒",
		category: "productivity",
		w: 780,
		h: 540,
		minW: 520,
		minH: 360,
		desktop: false,
		description: "Быстрые заметки",
		size: "8 МБ"
	},
	{
		id: "taskmgr",
		name: "Диспетчер задач",
		icon: "📊",
		category: "system",
		w: 640,
		h: 460,
		minW: 480,
		minH: 320,
		desktop: false,
		description: "Процессы и ресурсы",
		size: "7 МБ"
	},
	{
		id: "minesweeper",
		name: "Сапёр",
		icon: "💣",
		category: "games",
		w: 420,
		h: 520,
		minW: 360,
		minH: 440,
		desktop: false,
		description: "Классический сапёр 9×9",
		size: "5 МБ"
	},
	{
		id: "snake",
		name: "Змейка",
		icon: "🐍",
		category: "games",
		w: 480,
		h: 560,
		minW: 400,
		minH: 480,
		desktop: false,
		description: "Соберите яблоки",
		size: "4 МБ"
	},
	{
		id: "game2048",
		name: "2048",
		icon: "🔢",
		category: "games",
		w: 440,
		h: 560,
		minW: 380,
		minH: 480,
		desktop: false,
		description: "Сложите плитки до 2048",
		size: "3 МБ"
	},
	{
		id: "memory",
		name: "Память",
		icon: "🧠",
		category: "games",
		w: 520,
		h: 560,
		minW: 420,
		minH: 460,
		desktop: false,
		description: "Найди пары",
		size: "4 МБ"
	},
	{
		id: "tictactoe",
		name: "Крестики-нолики",
		icon: "⭕",
		category: "games",
		w: 420,
		h: 520,
		minW: 360,
		minH: 440,
		desktop: false,
		description: "Партия против ИИ",
		size: "3 МБ"
	},
	{
		id: "converter",
		name: "Конвертер",
		icon: "↔️",
		category: "utilities",
		w: 480,
		h: 420,
		minW: 360,
		minH: 320,
		desktop: false,
		description: "Единицы измерения",
		size: "2 МБ"
	},
	{
		id: "passwords",
		name: "Пароли",
		icon: "🔐",
		category: "utilities",
		w: 480,
		h: 460,
		minW: 360,
		minH: 360,
		desktop: false,
		description: "Генератор паролей",
		size: "2 МБ"
	},
	{
		id: "colors",
		name: "Пипетка",
		icon: "🌈",
		category: "utilities",
		w: 420,
		h: 480,
		minW: 340,
		minH: 360,
		desktop: false,
		description: "Палитра и HEX",
		size: "2 МБ"
	}
];
var APP_MAP = Object.fromEntries(APPS.map((a) => [a.id, a]));
var PINNED = [
	"explorer",
	"browser",
	"bank",
	"store",
	"camera",
	"settings"
];
var DEFAULT_DESKTOP = APPS.filter((a) => a.desktop).map((a) => a.id);
function uid$1(prefix = "id") {
	return `${prefix}-${Math.random().toString(36).slice(2, 9)}`;
}
function clamp(n, min, max) {
	return Math.max(min, Math.min(max, n));
}
function formatRub(n) {
	return new Intl.NumberFormat("ru-RU", {
		style: "currency",
		currency: "RUB",
		maximumFractionDigits: 0
	}).format(Math.round(n));
}
var DAYS$1 = [
	"воскресенье",
	"понедельник",
	"вторник",
	"среда",
	"четверг",
	"пятница",
	"суббота"
];
var MONTHS_GEN = [
	"января",
	"февраля",
	"марта",
	"апреля",
	"мая",
	"июня",
	"июля",
	"августа",
	"сентября",
	"октября",
	"ноября",
	"декабря"
];
var MONTHS_NOM = [
	"январь",
	"февраль",
	"март",
	"апрель",
	"май",
	"июнь",
	"июль",
	"август",
	"сентябрь",
	"октябрь",
	"ноябрь",
	"декабрь"
];
function monthNom(d) {
	return MONTHS_NOM[d.getMonth()];
}
function dateLong(d) {
	return `${DAYS$1[d.getDay()]}, ${d.getDate()} ${MONTHS_GEN[d.getMonth()]}`;
}
function dateShort(d) {
	return `${String(d.getDate()).padStart(2, "0")}.${String(d.getMonth() + 1).padStart(2, "0")}.${d.getFullYear()}`;
}
function timeStr(d, clock24, seconds) {
	const opts = {
		hour: "2-digit",
		minute: "2-digit",
		hour12: !clock24
	};
	if (seconds) opts.second = "2-digit";
	return d.toLocaleTimeString("ru-RU", opts);
}
function loadJson(key, fallback) {
	if (typeof localStorage === "undefined") return fallback;
	try {
		const raw = localStorage.getItem(key);
		if (!raw) return fallback;
		const parsed = JSON.parse(raw);
		if (Array.isArray(parsed) || typeof parsed !== "object" || parsed === null) return parsed;
		if (typeof fallback === "object" && fallback !== null && !Array.isArray(fallback)) return {
			...fallback,
			...parsed
		};
		return parsed;
	} catch {
		return fallback;
	}
}
function saveJson(key, value) {
	try {
		localStorage.setItem(key, JSON.stringify(value));
	} catch {}
}
var SETTINGS_KEY = `${OS.storageKey}_settings`;
var defaultSettings = () => ({
	theme: "dark",
	accent: "#0a84ff",
	wallpaper: WALLPAPERS[0].url,
	iconSize: "md",
	animations: true,
	volume: 70,
	brightness: 100,
	clock24: true,
	showSeconds: false,
	banners: true,
	cameraAllowed: true,
	micAllowed: true,
	wifi: true,
	bluetooth: true,
	airplane: false,
	nightlight: false,
	focus: false,
	recording: false,
	mouseSpeed: 10,
	pcName: OS.hostname,
	desktopPins: [...DEFAULT_DESKTOP],
	installed: []
});
function loadSettings() {
	const loaded = loadJson(SETTINGS_KEY, defaultSettings());
	if (!Array.isArray(loaded.desktopPins) || loaded.desktopPins.length === 0) loaded.desktopPins = [...DEFAULT_DESKTOP];
	if (!Array.isArray(loaded.installed)) loaded.installed = [];
	return loaded;
}
function applyChrome(s) {
	if (typeof document === "undefined") return;
	const root = document.documentElement;
	root.dataset.theme = s.theme;
	root.style.setProperty("--accent", s.accent);
	root.style.setProperty("--brightness", String(s.brightness / 100));
	root.classList.toggle("no-anim", !s.animations);
	root.style.colorScheme = s.theme;
}
function persistSettings(s) {
	saveJson(SETTINGS_KEY, s);
}
function taskbarH() {
	return 48;
}
function defaultPos(defW, defH, cascade) {
	const vw = typeof window === "undefined" ? 1280 : window.innerWidth;
	const vh = typeof window === "undefined" ? 800 : window.innerHeight;
	const maxW = Math.min(defW, vw - 24);
	const maxH = Math.min(defH, vh - taskbarH() - 16);
	if (vw < 800) return {
		x: 0,
		y: 0,
		w: vw,
		h: vh - taskbarH(),
		maximized: true
	};
	return {
		x: clamp(80 + cascade % 8 * 28, 8, Math.max(8, vw - maxW - 8)),
		y: clamp(48 + cascade % 8 * 24, 8, Math.max(8, vh - taskbarH() - maxH - 8)),
		w: maxW,
		h: maxH,
		maximized: false
	};
}
var useOS = create((set, get) => ({
	hydrated: false,
	phase: "boot",
	windows: [],
	zTop: 10,
	focusedId: null,
	selectedIcon: null,
	flyout: null,
	notifications: [],
	unread: 0,
	toasts: [],
	settings: defaultSettings(),
	contextMenu: null,
	snap: { zone: null },
	cascade: 0,
	now: Date.now(),
	hydrate: () => {
		const s = loadSettings();
		applyChrome(s);
		set({
			settings: s,
			hydrated: true
		});
	},
	setPhase: (phase) => set({
		phase,
		flyout: null,
		contextMenu: null
	}),
	setNow: (now) => set({ now }),
	patchSettings: (p) => {
		const settings = {
			...get().settings,
			...p
		};
		persistSettings(settings);
		applyChrome(settings);
		set({ settings });
	},
	openApp: (appId) => {
		const def = APP_MAP[appId];
		if (!def) return;
		const existing = get().windows.find((w) => w.appId === appId);
		if (existing) {
			const z = get().zTop + 1;
			set({
				windows: get().windows.map((w) => w.id === existing.id ? {
					...w,
					minimized: false,
					z
				} : w),
				zTop: z,
				focusedId: existing.id,
				flyout: null,
				contextMenu: null
			});
			return;
		}
		const pos = defaultPos(def.w, def.h, get().cascade);
		const z = get().zTop + 1;
		const win = {
			id: uid$1("win"),
			appId,
			title: def.name,
			icon: def.icon,
			x: pos.x,
			y: pos.y,
			w: pos.w,
			h: pos.h,
			z,
			minimized: false,
			maximized: pos.maximized
		};
		set({
			windows: [...get().windows, win],
			zTop: z,
			focusedId: win.id,
			cascade: get().cascade + 1,
			flyout: null,
			contextMenu: null
		});
	},
	closeWin: (id) => {
		const windows = get().windows.filter((w) => w.id !== id);
		set({
			windows,
			focusedId: get().focusedId === id ? windows.filter((w) => !w.minimized).sort((a, b) => b.z - a.z)[0]?.id ?? null : get().focusedId,
			contextMenu: null
		});
	},
	focusWin: (id) => {
		const z = get().zTop + 1;
		set({
			windows: get().windows.map((w) => w.id === id ? {
				...w,
				z,
				minimized: false
			} : w),
			zTop: z,
			focusedId: id,
			flyout: null,
			contextMenu: null
		});
	},
	minimizeWin: (id) => {
		const rest = get().windows.filter((w) => w.id !== id && !w.minimized).sort((a, b) => b.z - a.z)[0];
		set({
			windows: get().windows.map((w) => w.id === id ? {
				...w,
				minimized: true
			} : w),
			focusedId: rest?.id ?? null,
			contextMenu: null
		});
	},
	toggleMax: (id) => {
		set({
			windows: get().windows.map((w) => {
				if (w.id !== id) return w;
				if (w.maximized) {
					const p = w.prev ?? {
						x: 80,
						y: 60,
						w: 720,
						h: 480
					};
					return {
						...w,
						maximized: false,
						...p,
						prev: void 0
					};
				}
				return {
					...w,
					maximized: true,
					prev: {
						x: w.x,
						y: w.y,
						w: w.w,
						h: w.h
					}
				};
			}),
			contextMenu: null
		});
	},
	restoreWin: (id) => get().focusWin(id),
	taskbarClick: (id) => {
		const w = get().windows.find((x) => x.id === id);
		if (!w) return;
		if (w.minimized) get().focusWin(id);
		else if (get().focusedId === id) get().minimizeWin(id);
		else get().focusWin(id);
	},
	moveWin: (id, x, y) => {
		set({ windows: get().windows.map((w) => w.id === id ? {
			...w,
			x,
			y,
			maximized: false
		} : w) });
	},
	resizeWin: (id, x, y, w, h) => {
		const def = get().windows.find((x) => x.id === id);
		const app = def ? APP_MAP[def.appId] : void 0;
		const minW = app?.minW ?? 320;
		const minH = app?.minH ?? 240;
		set({ windows: get().windows.map((win) => win.id === id ? {
			...win,
			x,
			y,
			w: Math.max(minW, w),
			h: Math.max(minH, h),
			maximized: false
		} : win) });
	},
	snapWin: (id, zone) => {
		const vw = window.innerWidth;
		const vh = window.innerHeight - taskbarH();
		set({
			windows: get().windows.map((w) => {
				if (w.id !== id) return w;
				const prev = w.maximized ? w.prev : {
					x: w.x,
					y: w.y,
					w: w.w,
					h: w.h
				};
				if (zone === "left") return {
					...w,
					maximized: false,
					prev,
					x: 0,
					y: 0,
					w: Math.floor(vw / 2),
					h: vh
				};
				if (zone === "right") return {
					...w,
					maximized: false,
					prev,
					x: Math.floor(vw / 2),
					y: 0,
					w: Math.ceil(vw / 2),
					h: vh
				};
				if (zone === "max") return {
					...w,
					maximized: true,
					prev
				};
				return w;
			}),
			snap: { zone: null }
		});
	},
	setSnap: (zone) => set({ snap: { zone } }),
	selectIcon: (selectedIcon) => set({ selectedIcon }),
	setFlyout: (flyout) => set({
		flyout,
		contextMenu: null
	}),
	toggleFlyout: (f) => set({
		flyout: get().flyout === f ? null : f,
		contextMenu: null
	}),
	notify: (n) => {
		const item = {
			...n,
			id: uid$1("nt"),
			time: Date.now()
		};
		const notifications = [item, ...get().notifications].slice(0, 8);
		const banners = get().settings.banners && !get().settings.focus;
		set({
			notifications,
			unread: get().unread + 1,
			toasts: banners ? [item, ...get().toasts].slice(0, 3) : get().toasts
		});
		if (banners) setTimeout(() => {
			set({ toasts: get().toasts.filter((t) => t.id !== item.id) });
		}, 4500);
	},
	clearNotifs: () => set({
		notifications: [],
		unread: 0
	}),
	dismissToast: (id) => set({ toasts: get().toasts.filter((t) => t.id !== id) }),
	setContextMenu: (contextMenu) => set({
		contextMenu,
		flyout: contextMenu ? null : get().flyout
	}),
	closeOverlays: () => set({
		flyout: null,
		contextMenu: null
	}),
	installApp: (id) => {
		const s = get().settings;
		const installed = s.installed.includes(id) ? s.installed : [...s.installed, id];
		const desktopPins = s.desktopPins.includes(id) ? s.desktopPins : [...s.desktopPins, id];
		const settings = {
			...s,
			installed,
			desktopPins
		};
		persistSettings(settings);
		set({ settings });
	},
	pinDesktop: (id) => {
		const s = get().settings;
		if (s.desktopPins.includes(id)) return;
		const settings = {
			...s,
			desktopPins: [...s.desktopPins, id]
		};
		persistSettings(settings);
		set({ settings });
	},
	unpinDesktop: (id) => {
		const s = get().settings;
		const settings = {
			...s,
			desktopPins: s.desktopPins.filter((x) => x !== id)
		};
		persistSettings(settings);
		set({ settings });
	}
}));
function Desktop() {
	const pins = useOS((s) => s.settings.desktopPins);
	const selected = useOS((s) => s.selectedIcon);
	const selectIcon = useOS((s) => s.selectIcon);
	const openApp = useOS((s) => s.openApp);
	const setContextMenu = useOS((s) => s.setContextMenu);
	const closeOverlays = useOS((s) => s.closeOverlays);
	const size = useOS((s) => s.settings.iconSize);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "desktop",
		onPointerDown: (e) => {
			if (e.target === e.currentTarget || e.target.classList.contains("icon-grid")) {
				selectIcon(null);
				closeOverlays();
			}
		},
		onContextMenu: (e) => {
			if (e.target.closest(".desk-icon")) return;
			e.preventDefault();
			setContextMenu({
				x: e.clientX,
				y: e.clientY,
				items: [
					{
						label: "Обновить",
						action: "refresh"
					},
					{
						label: "Параметры",
						action: "personalize"
					},
					{
						sep: true,
						label: ""
					},
					{
						label: "Создать заметку",
						action: "new-note"
					},
					{
						label: "Терминал",
						action: "term"
					}
				]
			});
		},
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "icon-grid",
			children: pins.map((id) => {
				const app = APP_MAP[id];
				if (!app) return null;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					className: `desk-icon size-${size} ${selected === id ? "selected" : ""}`,
					onClick: (e) => {
						e.stopPropagation();
						selectIcon(id);
					},
					onDoubleClick: () => openApp(id),
					onContextMenu: (e) => {
						e.preventDefault();
						e.stopPropagation();
						selectIcon(id);
						setContextMenu({
							x: e.clientX,
							y: e.clientY,
							payload: id,
							items: [
								{
									label: "Открыть",
									action: "open"
								},
								{
									sep: true,
									label: ""
								},
								{
									label: "Свойства",
									action: "props"
								}
							]
						});
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "glyph",
						children: app.icon
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "label",
						children: app.name
					})]
				}, id);
			})
		})
	});
}
function Flyouts() {
	const flyout = useOS((s) => s.flyout);
	if (!flyout) return null;
	if (flyout === "start" || flyout === "search") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StartMenu, {});
	if (flyout === "calendar") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CalendarFlyout, {});
	if (flyout === "volume") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VolumeFlyout, {});
	if (flyout === "notify") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NotifyCenter, {});
	if (flyout === "power") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PowerMenu, {});
	if (flyout === "wifi") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WifiFlyout, {});
	if (flyout === "battery") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BatteryFlyout, {});
	return null;
}
function StartMenu() {
	const [q, setQ] = (0, import_react.useState)("");
	const [power, setPower] = (0, import_react.useState)(false);
	const openApp = useOS((s) => s.openApp);
	const settings = useOS((s) => s.settings);
	const query = q.trim().toLowerCase();
	const apps = APPS.filter((a) => !query || a.name.toLowerCase().includes(query) || a.id.includes(query));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flyout start-menu",
		onPointerDown: (e) => e.stopPropagation(),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				style: { position: "relative" },
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					style: {
						position: "absolute",
						left: 14,
						top: 10,
						color: "var(--fg-muted)"
					},
					children: "⌕"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: "start-search",
					placeholder: "Поиск приложений",
					value: q,
					autoFocus: true,
					onChange: (e) => setQ(e.target.value),
					onKeyDown: (e) => {
						if (e.key === "Enter" && apps[0]) openApp(apps[0].id);
					}
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				style: {
					margin: "14px 4px 4px",
					fontWeight: 600,
					fontSize: 13
				},
				children: "Приложения"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "start-grid",
				children: [apps.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					className: "start-app",
					onClick: () => openApp(a.id),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "g",
						children: a.icon
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: a.name })]
				}, a.id)), apps.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "muted",
					style: {
						gridColumn: "1 / -1",
						padding: 20
					},
					children: "Ничего не найдено"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "start-footer",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					style: {
						display: "flex",
						alignItems: "center",
						gap: 8
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						style: {
							width: 32,
							height: 32,
							borderRadius: 99,
							background: "var(--accent)",
							display: "grid",
							placeItems: "center",
							color: "#fff",
							fontWeight: 600
						},
						children: OS.user[0]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						style: { fontSize: 13 },
						children: OS.user
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "subtle",
						style: { fontSize: 11 },
						children: settings.pcName
					})] })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "os-btn",
					onClick: () => setPower((v) => !v),
					title: "Питание",
					children: "⏻"
				})]
			}),
			power && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				style: {
					position: "absolute",
					right: 16,
					bottom: 64,
					background: "var(--panel-solid)",
					border: "1px solid var(--border)",
					borderRadius: 10,
					padding: 6,
					minWidth: 200,
					boxShadow: "var(--shadow-md)"
				},
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PowerItems, {})
			})
		]
	});
}
function PowerMenu() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flyout",
		style: {
			right: 12,
			bottom: 60,
			minWidth: 220,
			padding: 8
		},
		onPointerDown: (e) => e.stopPropagation(),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PowerItems, {})
	});
}
function PowerItems() {
	const setPhase = useOS((s) => s.setPhase);
	const setFlyout = useOS((s) => s.setFlyout);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MenuRow, {
			label: "Спящий режим",
			onClick: () => {
				setFlyout(null);
				setPhase("sleep");
			}
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MenuRow, {
			label: "Завершение работы",
			onClick: () => {
				setFlyout(null);
				setPhase("shutdown");
			}
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MenuRow, {
			label: "Перезагрузка",
			onClick: () => {
				setFlyout(null);
				setPhase("restart");
			}
		})
	] });
}
function MenuRow({ label, onClick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		className: "os-btn",
		style: {
			width: "100%",
			textAlign: "left",
			marginBottom: 4
		},
		onClick,
		children: label
	});
}
function CalendarFlyout() {
	const now = useOS((s) => s.now);
	const settings = useOS((s) => s.settings);
	const [cursor, setCursor] = (0, import_react.useState)(() => /* @__PURE__ */ new Date());
	const d = new Date(now);
	const cells = (0, import_react.useMemo)(() => buildMonth(cursor), [cursor]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flyout",
		style: {
			right: 12,
			width: 320,
			padding: 18
		},
		onPointerDown: (e) => e.stopPropagation(),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				style: {
					fontSize: 36,
					fontWeight: 200,
					fontVariantNumeric: "tabular-nums"
				},
				children: timeStr(d, settings.clock24, true)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "muted",
				style: {
					marginBottom: 12,
					textTransform: "capitalize"
				},
				children: dateLong(d)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				style: {
					display: "flex",
					justifyContent: "space-between",
					alignItems: "center",
					marginBottom: 8
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "os-btn",
						onClick: () => setCursor(addMonth(cursor, -1)),
						children: "‹"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						style: {
							fontWeight: 600,
							textTransform: "capitalize"
						},
						children: [
							monthNom(cursor),
							" ",
							cursor.getFullYear()
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "os-btn",
						onClick: () => setCursor(addMonth(cursor, 1)),
						children: "›"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "cal-grid muted",
				style: {
					marginBottom: 4,
					fontSize: 11
				},
				children: [
					"Пн",
					"Вт",
					"Ср",
					"Чт",
					"Пт",
					"Сб",
					"Вс"
				].map((x) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: x }, x))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "cal-grid",
				children: cells.map((c, i) => {
					const today = c.date.getDate() === d.getDate() && c.date.getMonth() === d.getMonth() && c.date.getFullYear() === d.getFullYear();
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: `cal-cell ${c.out ? "out" : ""} ${today ? "today" : ""}`,
						children: c.date.getDate()
					}, i);
				})
			})
		]
	});
}
function buildMonth(cursor) {
	const y = cursor.getFullYear();
	const m = cursor.getMonth();
	const start = (new Date(y, m, 1).getDay() + 6) % 7;
	const days = [];
	for (let i = 0; i < 42; i++) {
		const date = new Date(y, m, i - start + 1);
		days.push({
			date,
			out: date.getMonth() !== m
		});
	}
	return days;
}
function addMonth(d, n) {
	return new Date(d.getFullYear(), d.getMonth() + n, 1);
}
function VolumeFlyout() {
	const settings = useOS((s) => s.settings);
	const patch = useOS((s) => s.patchSettings);
	const icon = settings.volume === 0 ? "🔇" : settings.volume < 40 ? "🔉" : "🔊";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flyout",
		style: {
			right: 140,
			width: 280,
			padding: 18
		},
		onPointerDown: (e) => e.stopPropagation(),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			style: {
				fontSize: 36,
				textAlign: "center"
			},
			children: icon
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			style: {
				display: "flex",
				alignItems: "center",
				gap: 10,
				marginTop: 12
			},
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				className: "os-range",
				type: "range",
				min: 0,
				max: 100,
				value: settings.volume,
				onChange: (e) => patch({ volume: Number(e.target.value) })
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				style: {
					width: 36,
					textAlign: "right",
					fontVariantNumeric: "tabular-nums"
				},
				children: [settings.volume, "%"]
			})]
		})]
	});
}
function NotifyCenter() {
	const settings = useOS((s) => s.settings);
	const patch = useOS((s) => s.patchSettings);
	const notifications = useOS((s) => s.notifications);
	const clearNotifs = useOS((s) => s.clearNotifs);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flyout",
		style: {
			right: 8,
			width: 360,
			maxWidth: "calc(100vw - 16px)",
			padding: 14
		},
		onPointerDown: (e) => e.stopPropagation(),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				style: {
					display: "flex",
					justifyContent: "space-between",
					alignItems: "center"
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Уведомления" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "os-btn",
					onClick: clearNotifs,
					children: "Очистить"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid-3",
				style: { margin: "12px 0" },
				children: [
					{
						key: "wifi",
						label: "Wi-Fi",
						icon: "📶"
					},
					{
						key: "bluetooth",
						label: "Bluetooth",
						icon: "🔷"
					},
					{
						key: "airplane",
						label: "Авиарежим",
						icon: "✈"
					},
					{
						key: "nightlight",
						label: "Ночной свет",
						icon: "🌙"
					},
					{
						key: "focus",
						label: "Фокус",
						icon: "🎯"
					},
					{
						key: "recording",
						label: "Запись экрана",
						icon: "⏺"
					}
				].map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					className: `tile ${settings[t.key] ? "on" : ""}`,
					onClick: () => {
						const next = !settings[t.key];
						const extra = { [t.key]: next };
						if (t.key === "airplane" && next) extra.wifi = false;
						if (t.key === "airplane" && !next) extra.wifi = true;
						if (t.key === "recording" && next) useOS.getState().notify({
							icon: "⏺",
							title: "Запись экрана",
							body: "Симуляция записи запущена"
						});
						patch(extra);
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t.icon }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						style: { fontSize: 11 },
						children: t.label
					})]
				}, t.key))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "muted",
				style: {
					fontSize: 12,
					marginBottom: 4
				},
				children: "Звук"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				className: "os-range",
				type: "range",
				min: 0,
				max: 100,
				value: settings.volume,
				onChange: (e) => patch({ volume: Number(e.target.value) })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "muted",
				style: {
					fontSize: 12,
					margin: "10px 0 4px"
				},
				children: "Яркость"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				className: "os-range",
				type: "range",
				min: 20,
				max: 100,
				value: settings.brightness,
				onChange: (e) => patch({ brightness: Number(e.target.value) })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				style: {
					marginTop: 12,
					maxHeight: 220,
					overflow: "auto"
				},
				children: [notifications.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "muted",
					style: {
						padding: 16,
						textAlign: "center"
					},
					children: "Нет новых уведомлений"
				}), notifications.map((n) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "card",
					style: {
						marginBottom: 8,
						display: "flex",
						gap: 8
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: n.icon }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						style: { minWidth: 0 },
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								style: { fontWeight: 600 },
								children: n.title
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "muted",
								children: n.body
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "subtle",
								style: { fontSize: 11 },
								children: new Date(n.time).toLocaleTimeString("ru-RU", {
									hour: "2-digit",
									minute: "2-digit"
								})
							})
						]
					})]
				}, n.id))]
			})
		]
	});
}
function WifiFlyout() {
	const settings = useOS((s) => s.settings);
	const patch = useOS((s) => s.patchSettings);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flyout",
		style: {
			right: 110,
			width: 280,
			padding: 14
		},
		onPointerDown: (e) => e.stopPropagation(),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				style: {
					fontWeight: 600,
					marginBottom: 8
				},
				children: "Сеть"
			}),
			[
				"Aether-5G",
				"Vizor Home",
				"CoffeeLab",
				"Aether Guest"
			].map((n, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				className: "os-btn",
				style: {
					width: "100%",
					textAlign: "left",
					marginBottom: 6,
					display: "flex",
					justifyContent: "space-between"
				},
				onClick: () => patch({
					wifi: true,
					airplane: false
				}),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["📶 ", n] }), i === 0 && settings.wifi && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "muted",
					children: "подкл."
				})]
			}, n)),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "os-btn",
				style: { width: "100%" },
				onClick: () => patch({ wifi: !settings.wifi }),
				children: settings.wifi ? "Отключить Wi-Fi" : "Включить Wi-Fi"
			})
		]
	});
}
function BatteryFlyout() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flyout",
		style: {
			right: 90,
			width: 240,
			padding: 14
		},
		onPointerDown: (e) => e.stopPropagation(),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				style: { fontWeight: 600 },
				children: "Батарея"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				style: {
					fontSize: 28,
					margin: "8px 0"
				},
				children: "87%"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "muted",
				children: "Осталось ≈ 4 ч 20 мин"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				style: {
					height: 8,
					borderRadius: 99,
					background: "var(--hover)",
					marginTop: 10,
					overflow: "hidden"
				},
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { style: {
					width: "87%",
					height: "100%",
					background: "var(--ok)"
				} })
			})
		]
	});
}
function ContextMenuLayer() {
	const menu = useOS((s) => s.contextMenu);
	const setContextMenu = useOS((s) => s.setContextMenu);
	const openApp = useOS((s) => s.openApp);
	const closeWin = useOS((s) => s.closeWin);
	const minimizeWin = useOS((s) => s.minimizeWin);
	const toggleMax = useOS((s) => s.toggleMax);
	const restoreWin = useOS((s) => s.restoreWin);
	const notify = useOS((s) => s.notify);
	if (!menu) return null;
	const x = Math.min(menu.x, window.innerWidth - 210);
	const y = Math.min(menu.y, window.innerHeight - 48 - menu.items.length * 36);
	const run = (action) => {
		const p = menu.payload ?? "";
		if (action === "open" || action === "open-app") openApp(p);
		if (action === "props") notify({
			icon: "ℹ️",
			title: "Свойства",
			body: `Объект: ${p}`
		});
		if (action === "min") minimizeWin(p);
		if (action === "max") toggleMax(p);
		if (action === "restore") restoreWin(p);
		if (action === "close") closeWin(p);
		if (action === "refresh") notify({
			icon: "💻",
			title: "Рабочий стол",
			body: "Обновлено"
		});
		if (action === "personalize") openApp("settings");
		if (action === "new-note") openApp("notepad");
		if (action === "term") openApp("terminal");
		setContextMenu(null);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "ctx",
		style: {
			left: x,
			top: y
		},
		onPointerDown: (e) => e.stopPropagation(),
		children: menu.items.map((it, i) => it.sep ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "sep" }, i) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			className: it.danger ? "danger" : "",
			disabled: it.disabled,
			onClick: () => run(it.action),
			children: it.label
		}, i))
	});
}
function Toasts() {
	const toasts = useOS((s) => s.toasts);
	const dismiss = useOS((s) => s.dismissToast);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "toast-stack",
		children: toasts.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			type: "button",
			className: "toast",
			onClick: () => dismiss(t.id),
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				style: { fontSize: 20 },
				children: t.icon
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				style: { textAlign: "left" },
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					style: { fontWeight: 600 },
					children: t.title
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "muted",
					children: t.body
				})]
			})]
		}, t.id))
	});
}
function SnapPreview() {
	const zone = useOS((s) => s.snap.zone);
	if (!zone) return null;
	const h = window.innerHeight - 48;
	const style = zone === "left" ? {
		left: 8,
		top: 8,
		width: window.innerWidth / 2 - 12,
		height: h - 16
	} : zone === "right" ? {
		left: window.innerWidth / 2 + 4,
		top: 8,
		width: window.innerWidth / 2 - 12,
		height: h - 16
	} : {
		left: 8,
		top: 8,
		width: window.innerWidth - 16,
		height: h - 16
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "snap-preview",
		style
	});
}
function OsLogo({ size = 48, glow = false, className }) {
	const g = Math.max(2, size * .08);
	const s = (size - g) / 2;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		width: size,
		height: size,
		viewBox: `0 0 ${size} ${size}`,
		className,
		"aria-hidden": true,
		style: glow ? { filter: "drop-shadow(0 0 12px color-mix(in srgb, var(--accent) 70%, transparent))" } : void 0,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "0",
				y: "0",
				width: s,
				height: s,
				rx: Math.max(2, s * .16),
				fill: "var(--accent)"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: s + g,
				y: "0",
				width: s,
				height: s,
				rx: Math.max(2, s * .16),
				fill: "var(--accent)"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "0",
				y: s + g,
				width: s,
				height: s,
				rx: Math.max(2, s * .16),
				fill: "var(--accent)"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: s + g,
				y: s + g,
				width: s,
				height: s,
				rx: Math.max(2, s * .16),
				fill: "var(--accent)"
			})
		]
	});
}
function Taskbar() {
	const windows = useOS((s) => s.windows);
	const focusedId = useOS((s) => s.focusedId);
	const flyout = useOS((s) => s.flyout);
	const unread = useOS((s) => s.unread);
	const settings = useOS((s) => s.settings);
	const now = useOS((s) => s.now);
	const toggleFlyout = useOS((s) => s.toggleFlyout);
	const openApp = useOS((s) => s.openApp);
	const taskbarClick = useOS((s) => s.taskbarClick);
	const setContextMenu = useOS((s) => s.setContextMenu);
	const [batt, setBatt] = (0, import_react.useState)(87);
	(0, import_react.useEffect)(() => {
		navigator.getBattery?.().then((b) => setBatt(Math.round(b.level * 100))).catch(() => {});
	}, []);
	const running = windows.filter((w) => !PINNED.includes(w.appId));
	const date = new Date(now);
	const onTaskCtx = (e, winId, appId) => {
		e.preventDefault();
		e.stopPropagation();
		const win = winId ? windows.find((w) => w.id === winId) : windows.find((w) => w.appId === appId);
		useOS.getState().setFlyout(null);
		setContextMenu({
			x: e.clientX,
			y: e.clientY,
			payload: win?.id ?? appId,
			items: win ? [
				{
					label: win.minimized ? "Развернуть" : "Свернуть",
					action: win.minimized ? "restore" : "min"
				},
				{
					label: "Развернуть окно",
					action: "max"
				},
				{
					sep: true,
					label: ""
				},
				{
					label: "Закрыть",
					action: "close",
					danger: true
				}
			] : [{
				label: "Открыть",
				action: "open-app"
			}]
		});
	};
	const volIcon = settings.volume === 0 ? "🔇" : settings.volume < 40 ? "🔉" : "🔊";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "taskbar",
		onContextMenu: (e) => e.preventDefault(),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "start-btn",
				"aria-label": "Пуск",
				onClick: () => toggleFlyout("start"),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OsLogo, { size: 18 })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "task-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: "search-pill",
						onClick: () => toggleFlyout("start"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "⌕" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Поиск" })]
					}),
					PINNED.map((id) => {
						const app = APP_MAP[id];
						const win = windows.find((w) => w.appId === id);
						const focused = win && focusedId === win.id && !win.minimized;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							className: `task-btn ${win ? "open" : ""} ${focused ? "focused active" : ""}`,
							title: app.name,
							onClick: () => win ? taskbarClick(win.id) : openApp(id),
							onContextMenu: (e) => onTaskCtx(e, win?.id, id),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: app.icon }), win && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "dash" })]
						}, id);
					}),
					running.map((w) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: `task-btn open ${focusedId === w.id && !w.minimized ? "focused active" : ""}`,
						title: w.title,
						onClick: () => taskbarClick(w.id),
						onContextMenu: (e) => onTaskCtx(e, w.id, w.appId),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: w.icon }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "dash" })]
					}, w.id))
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "tray",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "tray-btn",
						title: "Громкость",
						onClick: () => toggleFlyout("volume"),
						children: volIcon
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "tray-btn",
						title: "Сеть",
						onClick: () => toggleFlyout("wifi"),
						children: settings.airplane ? "✈" : settings.wifi ? "📶" : "⛔"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "tray-btn",
						title: "Батарея",
						onClick: () => toggleFlyout("battery"),
						children: "🔋"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: `tray-btn ${flyout === "calendar" ? "active" : ""}`,
						onClick: () => toggleFlyout("calendar"),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "tray-clock",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: timeStr(date, settings.clock24, settings.showSeconds) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "d",
								children: dateShort(date)
							})]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: "tray-btn",
						style: { position: "relative" },
						title: "Уведомления",
						onClick: () => {
							toggleFlyout("notify");
							useOS.setState({ unread: 0 });
						},
						children: ["🔔", unread > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "badge",
							children: unread > 9 ? "9+" : unread
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "sr-only",
				children: [batt, "%"]
			})
		]
	});
}
function AboutApp() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "app-pad",
		style: { textAlign: "center" },
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				style: {
					display: "grid",
					placeItems: "center",
					margin: "12px 0 8px"
				},
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OsLogo, {
					size: 72,
					glow: true
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				style: {
					margin: "8px 0 4px",
					fontWeight: 500
				},
				children: OS.name
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "muted",
				children: [
					"Версия ",
					OS.version,
					" · Сборка ",
					OS.build,
					" · ",
					OS.year
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "card",
				style: {
					textAlign: "left",
					marginTop: 18
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row$1, {
						k: "Автор",
						v: OS.author
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row$1, {
						k: "Лицензия",
						v: "PROPRIETARY · All Rights Reserved"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row$1, {
						k: "Copyright",
						v: `© ${OS.year} ${OS.author}`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row$1, {
						k: "Технологии",
						v: "HTML5, CSS3, Vanilla-совместимый React"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row$1, {
						k: "Приложения",
						v: String(APPS.length)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row$1, {
						k: "Разделы",
						v: "Система, Персонализация, Сеть, Банк, Игры"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				style: {
					marginTop: 28,
					fontSize: 18,
					letterSpacing: "0.08em",
					textTransform: "uppercase",
					color: "var(--fg-muted)"
				},
				children: "Все права защищены"
			})
		]
	});
}
function Row$1({ k, v }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		style: {
			display: "flex",
			justifyContent: "space-between",
			gap: 12,
			padding: "8px 0",
			borderBottom: "1px solid var(--border)"
		},
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "muted",
			children: k
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: v })]
	});
}
var KEY$2 = `${OS.storageKey}_bank`;
var GRADS = [
	"linear-gradient(135deg,#1b3a6b,#4f8cff)",
	"linear-gradient(135deg,#3b1d4a,#c084fc)",
	"linear-gradient(135deg,#143d2a,#34d399)",
	"linear-gradient(135deg,#4a2c0a,#f59e0b)"
];
function seed(name, pin) {
	const a = uid$1("c");
	const b = uid$1("c");
	const c = uid$1("c");
	return {
		user: {
			name,
			pin
		},
		cards: [
			{
				id: a,
				name: "Aether Gold",
				brand: "Visa",
				last4: "4412",
				balance: 62e3,
				blocked: false,
				pin,
				limit: 15e4,
				grad: GRADS[0]
			},
			{
				id: b,
				name: "Aether Black",
				brand: "Mastercard",
				last4: "8821",
				balance: 28e3,
				blocked: false,
				pin,
				limit: 8e4,
				grad: GRADS[1]
			},
			{
				id: c,
				name: "Зарплатная",
				brand: "МИР",
				last4: "3055",
				balance: 1e4,
				blocked: false,
				pin,
				limit: 5e4,
				grad: GRADS[2]
			}
		],
		piggy: [{
			id: uid$1("p"),
			name: "Отпуск",
			balance: 0,
			rate: 8
		}],
		deposits: [],
		credits: [],
		contacts: [{
			id: uid$1("k"),
			name: "Анна",
			account: "40817810000000000012"
		}, {
			id: uid$1("k"),
			name: "Максим",
			account: "40817810000000000077"
		}],
		autos: [],
		txs: [{
			id: uid$1("t"),
			type: "in",
			amount: 1e5,
			desc: "Стартовый баланс",
			time: Date.now() - 864e5,
			cardId: a
		}],
		fxLock: Date.now()
	};
}
var empty = {
	user: null,
	cards: [],
	piggy: [],
	deposits: [],
	credits: [],
	contacts: [],
	autos: [],
	txs: [],
	fxLock: 0
};
var TABS = [
	"Главная",
	"Карты",
	"Перевод",
	"Между своими",
	"Копилка",
	"Вклады",
	"Кредиты",
	"Валюта",
	"ЖКХ",
	"Автоплатежи",
	"Контакты",
	"История"
];
var FX = [
	{
		code: "USD",
		name: "Доллар США",
		rub: 92.4
	},
	{
		code: "EUR",
		name: "Евро",
		rub: 99.1
	},
	{
		code: "CNY",
		name: "Юань",
		rub: 12.7
	},
	{
		code: "GBP",
		name: "Фунт",
		rub: 118.2
	},
	{
		code: "JPY",
		name: "Иена",
		rub: .62
	},
	{
		code: "KZT",
		name: "Тенге",
		rub: .19
	}
];
var UTIL = [
	{
		name: "Электричество",
		amount: 1850
	},
	{
		name: "Вода",
		amount: 640
	},
	{
		name: "Газ",
		amount: 420
	},
	{
		name: "Интернет",
		amount: 790
	},
	{
		name: "Телефон",
		amount: 550
	},
	{
		name: "Домофон",
		amount: 180
	}
];
function annuity(P, annual, n) {
	const r = annual / 12 / 100;
	if (r === 0) return P / n;
	return P * r * Math.pow(1 + r, n) / (Math.pow(1 + r, n) - 1);
}
function BankApp() {
	const [bank, setBank] = (0, import_react.useState)(() => loadJson(KEY$2, empty));
	const [tab, setTab] = (0, import_react.useState)("Главная");
	const [name, setName] = (0, import_react.useState)("");
	const [pin, setPin] = (0, import_react.useState)("");
	const notify = useOS((s) => s.notify);
	const save = (next) => {
		setBank(next);
		saveJson(KEY$2, next);
	};
	const total = bank.cards.reduce((s, c) => s + c.balance, 0);
	const pay = (cardId, amount, desc, type = "out") => {
		const card = bank.cards.find((c) => c.id === cardId);
		if (!card || card.blocked) return "Карта недоступна";
		if (type === "out" && card.balance < amount) return "Недостаточно средств";
		const cards = bank.cards.map((c) => c.id === cardId ? {
			...c,
			balance: c.balance + (type === "in" ? amount : -amount)
		} : c);
		const txs = [{
			id: uid$1("t"),
			type,
			amount,
			desc,
			time: Date.now(),
			cardId
		}, ...bank.txs];
		save({
			...bank,
			cards,
			txs
		});
		return null;
	};
	if (!bank.user) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "app-pad",
		style: {
			display: "grid",
			placeItems: "center",
			height: "100%"
		},
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "card",
			style: { width: "min(360px,100%)" },
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					style: { marginTop: 0 },
					children: OS.bankName
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "muted",
					children: "Вход или регистрация. Стартовый баланс 100 000 ₽"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: "os-input",
					style: {
						width: "100%",
						marginBottom: 8
					},
					placeholder: "Имя",
					value: name,
					onChange: (e) => setName(e.target.value)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: "os-input",
					style: {
						width: "100%",
						marginBottom: 12
					},
					placeholder: "PIN · 4 цифры",
					maxLength: 4,
					value: pin,
					onChange: (e) => setPin(e.target.value.replace(/\D/g, "").slice(0, 4))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "os-btn primary",
					style: { width: "100%" },
					onClick: () => {
						if (name.trim().length < 2 || pin.length !== 4) return;
						save(seed(name.trim(), pin));
						notify({
							icon: "🏦",
							title: OS.bankName,
							body: `Добро пожаловать, ${name.trim()}`
						});
					},
					children: "Войти"
				})
			]
		})
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		style: {
			height: "100%",
			display: "flex",
			flexDirection: "column"
		},
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			style: { padding: "10px 12px 0" },
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				style: {
					display: "flex",
					justifyContent: "space-between",
					alignItems: "center"
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: OS.bankName }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "muted",
					children: bank.user.name
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "tabs",
				style: { marginTop: 8 },
				children: TABS.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: tab === t ? "on" : "",
					onClick: () => setTab(t),
					children: t
				}, t))
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "scroll",
			style: {
				padding: 12,
				flex: 1
			},
			children: [
				tab === "Главная" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Home, {
					bank,
					total
				}),
				tab === "Карты" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cards, {
					bank,
					save
				}),
				tab === "Перевод" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Transfer, {
					bank,
					pay,
					save
				}),
				tab === "Между своими" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Internal, {
					bank,
					save
				}),
				tab === "Копилка" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PiggyTab, {
					bank,
					save
				}),
				tab === "Вклады" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Deposits, {
					bank,
					save
				}),
				tab === "Кредиты" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Credits, {
					bank,
					save
				}),
				tab === "Валюта" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Fx, {
					bank,
					save
				}),
				tab === "ЖКХ" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Utils, {
					bank,
					pay
				}),
				tab === "Автоплатежи" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Autos, {
					bank,
					save,
					pay
				}),
				tab === "Контакты" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Contacts, {
					bank,
					save
				}),
				tab === "История" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(History, { bank })
			]
		})]
	});
}
function Home({ bank, total }) {
	const last = bank.txs.slice(0, 5);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "muted",
			children: "Совокупный баланс"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			style: {
				fontSize: 32,
				fontWeight: 500,
				marginBottom: 12
			},
			children: formatRub(total)
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			style: {
				display: "flex",
				gap: 10,
				overflow: "auto",
				paddingBottom: 8
			},
			children: bank.cards.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "bank-card",
				style: {
					background: c.grad,
					minWidth: 240
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					style: {
						display: "flex",
						justifyContent: "space-between"
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: c.brand }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["•• ", c.last4] })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					style: {
						opacity: .85,
						fontSize: 12
					},
					children: c.name
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					style: { fontSize: 22 },
					children: formatRub(c.balance)
				})] })]
			}, c.id))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid-3",
			style: { margin: "12px 0" },
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
					k: "Карты",
					v: String(bank.cards.length)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
					k: "Вклады",
					v: String(bank.deposits.length)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
					k: "Кредиты",
					v: String(bank.credits.length)
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "card",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				style: {
					fontWeight: 600,
					marginBottom: 8
				},
				children: "Курсы валют"
			}), FX.slice(0, 4).map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				style: {
					display: "flex",
					justifyContent: "space-between",
					padding: "4px 0"
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: f.code }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [f.rub.toFixed(2), " ₽"] })]
			}, f.code))]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "card",
			style: { marginTop: 10 },
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					style: {
						fontWeight: 600,
						marginBottom: 8
					},
					children: "Последние операции"
				}),
				last.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "muted",
					children: "Пусто"
				}),
				last.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					style: {
						display: "flex",
						justifyContent: "space-between",
						padding: "6px 0",
						borderTop: "1px solid var(--border)"
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t.desc }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						style: { color: t.type === "in" ? "var(--ok)" : "var(--fg)" },
						children: [t.type === "in" ? "+" : "−", formatRub(t.amount)]
					})]
				}, t.id))
			]
		})
	] });
}
function Stat({ k, v }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "card",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "muted",
			children: k
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			style: { fontSize: 22 },
			children: v
		})]
	});
}
function Cards({ bank, save }) {
	const [pin, setPin] = (0, import_react.useState)("");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [bank.cards.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "card",
		style: { marginBottom: 10 },
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "bank-card",
				style: {
					background: c.grad,
					marginBottom: 10
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					c.brand,
					" · ",
					c.name
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: formatRub(c.balance) })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "muted",
				children: [
					"Лимит ",
					formatRub(c.limit),
					" ",
					c.blocked ? "· заблокирована" : ""
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				style: {
					display: "flex",
					gap: 6,
					marginTop: 8,
					flexWrap: "wrap"
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "os-btn",
						onClick: () => save({
							...bank,
							cards: bank.cards.map((x) => x.id === c.id ? {
								...x,
								blocked: !x.blocked
							} : x)
						}),
						children: c.blocked ? "Разблокировать" : "Заблокировать"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "os-input",
						style: { width: 90 },
						placeholder: "лимит",
						onBlur: (e) => {
							const n = Number(e.target.value);
							if (n > 0) save({
								...bank,
								cards: bank.cards.map((x) => x.id === c.id ? {
									...x,
									limit: n
								} : x)
							});
						}
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "os-input",
						style: { width: 80 },
						placeholder: "PIN",
						maxLength: 4,
						value: pin,
						onChange: (e) => setPin(e.target.value.replace(/\D/g, ""))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "os-btn",
						onClick: () => {
							if (pin.length === 4) save({
								...bank,
								cards: bank.cards.map((x) => x.id === c.id ? {
									...x,
									pin
								} : x)
							});
						},
						children: "Сменить PIN"
					})
				]
			})
		]
	}, c.id)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		className: "os-btn primary",
		onClick: () => {
			const n = {
				id: uid$1("c"),
				name: "Новая карта",
				brand: "Visa",
				last4: String(Math.floor(1e3 + Math.random() * 9e3)),
				balance: 0,
				blocked: false,
				pin: bank.user?.pin ?? "0000",
				limit: 4e4,
				grad: GRADS[bank.cards.length % GRADS.length]
			};
			save({
				...bank,
				cards: [...bank.cards, n]
			});
		},
		children: "Выпустить карту"
	})] });
}
function Transfer({ bank, pay, save }) {
	const [from, setFrom] = (0, import_react.useState)(bank.cards[0]?.id);
	const [who, setWho] = (0, import_react.useState)("");
	const [acc, setAcc] = (0, import_react.useState)("");
	const [amount, setAmount] = (0, import_react.useState)("1000");
	const [err, setErr] = (0, import_react.useState)("");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "card",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
				className: "os-select",
				style: {
					width: "100%",
					marginBottom: 8
				},
				value: from,
				onChange: (e) => setFrom(e.target.value),
				children: bank.cards.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
					value: c.id,
					children: [
						c.name,
						" · ",
						formatRub(c.balance)
					]
				}, c.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				className: "os-input",
				style: {
					width: "100%",
					marginBottom: 8
				},
				placeholder: "Имя получателя",
				value: who,
				onChange: (e) => setWho(e.target.value)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				className: "os-input",
				style: {
					width: "100%",
					marginBottom: 8
				},
				placeholder: "Счёт",
				value: acc,
				onChange: (e) => setAcc(e.target.value)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				className: "os-input",
				style: {
					width: "100%",
					marginBottom: 8
				},
				value: amount,
				onChange: (e) => setAmount(e.target.value)
			}),
			err && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				style: {
					color: "var(--danger)",
					marginBottom: 8
				},
				children: err
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "os-btn primary",
				onClick: () => {
					const n = Number(amount);
					const e = pay(from, n, `Перевод ${who || acc || "получателю"}`);
					setErr(e ?? "");
					if (!e && who) {
						const latest = loadJson(KEY$2, bank);
						save({
							...latest,
							contacts: latest.contacts.some((c) => c.name === who) ? latest.contacts : [...latest.contacts, {
								id: uid$1("k"),
								name: who,
								account: acc || "—"
							}]
						});
					}
				},
				children: "Отправить"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "muted",
				style: { margin: "12px 0 6px" },
				children: "Быстрый перевод"
			}),
			bank.contacts.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "os-btn",
				style: {
					marginRight: 6,
					marginBottom: 6
				},
				onClick: () => {
					setWho(c.name);
					setAcc(c.account);
				},
				children: c.name
			}, c.id))
		]
	});
}
function Internal({ bank, save }) {
	const [from, setFrom] = (0, import_react.useState)(bank.cards[0]?.id);
	const [to, setTo] = (0, import_react.useState)(bank.cards[1]?.id ?? bank.piggy[0]?.id);
	const [amount, setAmount] = (0, import_react.useState)("500");
	const [err, setErr] = (0, import_react.useState)("");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "card",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "muted",
				children: "Откуда"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
				className: "os-select",
				style: {
					width: "100%",
					margin: "6px 0 10px"
				},
				value: from,
				onChange: (e) => setFrom(e.target.value),
				children: bank.cards.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
					value: c.id,
					children: c.name
				}, c.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "muted",
				children: "Куда"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
				className: "os-select",
				style: {
					width: "100%",
					margin: "6px 0 10px"
				},
				value: to,
				onChange: (e) => setTo(e.target.value),
				children: [bank.cards.filter((c) => c.id !== from).map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
					value: c.id,
					children: c.name
				}, c.id)), bank.piggy.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
					value: p.id,
					children: ["Копилка: ", p.name]
				}, p.id))]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				className: "os-input",
				value: amount,
				onChange: (e) => setAmount(e.target.value),
				style: {
					width: "100%",
					marginBottom: 8
				}
			}),
			err && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				style: { color: "var(--danger)" },
				children: err
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "os-btn primary",
				onClick: () => {
					const n = Number(amount);
					const src = bank.cards.find((c) => c.id === from);
					if (!src || src.blocked || src.balance < n) {
						setErr("Недостаточно средств");
						return;
					}
					let cards = bank.cards.map((c) => c.id === from ? {
						...c,
						balance: c.balance - n
					} : c);
					let piggy = bank.piggy;
					if (bank.cards.some((c) => c.id === to)) cards = cards.map((c) => c.id === to ? {
						...c,
						balance: c.balance + n
					} : c);
					else piggy = piggy.map((p) => p.id === to ? {
						...p,
						balance: p.balance + n
					} : p);
					save({
						...bank,
						cards,
						piggy,
						txs: [{
							id: uid$1("t"),
							type: "out",
							amount: n,
							desc: "Перевод между своими",
							time: Date.now(),
							cardId: from
						}, ...bank.txs]
					});
					setErr("");
				},
				children: "Перевести"
			})
		]
	});
}
function PiggyTab({ bank, save }) {
	const [name, setName] = (0, import_react.useState)("На цель");
	const [rate, setRate] = (0, import_react.useState)("7");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [bank.piggy.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "card",
		style: { marginBottom: 8 },
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				style: {
					display: "flex",
					justifyContent: "space-between"
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: p.name }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: formatRub(p.balance) })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "muted",
				children: [p.rate, "% годовых"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				style: {
					display: "flex",
					gap: 6,
					marginTop: 8
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "os-btn",
					onClick: () => {
						const card = bank.cards[0];
						if (!card || card.balance < 500) return;
						save({
							...bank,
							cards: bank.cards.map((c, i) => i === 0 ? {
								...c,
								balance: c.balance - 500
							} : c),
							piggy: bank.piggy.map((x) => x.id === p.id ? {
								...x,
								balance: x.balance + 500
							} : x),
							txs: [{
								id: uid$1("t"),
								type: "out",
								amount: 500,
								desc: `Копилка «${p.name}»`,
								time: Date.now(),
								cardId: card.id
							}, ...bank.txs]
						});
					},
					children: "+500 ₽"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "os-btn danger",
					onClick: () => {
						const card = bank.cards[0];
						if (!card) return;
						save({
							...bank,
							cards: bank.cards.map((c, i) => i === 0 ? {
								...c,
								balance: c.balance + p.balance
							} : c),
							piggy: bank.piggy.filter((x) => x.id !== p.id),
							txs: [{
								id: uid$1("t"),
								type: "in",
								amount: p.balance,
								desc: `Закрытие копилки «${p.name}»`,
								time: Date.now(),
								cardId: card.id
							}, ...bank.txs]
						});
					},
					children: "Закрыть"
				})]
			})
		]
	}, p.id)), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "card",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				className: "os-input",
				value: name,
				onChange: (e) => setName(e.target.value),
				style: {
					width: "100%",
					marginBottom: 8
				}
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				className: "os-input",
				value: rate,
				onChange: (e) => setRate(e.target.value),
				style: {
					width: "100%",
					marginBottom: 8
				},
				placeholder: "% годовых"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "os-btn primary",
				onClick: () => save({
					...bank,
					piggy: [...bank.piggy, {
						id: uid$1("p"),
						name,
						balance: 0,
						rate: Number(rate) || 7
					}]
				}),
				children: "Создать копилку"
			})
		]
	})] });
}
function Deposits({ bank, save }) {
	const offers = [
		{
			months: 3,
			rate: 6
		},
		{
			months: 6,
			rate: 8
		},
		{
			months: 12,
			rate: 11
		},
		{
			months: 24,
			rate: 13
		}
	];
	const [amount, setAmount] = (0, import_react.useState)("10000");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid-2",
			children: offers.map((o) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "card",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						style: { fontSize: 22 },
						children: [o.rate, "%"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "muted",
						children: [o.months, " мес."]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "os-btn primary",
						style: { marginTop: 8 },
						onClick: () => {
							const n = Number(amount);
							const card = bank.cards[0];
							if (!card || card.balance < n) return;
							save({
								...bank,
								cards: bank.cards.map((c, i) => i === 0 ? {
									...c,
									balance: c.balance - n
								} : c),
								deposits: [...bank.deposits, {
									id: uid$1("d"),
									amount: n,
									months: o.months,
									rate: o.rate,
									start: Date.now()
								}],
								txs: [{
									id: uid$1("t"),
									type: "out",
									amount: n,
									desc: `Вклад ${o.months} мес.`,
									time: Date.now(),
									cardId: card.id
								}, ...bank.txs]
							});
						},
						children: "Открыть"
					})
				]
			}, o.months))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			className: "os-input",
			value: amount,
			onChange: (e) => setAmount(e.target.value),
			style: {
				width: "100%",
				margin: "10px 0"
			}
		}),
		bank.deposits.map((d) => {
			const end = new Date(d.start);
			end.setMonth(end.getMonth() + d.months);
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "card",
				style: { marginTop: 8 },
				children: [
					formatRub(d.amount),
					" · ",
					d.rate,
					"% · до ",
					end.toLocaleDateString("ru-RU")
				]
			}, d.id);
		})
	] });
}
function Credits({ bank, save }) {
	const [P, setP] = (0, import_react.useState)("50000");
	const [n, setN] = (0, import_react.useState)("12");
	const [r, setR] = (0, import_react.useState)("14");
	const monthly = (0, import_react.useMemo)(() => annuity(Number(P) || 0, Number(r) || 0, Number(n) || 1), [
		P,
		n,
		r
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "card",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "os-input",
						value: P,
						onChange: (e) => setP(e.target.value)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "os-input",
						value: n,
						onChange: (e) => setN(e.target.value)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "os-input",
						value: r,
						onChange: (e) => setR(e.target.value)
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				style: { margin: "10px 0" },
				children: ["Платёж: ", formatRub(monthly)]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "os-btn primary",
				onClick: () => {
					const amount = Number(P);
					const months = Number(n);
					const rate = Number(r);
					const m = annuity(amount, rate, months);
					const card = bank.cards[0];
					if (!card) return;
					save({
						...bank,
						cards: bank.cards.map((c, i) => i === 0 ? {
							...c,
							balance: c.balance + amount
						} : c),
						credits: [...bank.credits, {
							id: uid$1("cr"),
							amount,
							months,
							rate,
							remaining: amount,
							monthly: m
						}],
						txs: [{
							id: uid$1("t"),
							type: "in",
							amount,
							desc: "Выдача кредита",
							time: Date.now(),
							cardId: card.id
						}, ...bank.txs]
					});
				},
				children: "Оформить"
			})
		]
	}), bank.credits.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "card",
		style: { marginTop: 8 },
		children: [
			"Остаток ",
			formatRub(c.remaining),
			" · ",
			formatRub(c.monthly),
			" / мес",
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				style: {
					marginTop: 8,
					display: "flex",
					gap: 6
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "os-btn",
					onClick: () => {
						const card = bank.cards[0];
						const payAmt = Math.min(c.monthly, c.remaining);
						if (!card || card.balance < payAmt) return;
						save({
							...bank,
							cards: bank.cards.map((x, i) => i === 0 ? {
								...x,
								balance: x.balance - payAmt
							} : x),
							credits: bank.credits.map((x) => x.id === c.id ? {
								...x,
								remaining: x.remaining - payAmt
							} : x).filter((x) => x.remaining > 1),
							txs: [{
								id: uid$1("t"),
								type: "out",
								amount: payAmt,
								desc: "Платёж по кредиту",
								time: Date.now(),
								cardId: card.id
							}, ...bank.txs]
						});
					},
					children: "Платёж"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "os-btn",
					onClick: () => {
						const card = bank.cards[0];
						if (!card || card.balance < c.remaining) return;
						save({
							...bank,
							cards: bank.cards.map((x, i) => i === 0 ? {
								...x,
								balance: x.balance - c.remaining
							} : x),
							credits: bank.credits.filter((x) => x.id !== c.id),
							txs: [{
								id: uid$1("t"),
								type: "out",
								amount: c.remaining,
								desc: "Досрочное погашение",
								time: Date.now(),
								cardId: card.id
							}, ...bank.txs]
						});
					},
					children: "Погасить досрочно"
				})]
			})
		]
	}, c.id))] });
}
function Fx({ bank, save }) {
	const [code, setCode] = (0, import_react.useState)("USD");
	const [amount, setAmount] = (0, import_react.useState)("100");
	const rate = FX.find((f) => f.code === code).rub;
	const rub = (Number(amount) || 0) * rate;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "card",
		children: [
			FX.map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				style: {
					display: "flex",
					justifyContent: "space-between",
					padding: "4px 0"
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
					f.code,
					" · ",
					f.name
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [f.rub.toFixed(2), " ₽"] })]
			}, f.code)),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid-2",
				style: { marginTop: 12 },
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
					className: "os-select",
					value: code,
					onChange: (e) => setCode(e.target.value),
					children: FX.map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: f.code }, f.code))
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: "os-input",
					value: amount,
					onChange: (e) => setAmount(e.target.value)
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				style: { margin: "10px 0" },
				children: ["= ", formatRub(rub)]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "os-btn primary",
				onClick: () => {
					const card = bank.cards[0];
					if (!card || card.balance < rub) return;
					save({
						...bank,
						cards: bank.cards.map((c, i) => i === 0 ? {
							...c,
							balance: c.balance - rub
						} : c),
						txs: [{
							id: uid$1("t"),
							type: "out",
							amount: rub,
							desc: `Покупка ${amount} ${code}`,
							time: Date.now(),
							cardId: card.id
						}, ...bank.txs]
					});
				},
				children: "Купить"
			})
		]
	});
}
function Utils({ bank, pay }) {
	const from = bank.cards[0]?.id;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid-2",
		children: UTIL.map((u) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "card",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: u.name }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "muted",
					children: formatRub(u.amount)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "os-btn primary",
					style: { marginTop: 8 },
					onClick: () => pay(from, u.amount, `ЖКХ · ${u.name}`),
					children: "Оплатить"
				})
			]
		}, u.name))
	});
}
function Autos({ bank, save, pay }) {
	const [name, setName] = (0, import_react.useState)("Интернет");
	const [amount, setAmount] = (0, import_react.useState)("790");
	const [period, setPeriod] = (0, import_react.useState)(30);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [bank.autos.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "card",
		style: {
			marginBottom: 8,
			display: "flex",
			justifyContent: "space-between"
		},
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
			a.name,
			" · ",
			formatRub(a.amount),
			" / ",
			a.period,
			" дн."
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			className: "os-btn",
			onClick: () => save({
				...bank,
				autos: bank.autos.filter((x) => x.id !== a.id)
			}),
			children: "Удалить"
		})]
	}, a.id)), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "card",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				className: "os-input",
				value: name,
				onChange: (e) => setName(e.target.value),
				style: {
					width: "100%",
					marginBottom: 8
				}
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				className: "os-input",
				value: amount,
				onChange: (e) => setAmount(e.target.value),
				style: {
					width: "100%",
					marginBottom: 8
				}
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
				className: "os-select",
				value: period,
				onChange: (e) => setPeriod(Number(e.target.value)),
				style: {
					width: "100%",
					marginBottom: 8
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: 1,
						children: "Каждый день"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: 7,
						children: "Раз в неделю"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: 30,
						children: "Раз в месяц"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "os-btn primary",
				onClick: () => {
					const cardId = bank.cards[0]?.id;
					save({
						...bank,
						autos: [...bank.autos, {
							id: uid$1("a"),
							name,
							amount: Number(amount),
							period,
							last: Date.now(),
							cardId
						}]
					});
					pay(cardId, Number(amount), `Автоплатёж · ${name}`);
				},
				children: "Создать"
			})
		]
	})] });
}
function Contacts({ bank, save }) {
	const [name, setName] = (0, import_react.useState)("");
	const [account, setAccount] = (0, import_react.useState)("");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [bank.contacts.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "card",
		style: {
			marginBottom: 8,
			display: "flex",
			justifyContent: "space-between"
		},
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: c.name }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "muted",
			children: c.account
		})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			className: "os-btn",
			onClick: () => save({
				...bank,
				contacts: bank.contacts.filter((x) => x.id !== c.id)
			}),
			children: "Удалить"
		})]
	}, c.id)), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "card",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				className: "os-input",
				placeholder: "Имя",
				value: name,
				onChange: (e) => setName(e.target.value),
				style: {
					width: "100%",
					marginBottom: 8
				}
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				className: "os-input",
				placeholder: "Счёт",
				value: account,
				onChange: (e) => setAccount(e.target.value),
				style: {
					width: "100%",
					marginBottom: 8
				}
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "os-btn primary",
				onClick: () => save({
					...bank,
					contacts: [...bank.contacts, {
						id: uid$1("k"),
						name,
						account
					}]
				}),
				children: "Добавить"
			})
		]
	})] });
}
function History({ bank }) {
	const [f, setF] = (0, import_react.useState)("all");
	const list = bank.txs.filter((t) => f === "all" || t.type === f);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		style: {
			display: "flex",
			gap: 6,
			marginBottom: 8
		},
		children: [
			"all",
			"in",
			"out"
		].map((x) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			className: `os-btn ${f === x ? "primary" : ""}`,
			onClick: () => setF(x),
			children: x === "all" ? "Все" : x === "in" ? "Поступления" : "Списания"
		}, x))
	}), list.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "card",
		style: {
			marginBottom: 6,
			display: "flex",
			justifyContent: "space-between"
		},
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: t.desc }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "subtle",
			children: new Date(t.time).toLocaleString("ru-RU")
		})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			style: { color: t.type === "in" ? "var(--ok)" : "var(--fg)" },
			children: [t.type === "in" ? "+" : "−", formatRub(t.amount)]
		})]
	}, t.id))] });
}
var HOME = "aether://home";
var ENGINES = [
	{
		name: "Яндекс",
		q: (s) => `https://yandex.ru/search/?text=${encodeURIComponent(s)}`,
		embed: (s) => `https://yandex.ru/search/?text=${encodeURIComponent(s)}`
	},
	{
		name: "Google",
		q: (s) => `https://www.google.com/search?q=${encodeURIComponent(s)}`,
		embed: (s) => `https://www.google.com/search?igu=1&q=${encodeURIComponent(s)}`
	},
	{
		name: "Bing",
		q: (s) => `https://www.bing.com/search?q=${encodeURIComponent(s)}`,
		embed: (s) => `https://www.bing.com/search?q=${encodeURIComponent(s)}`
	},
	{
		name: "DuckDuckGo",
		q: (s) => `https://duckduckgo.com/?q=${encodeURIComponent(s)}`,
		embed: (s) => `https://html.duckduckgo.com/html/?q=${encodeURIComponent(s)}`
	}
];
var LINKS = [
	{
		name: "Wikipedia",
		url: "https://ru.wikipedia.org"
	},
	{
		name: "YouTube",
		url: "https://www.youtube.com"
	},
	{
		name: "GitHub",
		url: "https://github.com"
	},
	{
		name: "MDN",
		url: "https://developer.mozilla.org"
	},
	{
		name: "Unsplash",
		url: "https://unsplash.com"
	},
	{
		name: "Habr",
		url: "https://habr.com"
	}
];
function uid() {
	return Math.random().toString(36).slice(2, 8);
}
function BrowserApp() {
	const [tabs, setTabs] = (0, import_react.useState)([{
		id: uid(),
		title: "Главная",
		url: HOME,
		embed: null
	}]);
	const [cur, setCur] = (0, import_react.useState)(0);
	const [addr, setAddr] = (0, import_react.useState)(HOME);
	const [engine, setEngine] = (0, import_react.useState)(0);
	const [hist, setHist] = (0, import_react.useState)([HOME]);
	const [hi, setHi] = (0, import_react.useState)(0);
	const tab = tabs[cur];
	const go = (url, embed, title) => {
		const next = {
			...tabs[cur],
			url,
			embed,
			title: title ?? url
		};
		const copy = [...tabs];
		copy[cur] = next;
		setTabs(copy);
		setAddr(url);
		setHist((h) => [...h.slice(0, hi + 1), url]);
		setHi((i) => i + 1);
	};
	const search = (q) => {
		const e = ENGINES[engine];
		go(e.q(q), e.embed(q), q);
	};
	const submit = (raw) => {
		const v = raw.trim();
		if (!v) return;
		if (v === HOME || v.startsWith("aether://")) {
			go(HOME, null, "Главная");
			return;
		}
		if (/^https?:\/\//i.test(v) || v.includes(".")) {
			const url = /^https?:/i.test(v) ? v : "https://" + v;
			go(url, url, url.replace(/^https?:\/\//, "").split("/")[0]);
		} else search(v);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		style: {
			height: "100%",
			display: "flex",
			flexDirection: "column",
			background: "var(--win)"
		},
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				style: {
					display: "flex",
					gap: 6,
					padding: "6px 8px",
					borderBottom: "1px solid var(--border)",
					alignItems: "center"
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "os-btn",
						disabled: hi <= 0,
						onClick: () => {
							const u = hist[hi - 1];
							setHi(hi - 1);
							setAddr(u);
						},
						children: "←"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "os-btn",
						disabled: hi >= hist.length - 1,
						onClick: () => {
							const u = hist[hi + 1];
							setHi(hi + 1);
							setAddr(u);
						},
						children: "→"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "os-btn",
						onClick: () => tab.embed && go(tab.url, tab.embed, tab.title),
						children: "↻"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "os-input",
						style: { flex: 1 },
						value: addr,
						onChange: (e) => setAddr(e.target.value),
						onKeyDown: (e) => e.key === "Enter" && submit(addr)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "os-btn",
						onClick: () => window.open(tab.embed || (addr.startsWith("http") ? addr : ENGINES[engine].q(addr)), "_blank"),
						children: "Новая вкладка"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				style: {
					display: "flex",
					gap: 4,
					padding: "4px 8px",
					borderBottom: "1px solid var(--border)"
				},
				children: [tabs.map((t, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: `os-btn ${i === cur ? "primary" : ""}`,
					onClick: () => {
						setCur(i);
						setAddr(t.url);
					},
					children: t.title.slice(0, 18)
				}, t.id)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "os-btn",
					onClick: () => {
						const t = {
							id: uid(),
							title: "Главная",
							url: HOME,
							embed: null
						};
						setTabs([...tabs, t]);
						setCur(tabs.length);
						setAddr(HOME);
					},
					children: "+"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				style: {
					flex: 1,
					minHeight: 0,
					position: "relative"
				},
				children: tab.embed ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("iframe", {
					title: tab.title,
					src: tab.embed,
					style: {
						width: "100%",
						height: "100%",
						border: 0,
						background: "#fff"
					}
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "scroll app-pad",
					style: { textAlign: "center" },
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							style: {
								display: "grid",
								placeItems: "center",
								margin: "24px 0 8px"
							},
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OsLogo, {
								size: 48,
								glow: true
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
							style: {
								fontWeight: 500,
								margin: "0 0 16px"
							},
							children: [OS.name, " Browser"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							style: {
								display: "flex",
								gap: 8,
								maxWidth: 560,
								margin: "0 auto 18px"
							},
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: "os-input",
								style: { flex: 1 },
								placeholder: "Поиск или адрес",
								value: addr === HOME ? "" : addr,
								onChange: (e) => setAddr(e.target.value),
								onKeyDown: (e) => e.key === "Enter" && submit(addr)
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "os-btn primary",
								onClick: () => submit(addr),
								children: "Найти"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							style: {
								display: "flex",
								gap: 8,
								justifyContent: "center",
								flexWrap: "wrap",
								marginBottom: 22
							},
							children: ENGINES.map((e, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: `os-btn ${engine === i ? "primary" : ""}`,
								onClick: () => setEngine(i),
								children: e.name
							}, e.name))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid-3",
							style: {
								maxWidth: 520,
								margin: "0 auto"
							},
							children: LINKS.map((l) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "card",
								onClick: () => go(l.url, l.url, l.name),
								children: l.name
							}, l.name))
						})
					]
				})
			})
		]
	});
}
function tokenize(src) {
	const out = [];
	let i = 0;
	while (i < src.length) {
		const c = src[i];
		if (c === " ") {
			i++;
			continue;
		}
		if ("+-×÷*/%()".includes(c)) {
			const op = c === "*" ? "×" : c === "/" ? "÷" : c;
			out.push(op);
			i++;
			continue;
		}
		if (c === "." || c >= "0" && c <= "9") {
			let s = "";
			while (i < src.length && (src[i] >= "0" && src[i] <= "9" || src[i] === ".")) s += src[i++];
			out.push(Number(s));
			continue;
		}
		throw new Error("bad");
	}
	return out;
}
function parse(tokens) {
	let i = 0;
	const peek = () => tokens[i];
	const eat = () => tokens[i++];
	const primary = () => {
		const t = eat();
		if (typeof t === "number") return t;
		if (t === "(") {
			const v = expr();
			eat();
			return v;
		}
		if (t === "−" || t === "-") return -primary();
		if (t === "+") return primary();
		throw new Error("bad");
	};
	const unary = () => {
		const t = peek();
		if (t === "−" || t === "-" || t === "+") {
			eat();
			return t === "+" ? unary() : -unary();
		}
		return primary();
	};
	const term = () => {
		let v = unary();
		while (peek() === "×" || peek() === "÷" || peek() === "%") {
			const op = eat();
			const r = unary();
			if (op === "×") v *= r;
			else if (op === "%") v = v * r / 100;
			else {
				if (r === 0) throw new Error("div0");
				v /= r;
			}
		}
		return v;
	};
	const expr = () => {
		let v = term();
		while (peek() === "+" || peek() === "−" || peek() === "-") {
			const op = eat();
			const r = term();
			v = op === "+" ? v + r : v - r;
		}
		return v;
	};
	return expr();
}
function evalExpr(s) {
	return parse(tokenize(s.replace(/,/g, ".")));
}
function CalculatorApp() {
	const [expr, setExpr] = (0, import_react.useState)("");
	const [prev, setPrev] = (0, import_react.useState)("");
	const [mem, setMem] = (0, import_react.useState)(null);
	const push = (k) => {
		if (k === "C") {
			setExpr("");
			setPrev("");
			return;
		}
		if (k === "←") {
			setExpr((e) => e.slice(0, -1));
			return;
		}
		if (k === "±") {
			setExpr((e) => e.startsWith("−") ? e.slice(1) : "−" + e);
			return;
		}
		if (k === "=") {
			try {
				const v = evalExpr(expr || "0");
				setPrev(expr + " =");
				setExpr(String(+v.toPrecision(12)));
				setMem(v);
			} catch {
				setPrev("Ошибка");
			}
			return;
		}
		setExpr((e) => e + k);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "app-pad",
		style: {
			display: "flex",
			flexDirection: "column",
			gap: 12
		},
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "card",
			style: {
				textAlign: "right",
				minHeight: 76
			},
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "muted",
				style: {
					fontSize: 12,
					minHeight: 16
				},
				children: prev || (mem != null ? `Ans = ${mem}` : " ")
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				style: {
					fontSize: 28,
					fontVariantNumeric: "tabular-nums",
					wordBreak: "break-all"
				},
				children: expr || "0"
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "calc-grid",
			children: [
				"C",
				"±",
				"%",
				"÷",
				"7",
				"8",
				"9",
				"×",
				"4",
				"5",
				"6",
				"−",
				"1",
				"2",
				"3",
				"+",
				"0",
				".",
				"←",
				"="
			].map((k) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: `calc-key ${k === "=" ? "eq" : "÷×−+%".includes(k) ? "op" : ""}`,
				onClick: () => push(k),
				children: k
			}, k))
		})]
	});
}
function CameraApp() {
	const videoRef = (0, import_react.useRef)(null);
	const recRef = (0, import_react.useRef)(null);
	const chunks = (0, import_react.useRef)([]);
	const [stream, setStream] = (0, import_react.useState)(null);
	const [err, setErr] = (0, import_react.useState)(null);
	const [mode, setMode] = (0, import_react.useState)("photo");
	const [facing, setFacing] = (0, import_react.useState)("user");
	const [rec, setRec] = (0, import_react.useState)(false);
	const [t, setT] = (0, import_react.useState)(0);
	const [shots, setShots] = (0, import_react.useState)([]);
	const [view, setView] = (0, import_react.useState)(null);
	const [flash, setFlash] = (0, import_react.useState)(false);
	const notify = useOS((s) => s.notify);
	const allowed = useOS((s) => s.settings.cameraAllowed);
	const start = async () => {
		setErr(null);
		if (!allowed) {
			setErr("Камера отключена в параметрах конфиденциальности.");
			return;
		}
		try {
			stream?.getTracks().forEach((t) => t.stop());
			const s = await navigator.mediaDevices.getUserMedia({
				video: {
					facingMode: facing,
					width: { ideal: 1280 },
					height: { ideal: 720 }
				},
				audio: mode === "video"
			});
			setStream(s);
			if (videoRef.current) {
				videoRef.current.srcObject = s;
				await videoRef.current.play();
			}
		} catch {
			setErr("Нет доступа к камере. Разрешите использование или подключите устройство.");
		}
	};
	(0, import_react.useEffect)(() => {
		start();
		return () => stream?.getTracks().forEach((t) => t.stop());
	}, [facing, allowed]);
	(0, import_react.useEffect)(() => {
		if (!rec) return;
		const i = setInterval(() => setT((x) => x + 1), 1e3);
		return () => clearInterval(i);
	}, [rec]);
	const snap = () => {
		const v = videoRef.current;
		if (!v) return;
		setFlash(true);
		setTimeout(() => setFlash(false), 180);
		const c = document.createElement("canvas");
		c.width = v.videoWidth || 1280;
		c.height = v.videoHeight || 720;
		const ctx = c.getContext("2d");
		if (!ctx) return;
		if (facing === "user") {
			ctx.translate(c.width, 0);
			ctx.scale(-1, 1);
		}
		ctx.drawImage(v, 0, 0);
		c.toBlob((b) => {
			if (!b) return;
			const url = URL.createObjectURL(b);
			setShots((s) => [{
				id: String(Date.now()),
				type: "photo",
				url,
				at: Date.now()
			}, ...s]);
			notify({
				icon: "📷",
				title: "Камера",
				body: "Снимок сохранён"
			});
		}, "image/jpeg", .92);
	};
	const toggleRec = () => {
		if (rec) {
			recRef.current?.stop();
			setRec(false);
			return;
		}
		if (!stream) return;
		try {
			const recd = new MediaRecorder(stream);
			chunks.current = [];
			recd.ondataavailable = (e) => e.data.size && chunks.current.push(e.data);
			recd.onstop = () => {
				const blob = new Blob(chunks.current, { type: recd.mimeType || "video/webm" });
				const url = URL.createObjectURL(blob);
				setShots((s) => [{
					id: String(Date.now()),
					type: "video",
					url,
					at: Date.now()
				}, ...s]);
			};
			recd.start();
			recRef.current = recd;
			setT(0);
			setRec(true);
		} catch {
			setErr("Запись недоступна в этом браузере.");
		}
	};
	const cur = view != null ? shots[view] : null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "viewfinder",
		children: [err ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			style: {
				height: "100%",
				display: "grid",
				placeItems: "center",
				padding: 24,
				textAlign: "center"
			},
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					style: {
						fontSize: 40,
						marginBottom: 8
					},
					children: "📷"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: err }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "os-btn primary",
					onClick: start,
					children: "Повторить"
				})
			] })
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("video", {
				ref: videoRef,
				playsInline: true,
				muted: true,
				style: {
					width: "100%",
					height: "100%",
					objectFit: "cover",
					transform: facing === "user" ? "scaleX(-1)" : void 0
				}
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "corner tl" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "corner tr" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "corner bl" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "corner br" }),
			flash && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { style: {
				position: "absolute",
				inset: 0,
				background: "#fff",
				opacity: .7
			} }),
			rec && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				style: {
					position: "absolute",
					top: 16,
					left: "50%",
					transform: "translateX(-50%)",
					color: "#ff3b30",
					fontWeight: 600
				},
				children: [
					"● REC ",
					String(Math.floor(t / 60)).padStart(2, "0"),
					":",
					String(t % 60).padStart(2, "0")
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				style: {
					position: "absolute",
					top: 12,
					right: 12,
					display: "flex",
					gap: 6
				},
				children: shots.slice(0, 4).map((s, i) => s.type === "photo" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: s.url,
					alt: "",
					onClick: () => setView(i),
					style: {
						width: 48,
						height: 48,
						objectFit: "cover",
						borderRadius: 8,
						cursor: "pointer"
					}
				}, s.id) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					onClick: () => setView(i),
					style: {
						width: 48,
						height: 48,
						borderRadius: 8,
						background: "#111",
						display: "grid",
						placeItems: "center",
						cursor: "pointer"
					},
					children: "▶"
				}, s.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				style: {
					position: "absolute",
					bottom: 16,
					left: 0,
					right: 0,
					display: "flex",
					justifyContent: "center",
					gap: 12,
					alignItems: "center"
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: `os-btn ${mode === "photo" ? "primary" : ""}`,
						onClick: () => setMode("photo"),
						children: "Фото"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: mode === "photo" ? snap : toggleRec,
						style: {
							width: 64,
							height: 64,
							borderRadius: 99,
							border: "3px solid #fff",
							background: rec ? "#ff3b30" : "#fff"
						}
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: `os-btn ${mode === "video" ? "primary" : ""}`,
						onClick: () => setMode("video"),
						children: "Видео"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "os-btn",
						onClick: () => setFacing(facing === "user" ? "environment" : "user"),
						children: "↺"
					})
				]
			})
		] }), cur && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			style: {
				position: "absolute",
				inset: 0,
				background: "#000",
				zIndex: 4,
				display: "flex",
				flexDirection: "column"
			},
			children: [cur.type === "photo" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: cur.url,
				alt: "",
				style: {
					flex: 1,
					objectFit: "contain"
				}
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("video", {
				src: cur.url,
				controls: true,
				style: { flex: 1 }
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				style: {
					display: "flex",
					gap: 8,
					justifyContent: "center",
					padding: 10
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "os-btn",
						disabled: view === 0,
						onClick: () => setView((v) => Math.max(0, (v ?? 0) - 1)),
						children: "←"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						className: "os-btn primary",
						href: cur.url,
						download: `aether-${cur.type}`,
						children: "Скачать"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "os-btn",
						disabled: view === shots.length - 1,
						onClick: () => setView((v) => Math.min(shots.length - 1, (v ?? 0) + 1)),
						children: "→"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "os-btn",
						onClick: () => setView(null),
						children: "Закрыть"
					})
				]
			})]
		})]
	});
}
var CITIES = [
	{
		name: "Москва",
		flag: "🇷🇺",
		tz: "Europe/Moscow"
	},
	{
		name: "Лондон",
		flag: "🇬🇧",
		tz: "Europe/London"
	},
	{
		name: "Нью-Йорк",
		flag: "🇺🇸",
		tz: "America/New_York"
	},
	{
		name: "Токио",
		flag: "🇯🇵",
		tz: "Asia/Tokyo"
	},
	{
		name: "Дубай",
		flag: "🇦🇪",
		tz: "Asia/Dubai"
	},
	{
		name: "Сидней",
		flag: "🇦🇺",
		tz: "Australia/Sydney"
	}
];
function ClockApp() {
	const [tab, setTab] = (0, import_react.useState)("analog");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		style: {
			height: "100%",
			display: "flex",
			flexDirection: "column"
		},
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "tabs",
			style: { padding: "8px 10px" },
			children: [
				["analog", "Аналоговые"],
				["world", "Мировые"],
				["stop", "Секундомер"],
				["timer", "Таймер"]
			].map(([k, l]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: tab === k ? "on" : "",
				onClick: () => setTab(k),
				children: l
			}, k))
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "scroll",
			style: { flex: 1 },
			children: [
				tab === "analog" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Analog, {}),
				tab === "world" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(World, {}),
				tab === "stop" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stopwatch, {}),
				tab === "timer" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Timer, {})
			]
		})]
	});
}
function Analog() {
	const now = useOS((s) => s.now);
	const d = new Date(now);
	const s = d.getSeconds() + d.getMilliseconds() / 1e3;
	const m = d.getMinutes() + s / 60;
	const h = d.getHours() % 12 + m / 60;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		style: {
			display: "grid",
			placeItems: "center",
			padding: 20
		},
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
			width: "240",
			height: "240",
			viewBox: "0 0 200 200",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "100",
					cy: "100",
					r: "96",
					fill: "var(--hover)",
					stroke: "var(--border-strong)"
				}),
				Array.from({ length: 60 }, (_, i) => {
					const a = i / 60 * Math.PI * 2 - Math.PI / 2;
					const inner = i % 5 === 0 ? 78 : 86;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
						x1: 100 + Math.cos(a) * inner,
						y1: 100 + Math.sin(a) * inner,
						x2: 100 + Math.cos(a) * 92,
						y2: 100 + Math.sin(a) * 92,
						stroke: "var(--fg)",
						strokeWidth: i % 5 === 0 ? 2 : 1,
						opacity: i % 5 === 0 ? .9 : .4
					}, i);
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
					x1: "100",
					y1: "100",
					x2: 100 + Math.cos(h / 12 * Math.PI * 2 - Math.PI / 2) * 48,
					y2: 100 + Math.sin(h / 12 * Math.PI * 2 - Math.PI / 2) * 48,
					stroke: "var(--fg)",
					strokeWidth: "4",
					strokeLinecap: "round"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
					x1: "100",
					y1: "100",
					x2: 100 + Math.cos(m / 60 * Math.PI * 2 - Math.PI / 2) * 68,
					y2: 100 + Math.sin(m / 60 * Math.PI * 2 - Math.PI / 2) * 68,
					stroke: "var(--fg)",
					strokeWidth: "3",
					strokeLinecap: "round"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
					x1: "100",
					y1: "100",
					x2: 100 + Math.cos(s / 60 * Math.PI * 2 - Math.PI / 2) * 78,
					y2: 100 + Math.sin(s / 60 * Math.PI * 2 - Math.PI / 2) * 78,
					stroke: "var(--accent)",
					strokeWidth: "1.5"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "100",
					cy: "100",
					r: "4",
					fill: "var(--accent)"
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			style: {
				fontSize: 28,
				marginTop: 8,
				fontVariantNumeric: "tabular-nums"
			},
			children: d.toLocaleTimeString("ru-RU")
		})]
	});
}
function World() {
	const now = useOS((s) => s.now);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "app-pad grid-2",
		children: CITIES.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "card",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				c.flag,
				" ",
				c.name
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				style: {
					fontSize: 22,
					fontVariantNumeric: "tabular-nums"
				},
				children: new Date(now).toLocaleTimeString("ru-RU", {
					timeZone: c.tz,
					hour: "2-digit",
					minute: "2-digit",
					second: "2-digit"
				})
			})]
		}, c.name))
	});
}
function Stopwatch() {
	const [run, setRun] = (0, import_react.useState)(false);
	const [t, setT] = (0, import_react.useState)(0);
	const [laps, setLaps] = (0, import_react.useState)([]);
	(0, import_react.useEffect)(() => {
		if (!run) return;
		let raf = 0;
		let last = performance.now();
		const loop = (now) => {
			const dt = Math.min(.1, (now - last) / 1e3);
			last = now;
			setT((x) => x + dt);
			raf = requestAnimationFrame(loop);
		};
		raf = requestAnimationFrame(loop);
		return () => cancelAnimationFrame(raf);
	}, [run]);
	const fmt = (x) => {
		const m = Math.floor(x / 60);
		const s = x % 60;
		return `${String(m).padStart(2, "0")}:${s.toFixed(2).padStart(5, "0")}`;
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "app-pad",
		style: { textAlign: "center" },
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				style: {
					fontSize: 48,
					fontVariantNumeric: "tabular-nums"
				},
				children: fmt(t)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				style: {
					display: "flex",
					gap: 8,
					justifyContent: "center",
					margin: 12
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "os-btn primary",
						onClick: () => setRun(!run),
						children: run ? "Пауза" : "Старт"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "os-btn",
						onClick: () => setLaps([t, ...laps]),
						children: "Круг"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "os-btn",
						onClick: () => {
							setRun(false);
							setT(0);
							setLaps([]);
						},
						children: "Сброс"
					})
				]
			}),
			laps.map((l, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "muted",
				children: [
					"#",
					laps.length - i,
					" · ",
					fmt(l)
				]
			}, i))
		]
	});
}
function Timer() {
	const [h, setH] = (0, import_react.useState)(0);
	const [m, setM] = (0, import_react.useState)(5);
	const [s, setS] = (0, import_react.useState)(0);
	const [left, setLeft] = (0, import_react.useState)(null);
	const [run, setRun] = (0, import_react.useState)(false);
	const notify = useOS((s) => s.notify);
	const total = h * 3600 + m * 60 + s;
	(0, import_react.useEffect)(() => {
		if (!run || left == null) return;
		let raf = 0;
		let last = performance.now();
		const loop = (now) => {
			const dt = Math.min(.1, (now - last) / 1e3);
			last = now;
			setLeft((x) => {
				if (x == null) return x;
				const n = x - dt;
				if (n <= 0) {
					setRun(false);
					notify({
						icon: "🕐",
						title: "Таймер",
						body: "Время вышло"
					});
					return 0;
				}
				return n;
			});
			raf = requestAnimationFrame(loop);
		};
		raf = requestAnimationFrame(loop);
		return () => cancelAnimationFrame(raf);
	}, [
		run,
		left,
		notify
	]);
	const show = left ?? total;
	const hh = Math.floor(show / 3600);
	const mm = Math.floor(show % 3600 / 60);
	const ss = Math.floor(show % 60);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "app-pad",
		style: { textAlign: "center" },
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				style: {
					fontSize: 42,
					fontVariantNumeric: "tabular-nums"
				},
				children: [
					String(hh).padStart(2, "0"),
					":",
					String(mm).padStart(2, "0"),
					":",
					String(ss).padStart(2, "0")
				]
			}),
			left == null && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				style: {
					display: "flex",
					gap: 8,
					justifyContent: "center",
					marginTop: 12
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Num, {
						v: h,
						set: setH,
						max: 23
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Num, {
						v: m,
						set: setM,
						max: 59
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Num, {
						v: s,
						set: setS,
						max: 59
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				style: {
					display: "flex",
					gap: 8,
					justifyContent: "center",
					marginTop: 12
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "os-btn primary",
					onClick: () => {
						if (left == null) setLeft(total);
						setRun((r) => !r);
					},
					children: run ? "Пауза" : "Старт"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "os-btn",
					onClick: () => {
						setRun(false);
						setLeft(null);
					},
					children: "Сброс"
				})]
			})
		]
	});
}
function Num({ v, set, max }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		className: "os-input",
		style: {
			width: 64,
			textAlign: "center"
		},
		value: v,
		onChange: (e) => set(Math.max(0, Math.min(max, Number(e.target.value) || 0)))
	});
}
var TREE = {
	"Этот компьютер": [
		{
			name: "Документы",
			icon: "📁",
			kind: "folder"
		},
		{
			name: "Загрузки",
			icon: "📁",
			kind: "folder"
		},
		{
			name: "Изображения",
			icon: "📁",
			kind: "folder"
		},
		{
			name: "Музыка",
			icon: "📁",
			kind: "folder"
		},
		{
			name: "Видео",
			icon: "📁",
			kind: "folder"
		},
		{
			name: "Диск C:",
			icon: "💽",
			kind: "folder",
			size: "128 ГБ"
		},
		{
			name: "Диск D:",
			icon: "💽",
			kind: "folder",
			size: "512 ГБ"
		}
	],
	Документы: [
		{
			name: "Резюме.docx",
			icon: "📄",
			kind: "file",
			size: "48 КБ"
		},
		{
			name: "Заметки.txt",
			icon: "📝",
			kind: "file",
			size: "3 КБ"
		},
		{
			name: "Бюджет.xlsx",
			icon: "📊",
			kind: "file",
			size: "112 КБ"
		},
		{
			name: "Проекты",
			icon: "📁",
			kind: "folder"
		}
	],
	Проекты: [{
		name: "AetherOS",
		icon: "📁",
		kind: "folder"
	}, {
		name: "readme.md",
		icon: "📄",
		kind: "file",
		size: "2 КБ"
	}],
	AetherOS: [{
		name: "index.html",
		icon: "🌐",
		kind: "file",
		size: "1.2 МБ"
	}],
	Загрузки: [
		{
			name: "setup.exe",
			icon: "📦",
			kind: "file",
			size: "84 МБ"
		},
		{
			name: "photo.jpg",
			icon: "🖼️",
			kind: "file",
			size: "3.1 МБ"
		},
		{
			name: "archive.zip",
			icon: "🗜️",
			kind: "file",
			size: "22 МБ"
		}
	],
	Изображения: [
		{
			name: "Отпуск",
			icon: "📁",
			kind: "folder"
		},
		{
			name: "wallpaper.jpg",
			icon: "🖼️",
			kind: "file",
			size: "4.8 МБ"
		},
		{
			name: "logo.png",
			icon: "🖼️",
			kind: "file",
			size: "220 КБ"
		}
	],
	Отпуск: [{
		name: "море.jpg",
		icon: "🖼️",
		kind: "file",
		size: "2.4 МБ"
	}, {
		name: "горы.jpg",
		icon: "🖼️",
		kind: "file",
		size: "3.0 МБ"
	}],
	Музыка: [{
		name: "Night Drive.mp3",
		icon: "🎵",
		kind: "file",
		size: "8 МБ"
	}, {
		name: "Glass Rain.mp3",
		icon: "🎵",
		kind: "file",
		size: "7 МБ"
	}],
	Видео: [{
		name: "demo.mp4",
		icon: "🎬",
		kind: "file",
		size: "120 МБ"
	}],
	"Диск C:": [
		{
			name: "Windows",
			icon: "📁",
			kind: "folder"
		},
		{
			name: "Users",
			icon: "📁",
			kind: "folder"
		},
		{
			name: "Program Files",
			icon: "📁",
			kind: "folder"
		}
	],
	Windows: [{
		name: "System32",
		icon: "📁",
		kind: "folder"
	}],
	Users: [{
		name: "User",
		icon: "📁",
		kind: "folder"
	}],
	User: [{
		name: "Desktop",
		icon: "📁",
		kind: "folder"
	}, {
		name: "Documents",
		icon: "📁",
		kind: "folder"
	}],
	"Program Files": [{
		name: "Aether",
		icon: "📁",
		kind: "folder"
	}],
	"Диск D:": [{
		name: "Games",
		icon: "📁",
		kind: "folder"
	}, {
		name: "Backup",
		icon: "📁",
		kind: "folder"
	}],
	Games: [{
		name: "Snake",
		icon: "📁",
		kind: "folder"
	}],
	Backup: [{
		name: "2026-01.zip",
		icon: "🗜️",
		kind: "file",
		size: "2 ГБ"
	}]
};
var SIDE = [
	"Этот компьютер",
	"Документы",
	"Загрузки",
	"Изображения",
	"Музыка",
	"Видео",
	"Диск C:",
	"Диск D:"
];
function ExplorerApp() {
	const [path, setPath] = (0, import_react.useState)(["Этот компьютер"]);
	const cur = path[path.length - 1];
	const items = TREE[cur] ?? [];
	const crumbs = (0, import_react.useMemo)(() => path, [path]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "finder",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "side-nav",
			children: SIDE.map((n) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: cur === n ? "active" : "",
				onClick: () => setPath([n]),
				children: n
			}, n))
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			style: {
				display: "flex",
				flexDirection: "column",
				minWidth: 0
			},
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				style: {
					display: "flex",
					gap: 8,
					alignItems: "center",
					padding: "8px 12px",
					borderBottom: "1px solid var(--border)"
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "os-btn",
					disabled: path.length < 2,
					onClick: () => setPath(path.slice(0, -1)),
					children: "←"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "muted",
					style: {
						display: "flex",
						gap: 6,
						flexWrap: "wrap"
					},
					children: crumbs.map((c, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "os-btn",
						style: {
							height: 26,
							padding: "0 8px"
						},
						onClick: () => setPath(path.slice(0, i + 1)),
						children: c
					}, c + i))
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "file-grid scroll",
				children: [items.map((it) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					className: "file-cell",
					onDoubleClick: () => {
						if (it.kind === "folder") setPath([...path, it.name]);
					},
					onClick: () => {
						if (it.kind === "folder") setPath([...path, it.name]);
					},
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							style: { fontSize: 28 },
							children: it.icon
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: it.name }),
						it.size && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "subtle",
							children: it.size
						})
					]
				}, it.name)), items.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "muted",
					children: "Папка пуста"
				})]
			})]
		})]
	});
}
function Minesweeper() {
	const W = 9;
	const H = 9;
	const M = 10;
	const [board, setBoard] = (0, import_react.useState)(() => makeBoard(W, H, M));
	const [dead, setDead] = (0, import_react.useState)(false);
	const [won, setWon] = (0, import_react.useState)(false);
	const notify = useOS((s) => s.notify);
	const uncover = (i) => {
		if (dead || won) return;
		setBoard((b) => {
			const next = b.map((c) => ({ ...c }));
			if (next[i].flag || next[i].open) return b;
			if (next[i].mine) {
				next.forEach((c) => {
					if (c.mine) c.open = true;
				});
				setDead(true);
				notify({
					icon: "💣",
					title: "Сапёр",
					body: "Поражение"
				});
				return next;
			}
			const stack = [i];
			while (stack.length) {
				const cur = stack.pop();
				if (next[cur].open || next[cur].flag) continue;
				next[cur].open = true;
				if (next[cur].n === 0) {
					for (const nb of neigh(cur, W, H)) if (!next[nb].open && !next[nb].mine) stack.push(nb);
				}
			}
			if (next.every((c) => c.mine || c.open)) {
				setWon(true);
				notify({
					icon: "🏆",
					title: "Сапёр",
					body: "Победа"
				});
			}
			return next;
		});
	};
	const flag = (i, e) => {
		e.preventDefault();
		if (dead || won) return;
		setBoard((b) => b.map((c, idx) => idx === i && !c.open ? {
			...c,
			flag: !c.flag
		} : c));
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "app-pad",
		style: { textAlign: "center" },
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "muted",
				style: { marginBottom: 8 },
				children: dead ? "Поражение" : won ? "Победа" : `Мины: ${M - board.filter((c) => c.flag).length}`
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				style: {
					display: "grid",
					gridTemplateColumns: `repeat(${W}, 32px)`,
					gap: 2,
					justifyContent: "center"
				},
				children: board.map((c, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => uncover(i),
					onContextMenu: (e) => flag(i, e),
					style: {
						width: 32,
						height: 32,
						border: "none",
						borderRadius: 4,
						background: c.open ? "var(--hover)" : "var(--panel-solid)",
						color: c.mine && c.open ? "var(--danger)" : "var(--fg)",
						fontWeight: 700
					},
					children: c.open ? c.mine ? "💣" : c.n || "" : c.flag ? "⚑" : ""
				}, i))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "os-btn",
				style: { marginTop: 12 },
				onClick: () => {
					setBoard(makeBoard(W, H, M));
					setDead(false);
					setWon(false);
				},
				children: "Заново"
			})
		]
	});
}
function neigh(i, W, H) {
	const x = i % W;
	const y = Math.floor(i / W);
	const out = [];
	for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) {
		if (!dx && !dy) continue;
		const nx = x + dx;
		const ny = y + dy;
		if (nx >= 0 && nx < W && ny >= 0 && ny < H) out.push(ny * W + nx);
	}
	return out;
}
function makeBoard(W, H, M) {
	const cells = Array.from({ length: W * H }, () => ({
		mine: false,
		open: false,
		flag: false,
		n: 0
	}));
	let m = 0;
	while (m < M) {
		const i = Math.floor(Math.random() * cells.length);
		if (cells[i].mine) continue;
		cells[i].mine = true;
		m++;
	}
	cells.forEach((c, i) => {
		c.n = neigh(i, W, H).filter((n) => cells[n].mine).length;
	});
	return cells;
}
function SnakeGame() {
	const canvas = (0, import_react.useRef)(null);
	const [score, setScore] = (0, import_react.useState)(0);
	const [over, setOver] = (0, import_react.useState)(false);
	const dir = (0, import_react.useRef)({
		x: 1,
		y: 0
	});
	const next = (0, import_react.useRef)({
		x: 1,
		y: 0
	});
	const [runId, setRunId] = (0, import_react.useState)(0);
	(0, import_react.useEffect)(() => {
		const c = canvas.current;
		if (!c) return;
		const ctx = c.getContext("2d");
		const N = 20;
		const cell = 18;
		c.width = 360;
		c.height = 360;
		let snake = [
			{
				x: 8,
				y: 10
			},
			{
				x: 7,
				y: 10
			},
			{
				x: 6,
				y: 10
			}
		];
		let food = {
			x: 14,
			y: 10
		};
		let acc = 0;
		let last = performance.now();
		let dead = false;
		let sc = 0;
		const onKey = (e) => {
			const k = e.key;
			const d = next.current;
			if (k === "ArrowUp" && dir.current.y !== 1) {
				d.x = 0;
				d.y = -1;
			}
			if (k === "ArrowDown" && dir.current.y !== -1) {
				d.x = 0;
				d.y = 1;
			}
			if (k === "ArrowLeft" && dir.current.x !== 1) {
				d.x = -1;
				d.y = 0;
			}
			if (k === "ArrowRight" && dir.current.x !== -1) {
				d.x = 1;
				d.y = 0;
			}
			if (k.startsWith("Arrow")) e.preventDefault();
		};
		window.addEventListener("keydown", onKey);
		let raf = 0;
		const loop = (now) => {
			const dt = Math.min(.1, (now - last) / 1e3);
			last = now;
			acc += dt;
			const step = .12;
			while (acc >= step && !dead) {
				acc -= step;
				dir.current = { ...next.current };
				const h = {
					x: snake[0].x + dir.current.x,
					y: snake[0].y + dir.current.y
				};
				if (h.x < 0 || h.y < 0 || h.x >= N || h.y >= N || snake.some((s) => s.x === h.x && s.y === h.y)) {
					dead = true;
					setOver(true);
					break;
				}
				snake = [h, ...snake];
				if (h.x === food.x && h.y === food.y) {
					sc += 10;
					setScore(sc);
					food = {
						x: Math.floor(Math.random() * N),
						y: Math.floor(Math.random() * N)
					};
				} else snake.pop();
			}
			ctx.fillStyle = "#111";
			ctx.fillRect(0, 0, c.width, c.height);
			ctx.fillStyle = "#30d158";
			snake.forEach((s, idx) => {
				ctx.globalAlpha = idx === 0 ? 1 : .75;
				ctx.fillRect(s.x * cell + 1, s.y * cell + 1, 16, 16);
			});
			ctx.globalAlpha = 1;
			ctx.fillStyle = "#ff453a";
			ctx.fillRect(food.x * cell + 2, food.y * cell + 2, 14, 14);
			raf = requestAnimationFrame(loop);
		};
		raf = requestAnimationFrame(loop);
		return () => {
			cancelAnimationFrame(raf);
			window.removeEventListener("keydown", onKey);
		};
	}, [runId]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "app-pad",
		style: { textAlign: "center" },
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "muted",
				children: [
					"Счёт ",
					score,
					" ",
					over ? "· конец. Нажмите «Заново»" : ""
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("canvas", {
				ref: canvas,
				style: {
					margin: "8px auto",
					display: "block",
					borderRadius: 8
				}
			}),
			over && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "os-btn primary",
				onClick: () => {
					setScore(0);
					setOver(false);
					dir.current = {
						x: 1,
						y: 0
					};
					next.current = {
						x: 1,
						y: 0
					};
					setRunId((n) => n + 1);
				},
				children: "Заново"
			})
		]
	});
}
function Game2048() {
	const empty = () => Array.from({ length: 16 }, () => 0);
	const spawn = (b) => {
		const free = b.map((v, i) => v === 0 ? i : -1).filter((i) => i >= 0);
		if (!free.length) return b;
		const i = free[Math.floor(Math.random() * free.length)];
		const n = [...b];
		n[i] = Math.random() < .9 ? 2 : 4;
		return n;
	};
	const [board, setBoard] = (0, import_react.useState)(() => spawn(spawn(empty())));
	const [score, setScore] = (0, import_react.useState)(0);
	const slide = (row) => {
		const a = row.filter((x) => x);
		let s = 0;
		for (let i = 0; i < a.length - 1; i++) if (a[i] === a[i + 1]) {
			a[i] *= 2;
			s += a[i];
			a[i + 1] = 0;
		}
		const m = a.filter((x) => x);
		while (m.length < 4) m.push(0);
		return {
			row: m,
			s
		};
	};
	const move = (dir) => {
		const g = [...board];
		let add = 0;
		const get = (r, c) => g[r * 4 + c];
		const set = (r, c, v) => g[r * 4 + c] = v;
		if (dir === "L" || dir === "R") for (let r = 0; r < 4; r++) {
			let row = [
				0,
				1,
				2,
				3
			].map((c) => get(r, c));
			if (dir === "R") row.reverse();
			const res = slide(row);
			if (dir === "R") res.row.reverse();
			res.row.forEach((v, c) => set(r, c, v));
			add += res.s;
		}
		else for (let c = 0; c < 4; c++) {
			let col = [
				0,
				1,
				2,
				3
			].map((r) => get(r, c));
			if (dir === "D") col.reverse();
			const res = slide(col);
			if (dir === "D") res.row.reverse();
			res.row.forEach((v, r) => set(r, c, v));
			add += res.s;
		}
		if (g.some((v, i) => v !== board[i])) {
			setBoard(spawn(g));
			setScore((s) => s + add);
		}
	};
	(0, import_react.useEffect)(() => {
		const onKey = (e) => {
			const map = {
				ArrowLeft: "L",
				ArrowRight: "R",
				ArrowUp: "U",
				ArrowDown: "D"
			};
			if (map[e.key]) {
				e.preventDefault();
				move(map[e.key]);
			}
		};
		window.addEventListener("keydown", onKey);
		return () => window.removeEventListener("keydown", onKey);
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "app-pad",
		style: { textAlign: "center" },
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				style: { marginBottom: 8 },
				children: ["Счёт ", score]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				style: {
					display: "grid",
					gridTemplateColumns: "repeat(4, 70px)",
					gap: 6,
					justifyContent: "center"
				},
				children: board.map((v, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					style: {
						height: 70,
						borderRadius: 8,
						display: "grid",
						placeItems: "center",
						background: v ? `color-mix(in srgb, var(--accent) ${Math.min(90, Math.log2(v) * 10)}%, var(--hover))` : "var(--hover)",
						fontWeight: 700,
						fontSize: v > 512 ? 16 : 20
					},
					children: v || ""
				}, i))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "os-btn",
				style: { marginTop: 12 },
				onClick: () => {
					setBoard(spawn(spawn(empty())));
					setScore(0);
				},
				children: "Заново"
			})
		]
	});
}
var PAIRS = [
	"▲",
	"●",
	"■",
	"◆",
	"★",
	"✦",
	"⬡",
	"♥"
];
function MemoryGame() {
	const shuffle = () => [...PAIRS, ...PAIRS].map((v) => ({
		v,
		k: Math.random()
	})).sort((a, b) => a.k - b.k).map((x, i) => ({
		id: i,
		v: x.v,
		open: false,
		done: false
	}));
	const [cards, setCards] = (0, import_react.useState)(shuffle);
	const [sel, setSel] = (0, import_react.useState)([]);
	const [moves, setMoves] = (0, import_react.useState)(0);
	const [t, setT] = (0, import_react.useState)(0);
	const [run, setRun] = (0, import_react.useState)(false);
	const notify = useOS((s) => s.notify);
	(0, import_react.useEffect)(() => {
		if (!run) return;
		const i = setInterval(() => setT((x) => x + 1), 1e3);
		return () => clearInterval(i);
	}, [run]);
	const click = (i) => {
		if (cards[i].open || cards[i].done || sel.length === 2) return;
		if (!run) setRun(true);
		const nextSel = [...sel, i];
		const next = cards.map((c, idx) => idx === i ? {
			...c,
			open: true
		} : c);
		setCards(next);
		setSel(nextSel);
		if (nextSel.length === 2) {
			setMoves((m) => m + 1);
			const [a, b] = nextSel;
			if (next[a].v === next[b].v) setTimeout(() => {
				setCards((c) => c.map((x, idx) => idx === a || idx === b ? {
					...x,
					done: true
				} : x));
				setSel([]);
				if (next.filter((x) => x.done).length + 2 === next.length) {
					setRun(false);
					notify({
						icon: "🧠",
						title: "Память",
						body: `Готово за ${moves + 1} ходов`
					});
				}
			}, 350);
			else setTimeout(() => {
				setCards((c) => c.map((x, idx) => idx === a || idx === b ? {
					...x,
					open: false
				} : x));
				setSel([]);
			}, 700);
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "app-pad",
		style: { textAlign: "center" },
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "muted",
				children: [
					"Ходы ",
					moves,
					" · ",
					t,
					" с"
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				style: {
					display: "grid",
					gridTemplateColumns: "repeat(4, 64px)",
					gap: 8,
					justifyContent: "center",
					marginTop: 10
				},
				children: cards.map((c, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => click(i),
					style: {
						height: 64,
						borderRadius: 10,
						border: "none",
						background: c.open || c.done ? "var(--accent)" : "var(--hover)",
						color: "#fff",
						fontSize: 22
					},
					children: c.open || c.done ? c.v : ""
				}, c.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "os-btn",
				style: { marginTop: 12 },
				onClick: () => {
					setCards(shuffle());
					setSel([]);
					setMoves(0);
					setT(0);
					setRun(false);
				},
				children: "Заново"
			})
		]
	});
}
function TicTacToe() {
	const [b, setB] = (0, import_react.useState)(Array(9).fill(null));
	const [lock, setLock] = (0, import_react.useState)(false);
	const notify = useOS((s) => s.notify);
	const winner = win(b);
	const play = (i) => {
		if (b[i] || winner || lock) return;
		const next = [...b];
		next[i] = "X";
		const w = win(next);
		setB(next);
		if (w) {
			notify({
				icon: "⭕",
				title: "Крестики-нолики",
				body: w === "X" ? "Вы победили" : w === "O" ? "ИИ победил" : "Ничья"
			});
			return;
		}
		setLock(true);
		setTimeout(() => {
			const ai = aiMove(next);
			if (ai >= 0) next[ai] = "O";
			setB([...next]);
			const w2 = win(next);
			if (w2) notify({
				icon: "⭕",
				title: "Крестики-нолики",
				body: w2 === "O" ? "ИИ победил" : "Ничья"
			});
			setLock(false);
		}, 280);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "app-pad",
		style: { textAlign: "center" },
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "muted",
				children: winner ? winner === "D" ? "Ничья" : `Победил ${winner}` : "Ваш ход · крестики"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				style: {
					display: "grid",
					gridTemplateColumns: "repeat(3, 72px)",
					gap: 8,
					justifyContent: "center",
					margin: 12
				},
				children: b.map((c, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => play(i),
					style: {
						height: 72,
						borderRadius: 12,
						border: "1px solid var(--border)",
						background: "var(--hover)",
						fontSize: 28
					},
					children: c ?? ""
				}, i))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "os-btn",
				onClick: () => {
					setB(Array(9).fill(null));
					setLock(false);
				},
				children: "Заново"
			})
		]
	});
}
function win(b) {
	for (const [a, c, d] of [
		[
			0,
			1,
			2
		],
		[
			3,
			4,
			5
		],
		[
			6,
			7,
			8
		],
		[
			0,
			3,
			6
		],
		[
			1,
			4,
			7
		],
		[
			2,
			5,
			8
		],
		[
			0,
			4,
			8
		],
		[
			2,
			4,
			6
		]
	]) if (b[a] && b[a] === b[c] && b[a] === b[d]) return b[a];
	if (b.every(Boolean)) return "D";
	return null;
}
function aiMove(b) {
	const tryWin = (p) => {
		for (let i = 0; i < 9; i++) {
			if (b[i]) continue;
			const t = [...b];
			t[i] = p;
			if (win(t) === p) return i;
		}
		return -1;
	};
	const w = tryWin("O");
	if (w >= 0) return w;
	const bl = tryWin("X");
	if (bl >= 0) return bl;
	if (!b[4]) return 4;
	const corners = [
		0,
		2,
		6,
		8
	].filter((i) => !b[i]);
	if (corners.length) return corners[Math.floor(Math.random() * corners.length)];
	return b.map((v, i) => v ? -1 : i).filter((i) => i >= 0)[0] ?? -1;
}
var TRACKS = [
	{
		title: "Night Drive",
		artist: "Aether",
		color: "#1d4ed8",
		seq: [
			220,
			277,
			330,
			440
		]
	},
	{
		title: "Glass Rain",
		artist: "Vizor",
		color: "#0f766e",
		seq: [
			196,
			247,
			294,
			392
		]
	},
	{
		title: "Northern Lights",
		artist: "Aurora",
		color: "#6d28d9",
		seq: [
			164,
			196,
			246,
			329
		]
	}
];
function MusicApp() {
	const [i, setI] = (0, import_react.useState)(0);
	const [play, setPlay] = (0, import_react.useState)(false);
	const [prog, setProg] = (0, import_react.useState)(0);
	const [dur] = (0, import_react.useState)(32);
	const canvas = (0, import_react.useRef)(null);
	const ctxRef = (0, import_react.useRef)(null);
	const volume = useOS((s) => s.settings.volume);
	const t = TRACKS[i];
	(0, import_react.useEffect)(() => {
		if (!play) return;
		const AC = window.AudioContext || window.webkitAudioContext;
		const ac = ctxRef.current ?? new AC();
		ctxRef.current = ac;
		ac.resume();
		let stop = false;
		let step = 0;
		const gain = ac.createGain();
		gain.gain.value = volume / 100 * .08;
		const analyser = ac.createAnalyser();
		analyser.fftSize = 64;
		gain.connect(analyser);
		analyser.connect(ac.destination);
		const osc = ac.createOscillator();
		osc.type = "sine";
		osc.frequency.value = t.seq[0];
		osc.connect(gain);
		osc.start();
		const id = setInterval(() => {
			step = (step + 1) % t.seq.length;
			osc.frequency.setTargetAtTime(t.seq[step], ac.currentTime, .05);
		}, 280);
		const data = new Uint8Array(analyser.frequencyBinCount);
		const loop = () => {
			if (stop) return;
			const c = canvas.current;
			const g = c?.getContext("2d");
			if (c && g) {
				analyser.getByteFrequencyData(data);
				g.clearRect(0, 0, c.width, c.height);
				const w = c.width / data.length;
				g.fillStyle = "#fff";
				data.forEach((v, idx) => {
					const h = v / 255 * c.height;
					g.globalAlpha = .85;
					g.fillRect(idx * w + 1, c.height - h, w - 2, h);
				});
			}
			requestAnimationFrame(loop);
		};
		loop();
		const tick = setInterval(() => {
			setProg((p) => {
				if (p >= dur) {
					setI((x) => (x + 1) % TRACKS.length);
					return 0;
				}
				return p + .25;
			});
		}, 250);
		return () => {
			stop = true;
			clearInterval(id);
			clearInterval(tick);
			osc.stop();
			osc.disconnect();
		};
	}, [
		play,
		i,
		volume,
		t.seq,
		dur
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "app-pad",
		style: {
			display: "flex",
			flexDirection: "column",
			alignItems: "center",
			gap: 12
		},
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				style: {
					width: 220,
					height: 220,
					borderRadius: 18,
					background: `linear-gradient(145deg, ${t.color}, #111)`,
					display: "grid",
					placeItems: "center"
				},
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("canvas", {
					ref: canvas,
					width: 180,
					height: 80
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				style: {
					fontSize: 20,
					fontWeight: 600
				},
				children: t.title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "muted",
				children: t.artist
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				className: "os-range",
				type: "range",
				min: 0,
				max: dur,
				value: prog,
				onChange: (e) => setProg(Number(e.target.value))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "muted",
				style: { fontVariantNumeric: "tabular-nums" },
				children: [
					fmt(prog),
					" / ",
					fmt(dur)
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				style: {
					display: "flex",
					gap: 10
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "os-btn",
						onClick: () => {
							setI((x) => (x + TRACKS.length - 1) % TRACKS.length);
							setProg(0);
						},
						children: "⏮"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "os-btn primary",
						onClick: () => setPlay(!play),
						children: play ? "⏸" : "▶"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "os-btn",
						onClick: () => {
							setI((x) => (x + 1) % TRACKS.length);
							setProg(0);
						},
						children: "⏭"
					})
				]
			})
		]
	});
}
function fmt(s) {
	return `${Math.floor(s / 60)}:${String(Math.floor(s % 60)).padStart(2, "0")}`;
}
var PHOTOS = [
	["#0ea5e9", "#1d4ed8"],
	["#f59e0b", "#b45309"],
	["#34d399", "#065f46"],
	["#f472b6", "#9d174d"],
	["#818cf8", "#312e81"],
	["#fb923c", "#7c2d12"],
	["#22d3ee", "#155e75"],
	["#a3e635", "#3f6212"],
	["#e879f9", "#6b21a8"],
	["#facc15", "#854d0e"],
	["#94a3b8", "#1e293b"],
	["#f43f5e", "#881337"]
];
function PhotosApp() {
	const notify = useOS((s) => s.notify);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "app-pad scroll",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			style: {
				display: "grid",
				gridTemplateColumns: "repeat(4, 1fr)",
				gap: 8
			},
			children: PHOTOS.map((g, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				style: {
					aspectRatio: "1",
					borderRadius: 10,
					border: "none",
					background: `linear-gradient(135deg, ${g[0]}, ${g[1]})`
				},
				onClick: () => notify({
					icon: "🖼️",
					title: "Фотографии",
					body: `Снимок ${i + 1} · локальный альбом`
				})
			}, i))
		})
	});
}
var DAYS = [
	{
		d: "Сегодня",
		icon: "☁️",
		t: 12,
		n: 6
	},
	{
		d: "Вт",
		icon: "🌦️",
		t: 10,
		n: 4
	},
	{
		d: "Ср",
		icon: "🌧️",
		t: 8,
		n: 3
	},
	{
		d: "Чт",
		icon: "⛅",
		t: 11,
		n: 5
	},
	{
		d: "Пт",
		icon: "☀️",
		t: 14,
		n: 7
	}
];
function WeatherApp() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "app-pad",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "muted",
				children: "Москва"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				style: {
					fontSize: 56,
					fontWeight: 200
				},
				children: "+12°"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: "Облачно · ощущается как +9°" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid-2",
				style: { margin: "14px 0" },
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "card",
					children: "Влажность 72%"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "card",
					children: "Ветер 4 м/с"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid-3",
				children: DAYS.map((x) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "card",
					style: { textAlign: "center" },
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "muted",
							children: x.d
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							style: { fontSize: 24 },
							children: x.icon
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							x.t,
							"° / ",
							x.n,
							"°"
						] })
					]
				}, x.d))
			})
		]
	});
}
var KEY$1 = `${OS.storageKey}_notepad`;
function NotepadApp() {
	const [text, setText] = (0, import_react.useState)(() => typeof localStorage !== "undefined" ? localStorage.getItem(KEY$1) ?? "" : "");
	const [wrap, setWrap] = (0, import_react.useState)(true);
	const [menu, setMenu] = (0, import_react.useState)(null);
	const notify = useOS((s) => s.notify);
	(0, import_react.useEffect)(() => {
		localStorage.setItem(KEY$1, text);
	}, [text]);
	const run = (id) => {
		setMenu(null);
		if (id === "new") setText("");
		if (id === "save") {
			localStorage.setItem(KEY$1, text);
			notify({
				icon: "📝",
				title: "Блокнот",
				body: "Файл сохранён"
			});
		}
		if (id === "cut") {
			navigator.clipboard?.writeText(text);
			setText("");
		}
		if (id === "copy") navigator.clipboard?.writeText(text);
		if (id === "paste") navigator.clipboard?.readText().then((t) => setText((s) => s + t)).catch(() => {});
		if (id === "wrap") setWrap((v) => !v);
		if (id === "time") setText((s) => s + "\n" + (/* @__PURE__ */ new Date()).toLocaleString("ru-RU"));
	};
	const menus = {
		Файл: [{
			id: "new",
			label: "Создать"
		}, {
			id: "save",
			label: "Сохранить"
		}],
		Правка: [
			{
				id: "cut",
				label: "Вырезать"
			},
			{
				id: "copy",
				label: "Копировать"
			},
			{
				id: "paste",
				label: "Вставить"
			},
			{
				id: "time",
				label: "Время и дата"
			}
		],
		Формат: [{
			id: "wrap",
			label: wrap ? "Не переносить" : "Переносить строки"
		}],
		Вид: [{
			id: "wrap",
			label: "Перенос строк"
		}]
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		style: {
			height: "100%",
			display: "flex",
			flexDirection: "column"
		},
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			style: {
				display: "flex",
				gap: 2,
				padding: "4px 8px",
				borderBottom: "1px solid var(--border)",
				position: "relative"
			},
			children: [Object.keys(menus).map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "os-btn",
				style: { height: 26 },
				onClick: () => setMenu(menu === m ? null : m),
				children: m
			}, m)), menu && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "ctx",
				style: {
					left: 8,
					top: 34,
					position: "absolute"
				},
				children: menus[menu].map((it) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => run(it.id),
					children: it.label
				}, it.id))
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
			className: "note-area",
			value: text,
			onChange: (e) => setText(e.target.value),
			spellCheck: false,
			style: { whiteSpace: wrap ? "pre-wrap" : "pre" },
			placeholder: "Начните ввод…"
		})]
	});
}
var KEY = `${OS.storageKey}_notes`;
function NotesApp() {
	const [notes, setNotes] = (0, import_react.useState)(() => loadJson(KEY, [{
		id: "n1",
		title: "Добро пожаловать",
		body: "Это ваши заметки в AetherOS.",
		at: Date.now()
	}]));
	const [cur, setCur] = (0, import_react.useState)(notes[0]?.id ?? null);
	const note = notes.find((n) => n.id === cur);
	(0, import_react.useEffect)(() => {
		saveJson(KEY, notes);
	}, [notes]);
	const patch = (p) => {
		setNotes((list) => list.map((n) => n.id === cur ? {
			...n,
			...p,
			at: Date.now()
		} : n));
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		style: {
			display: "grid",
			gridTemplateColumns: "220px 1fr",
			height: "100%"
		},
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "side-nav",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "os-btn primary",
				style: {
					width: "100%",
					marginBottom: 8
				},
				onClick: () => {
					const n = {
						id: uid$1("n"),
						title: "Новая заметка",
						body: "",
						at: Date.now()
					};
					setNotes([n, ...notes]);
					setCur(n.id);
				},
				children: "+ Новая заметка"
			}), notes.map((n) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: n.id === cur ? "active" : "",
				onClick: () => setCur(n.id),
				children: n.title || "Без названия"
			}, n.id))]
		}), note ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			style: {
				display: "flex",
				flexDirection: "column",
				minWidth: 0
			},
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				className: "os-input",
				style: {
					border: "none",
					borderRadius: 0,
					height: 44,
					fontSize: 16,
					background: "transparent"
				},
				value: note.title,
				onChange: (e) => patch({ title: e.target.value })
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
				className: "note-area",
				value: note.body,
				onChange: (e) => patch({ body: e.target.value }),
				placeholder: "Текст заметки"
			})]
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "muted",
			style: { padding: 20 },
			children: "Нет заметок"
		})]
	});
}
function PaintApp() {
	const canvasRef = (0, import_react.useRef)(null);
	const wrapRef = (0, import_react.useRef)(null);
	const [color, setColor] = (0, import_react.useState)("#0a84ff");
	const [size, setSize] = (0, import_react.useState)(6);
	const [tool, setTool] = (0, import_react.useState)("brush");
	const drawing = (0, import_react.useRef)(false);
	const last = (0, import_react.useRef)(null);
	const fit = () => {
		const c = canvasRef.current;
		const w = wrapRef.current;
		if (!c || !w) return;
		const dpr = Math.min(2, window.devicePixelRatio || 1);
		const rect = w.getBoundingClientRect();
		const img = c.getContext("2d")?.getImageData(0, 0, c.width, c.height);
		c.width = Math.max(1, rect.width * dpr);
		c.height = Math.max(1, rect.height * dpr);
		const ctx = c.getContext("2d");
		if (!ctx) return;
		ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
		ctx.fillStyle = "#ffffff";
		ctx.fillRect(0, 0, rect.width, rect.height);
		if (img) {}
	};
	(0, import_react.useEffect)(() => {
		fit();
		const ro = new ResizeObserver(fit);
		if (wrapRef.current) ro.observe(wrapRef.current);
		return () => ro.disconnect();
	}, []);
	const pos = (e) => {
		const r = canvasRef.current.getBoundingClientRect();
		return {
			x: e.clientX - r.left,
			y: e.clientY - r.top
		};
	};
	const stroke = (from, to) => {
		const ctx = canvasRef.current?.getContext("2d");
		if (!ctx) return;
		ctx.lineCap = "round";
		ctx.lineJoin = "round";
		ctx.lineWidth = size;
		ctx.strokeStyle = tool === "erase" ? "#ffffff" : color;
		ctx.beginPath();
		ctx.moveTo(from.x, from.y);
		ctx.lineTo(to.x, to.y);
		ctx.stroke();
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		style: {
			height: "100%",
			display: "flex",
			flexDirection: "column"
		},
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			style: {
				display: "flex",
				gap: 8,
				alignItems: "center",
				padding: 8,
				borderBottom: "1px solid var(--border)"
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					type: "color",
					value: color,
					onChange: (e) => setColor(e.target.value)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: "os-range",
					style: { width: 120 },
					type: "range",
					min: 1,
					max: 40,
					value: size,
					onChange: (e) => setSize(Number(e.target.value))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "muted",
					children: [size, "px"]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: `os-btn ${tool === "brush" ? "primary" : ""}`,
					onClick: () => setTool("brush"),
					children: "Кисть"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: `os-btn ${tool === "erase" ? "primary" : ""}`,
					onClick: () => setTool("erase"),
					children: "Ластик"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "os-btn",
					onClick: () => {
						const c = canvasRef.current;
						const ctx = c?.getContext("2d");
						if (!c || !ctx) return;
						ctx.setTransform(1, 0, 0, 1, 0, 0);
						ctx.fillStyle = "#fff";
						ctx.fillRect(0, 0, c.width, c.height);
						const dpr = Math.min(2, window.devicePixelRatio || 1);
						ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
					},
					children: "Очистить"
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			ref: wrapRef,
			style: {
				flex: 1,
				minHeight: 0
			},
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("canvas", {
				ref: canvasRef,
				style: {
					width: "100%",
					height: "100%",
					display: "block",
					cursor: "crosshair",
					touchAction: "none"
				},
				onPointerDown: (e) => {
					drawing.current = true;
					last.current = pos(e);
					e.target.setPointerCapture(e.pointerId);
					stroke(last.current, last.current);
				},
				onPointerMove: (e) => {
					if (!drawing.current || !last.current) return;
					const p = pos(e);
					stroke(last.current, p);
					last.current = p;
				},
				onPointerUp: () => {
					drawing.current = false;
					last.current = null;
				}
			})
		})]
	});
}
var SECTIONS = [
	"Система",
	"Персонализация",
	"Приложения",
	"Время и язык",
	"Сеть",
	"Звук",
	"Уведомления",
	"Конфиденциальность",
	"Обновление",
	"Мышь",
	"Память",
	"Данные",
	"О системе"
];
function SettingsApp() {
	const [sec, setSec] = (0, import_react.useState)("Система");
	const s = useOS((s) => s.settings);
	const patch = useOS((s) => s.patchSettings);
	const setPhase = useOS((s) => s.setPhase);
	const notify = useOS((s) => s.notify);
	const windows = useOS((s) => s.windows);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		style: {
			display: "flex",
			height: "100%"
		},
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "side-nav",
			children: SECTIONS.map((n) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: sec === n ? "active" : "",
				onClick: () => setSec(n),
				children: n
			}, n))
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "scroll app-pad",
			style: { flex: 1 },
			children: [
				sec === "Система" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						style: { marginTop: 0 },
						children: s.pcName
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						k: "ОС",
						v: `${OS.name} ${OS.version}`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						k: "Сборка",
						v: OS.build
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "os-input",
						style: {
							width: "100%",
							margin: "10px 0"
						},
						value: s.pcName,
						onChange: (e) => patch({ pcName: e.target.value })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "os-btn",
						onClick: () => setPhase("restart"),
						children: "Перезагрузка"
					})
				] }),
				sec === "Персонализация" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "muted",
						children: "Тема"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						style: {
							display: "flex",
							gap: 8,
							margin: "8px 0 14px"
						},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: `os-btn ${s.theme === "dark" ? "primary" : ""}`,
							onClick: () => patch({ theme: "dark" }),
							children: "Тёмная"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: `os-btn ${s.theme === "light" ? "primary" : ""}`,
							onClick: () => patch({ theme: "light" }),
							children: "Светлая"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "muted",
						children: "Обои"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						style: {
							display: "grid",
							gridTemplateColumns: "repeat(4, 1fr)",
							gap: 8,
							margin: "8px 0 14px"
						},
						children: WALLPAPERS.map((w) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => patch({ wallpaper: w.url }),
							title: w.name,
							style: {
								aspectRatio: "16/10",
								borderRadius: 8,
								border: s.wallpaper === w.url ? "2px solid var(--accent)" : "1px solid var(--border)",
								background: `url(${w.url}) center/cover`
							}
						}, w.id))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "muted",
						children: "Акцент"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						style: {
							display: "flex",
							gap: 8,
							flexWrap: "wrap",
							margin: "8px 0 14px"
						},
						children: ACCENTS.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => patch({ accent: c }),
							style: {
								width: 28,
								height: 28,
								borderRadius: 99,
								background: c,
								border: s.accent === c ? "2px solid #fff" : "2px solid transparent",
								boxShadow: s.accent === c ? "0 0 0 2px var(--fg)" : void 0
							}
						}, c))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "muted",
						children: "Иконки"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						style: {
							display: "flex",
							gap: 8,
							margin: "8px 0"
						},
						children: [
							"sm",
							"md",
							"lg"
						].map((x) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: `os-btn ${s.iconSize === x ? "primary" : ""}`,
							onClick: () => patch({ iconSize: x }),
							children: x === "sm" ? "Мелкие" : x === "md" ? "Средние" : "Крупные"
						}, x))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						style: {
							display: "flex",
							gap: 8,
							alignItems: "center",
							marginTop: 12
						},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "checkbox",
							checked: s.animations,
							onChange: (e) => patch({ animations: e.target.checked })
						}), "Анимации"]
					})
				] }),
				sec === "Приложения" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: APPS.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "card",
					style: {
						marginBottom: 6,
						display: "flex",
						justifyContent: "space-between"
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
						a.icon,
						" ",
						a.name
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "muted",
						children: a.size
					})]
				}, a.id)) }),
				sec === "Время и язык" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						style: {
							display: "flex",
							gap: 8,
							marginBottom: 10
						},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "checkbox",
							checked: s.clock24,
							onChange: (e) => patch({ clock24: e.target.checked })
						}), "24-часовой формат"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						style: {
							display: "flex",
							gap: 8
						},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "checkbox",
							checked: s.showSeconds,
							onChange: (e) => patch({ showSeconds: e.target.checked })
						}), "Показывать секунды"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "muted",
						children: "Язык интерфейса: русский"
					})
				] }),
				sec === "Сеть" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle, {
						label: "Wi-Fi",
						on: s.wifi,
						onChange: (v) => patch({
							wifi: v,
							airplane: v ? false : s.airplane
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle, {
						label: "Bluetooth",
						on: s.bluetooth,
						onChange: (v) => patch({ bluetooth: v })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle, {
						label: "Авиарежим",
						on: s.airplane,
						onChange: (v) => patch({
							airplane: v,
							wifi: v ? false : s.wifi
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "card",
						style: { marginTop: 10 },
						children: ["Aether-5G · ", s.wifi ? "подключено" : "отключено"]
					})
				] }),
				sec === "Звук" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "muted",
					children: [
						"Громкость ",
						s.volume,
						"%"
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: "os-range",
					type: "range",
					min: 0,
					max: 100,
					value: s.volume,
					onChange: (e) => patch({ volume: Number(e.target.value) })
				})] }),
				sec === "Уведомления" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle, {
					label: "Показывать баннеры",
					on: s.banners,
					onChange: (v) => patch({ banners: v })
				}),
				sec === "Конфиденциальность" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle, {
					label: "Камера",
					on: s.cameraAllowed,
					onChange: (v) => patch({ cameraAllowed: v })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle, {
					label: "Микрофон",
					on: s.micAllowed,
					onChange: (v) => patch({ micAllowed: v })
				})] }),
				sec === "Обновление" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: ["AetherOS в актуальном состоянии · ", OS.build] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "os-btn primary",
					onClick: () => {
						notify({
							icon: "⬇️",
							title: "Центр обновления",
							body: "Новых обновлений нет"
						});
					},
					children: "Проверить наличие обновлений"
				})] }),
				sec === "Мышь" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "muted",
					children: ["Скорость ", s.mouseSpeed]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: "os-range",
					type: "range",
					min: 1,
					max: 20,
					value: s.mouseSpeed,
					onChange: (e) => patch({ mouseSpeed: Number(e.target.value) })
				})] }),
				sec === "Память" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
						label: "Диск C:",
						used: 42,
						total: 128
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
						label: "Диск D:",
						used: 180,
						total: 512
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "muted",
						children: ["Открыто окон: ", windows.length]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "os-btn",
						onClick: () => notify({
							icon: "🧹",
							title: "Память",
							body: "Временные файлы очищены (симуляция)"
						}),
						children: "Очистка"
					})
				] }),
				sec === "Данные" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "os-btn",
						onClick: () => {
							const blob = new Blob([JSON.stringify({ settings: s }, null, 2)], { type: "application/json" });
							const a = document.createElement("a");
							a.href = URL.createObjectURL(blob);
							a.download = "aetheros-backup.json";
							a.click();
						},
						children: "Экспорт JSON"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "os-btn",
						style: {
							display: "inline-grid",
							placeItems: "center",
							marginLeft: 8
						},
						children: ["Импорт JSON", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "file",
							accept: "application/json",
							hidden: true,
							onChange: (e) => {
								const f = e.target.files?.[0];
								if (!f) return;
								f.text().then((t) => {
									try {
										const data = JSON.parse(t);
										if (data.settings) patch(data.settings);
										notify({
											icon: "⚙️",
											title: "Данные",
											body: "Импорт выполнен"
										});
									} catch {
										notify({
											icon: "⚙️",
											title: "Данные",
											body: "Файл повреждён"
										});
									}
								});
							}
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "os-btn danger",
						style: { marginLeft: 8 },
						onClick: () => {
							Object.keys(localStorage).filter((k) => k.startsWith(OS.storageKey)).forEach((k) => localStorage.removeItem(k));
							patch(defaultSettings());
							saveJson(`${OS.storageKey}_settings`, defaultSettings());
							notify({
								icon: "⚠️",
								title: "Сброс",
								body: "Настройки сброшены"
							});
						},
						children: "Сброс"
					})
				] }),
				sec === "О системе" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					style: { textAlign: "center" },
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(OsLogo, {
							size: 56,
							glow: true
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", { children: OS.name }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "muted",
							children: [
								OS.version,
								" (",
								OS.build,
								") · © ",
								OS.year,
								" ",
								OS.author
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "PROPRIETARY · All Rights Reserved" })
					]
				})
			]
		})]
	});
}
function Row({ k, v }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		style: {
			display: "flex",
			justifyContent: "space-between",
			padding: "8px 0",
			borderBottom: "1px solid var(--border)"
		},
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "muted",
			children: k
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: v })]
	});
}
function Toggle({ label, on, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		style: {
			display: "flex",
			justifyContent: "space-between",
			padding: "10px 0",
			borderBottom: "1px solid var(--border)"
		},
		children: [label, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			type: "checkbox",
			checked: on,
			onChange: (e) => onChange(e.target.checked)
		})]
	});
}
function Bar({ label, used, total }) {
	const p = Math.round(used / total * 100);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "card",
		style: { marginBottom: 8 },
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			style: {
				display: "flex",
				justifyContent: "space-between"
			},
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: label }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "muted",
				children: [
					used,
					" / ",
					total,
					" ГБ"
				]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			style: {
				height: 8,
				background: "var(--hover)",
				borderRadius: 99,
				marginTop: 8
			},
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { style: {
				width: `${p}%`,
				height: "100%",
				background: "var(--accent)",
				borderRadius: 99
			} })
		})]
	});
}
var CATS = [
	"Все",
	"Игры",
	"Продуктивность",
	"Медиа",
	"Утилиты"
];
var MAP$1 = {
	Все: "",
	Игры: "games",
	Продуктивность: "productivity",
	Медиа: "media",
	Утилиты: "utilities"
};
function StoreApp() {
	const [cat, setCat] = (0, import_react.useState)("Все");
	const [q, setQ] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)({});
	const installed = useOS((s) => s.settings.installed);
	const pins = useOS((s) => s.settings.desktopPins);
	const installApp = useOS((s) => s.installApp);
	const openApp = useOS((s) => s.openApp);
	const notify = useOS((s) => s.notify);
	const list = (0, import_react.useMemo)(() => {
		return APPS.filter((a) => {
			if (MAP$1[cat] && a.category !== MAP$1[cat]) return false;
			if (q && !a.name.toLowerCase().includes(q.toLowerCase())) return false;
			return a.id !== "store";
		});
	}, [cat, q]);
	const startInstall = (id, name) => {
		if (busy[id] != null) return;
		let p = 0;
		setBusy((b) => ({
			...b,
			[id]: 0
		}));
		const t = setInterval(() => {
			p += 8 + Math.random() * 12;
			if (p >= 100) {
				clearInterval(t);
				setBusy((b) => ({
					...b,
					[id]: 100
				}));
				setTimeout(() => {
					installApp(id);
					setBusy((b) => {
						const n = { ...b };
						delete n[id];
						return n;
					});
					notify({
						icon: "🛒",
						title: "Установлено",
						body: `${name} добавлено на рабочий стол`
					});
				}, 500);
			} else setBusy((b) => ({
				...b,
				[id]: Math.min(99, Math.round(p))
			}));
		}, 120);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "app-pad scroll",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			style: {
				display: "flex",
				gap: 8,
				marginBottom: 12,
				flexWrap: "wrap"
			},
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				className: "os-input",
				placeholder: "Поиск",
				value: q,
				onChange: (e) => setQ(e.target.value),
				style: {
					flex: 1,
					minWidth: 160
				}
			}), CATS.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: `os-btn ${cat === c ? "primary" : ""}`,
				onClick: () => setCat(c),
				children: c
			}, c))]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid-2",
			children: list.map((a) => {
				const done = installed.includes(a.id) || pins.includes(a.id);
				const prog = busy[a.id];
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "card",
					style: {
						display: "flex",
						gap: 12,
						alignItems: "center"
					},
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							style: { fontSize: 32 },
							children: a.icon
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							style: {
								flex: 1,
								minWidth: 0
							},
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									style: { fontWeight: 600 },
									children: a.name
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "muted",
									children: a.description
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "subtle",
									children: a.size
								}),
								prog != null && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									style: {
										height: 6,
										background: "var(--hover)",
										borderRadius: 99,
										marginTop: 6
									},
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { style: {
										width: `${prog}%`,
										height: "100%",
										background: "var(--accent)",
										borderRadius: 99
									} })
								})
							]
						}),
						prog != null ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "os-btn",
							disabled: true,
							children: prog < 100 ? `${prog}%` : "Установка..."
						}) : done ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "os-btn primary",
							onClick: () => openApp(a.id),
							children: "Открыть"
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "os-btn",
							onClick: () => startInstall(a.id, a.name),
							children: "Установить"
						})
					]
				}, a.id);
			})
		})]
	});
}
function TaskManagerApp() {
	const windows = useOS((s) => s.windows);
	const closeWin = useOS((s) => s.closeWin);
	const [, bump] = (0, import_react.useState)(0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "app-pad",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			style: {
				display: "flex",
				justifyContent: "space-between",
				marginBottom: 10
			},
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Процессы" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "os-btn",
				onClick: () => bump((n) => n + 1),
				children: "Обновить"
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
			style: {
				width: "100%",
				borderCollapse: "collapse",
				fontSize: 13
			},
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
				className: "muted",
				style: { textAlign: "left" },
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						style: { padding: 6 },
						children: "Приложение"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "ОЗУ" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "ЦП" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {})
				]
			}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tbody", { children: [windows.map((w) => {
				const ram = 80 + w.z * 13 % 220;
				const cpu = w.z * 7 % 18 + (w.minimized ? 0 : 4);
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
					style: { borderTop: "1px solid var(--border)" },
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
							style: { padding: 6 },
							children: [
								w.icon,
								" ",
								w.title
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", { children: [ram, " МБ"] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", { children: [cpu, "%"] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "os-btn danger",
							onClick: () => closeWin(w.id),
							children: "Завершить"
						}) })
					]
				}, w.id);
			}), windows.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
				colSpan: 4,
				className: "muted",
				style: { padding: 12 },
				children: "Нет запущенных приложений"
			}) })] })]
		})]
	});
}
var PROMPT = `C:\\Users\\${OS.user}>`;
function TerminalApp() {
	const [lines, setLines] = (0, import_react.useState)([
		`${OS.name} [версия ${OS.version} сборка ${OS.build}]`,
		"(c) Vizor, 2026. Все права защищены.",
		""
	]);
	const [input, setInput] = (0, import_react.useState)("");
	const hist = (0, import_react.useRef)([]);
	const hi = (0, import_react.useRef)(-1);
	const box = (0, import_react.useRef)(null);
	const openApp = useOS((s) => s.openApp);
	const setPhase = useOS((s) => s.setPhase);
	const windows = useOS((s) => s.windows);
	const closeWin = useOS((s) => s.closeWin);
	(0, import_react.useEffect)(() => {
		box.current?.scrollTo(0, box.current.scrollHeight);
	}, [lines]);
	const print = (more) => setLines((l) => [...l, ...more]);
	const run = (raw) => {
		const cmd = raw.trim();
		print([`${PROMPT}${cmd}`]);
		if (!cmd) return;
		hist.current.push(cmd);
		hi.current = hist.current.length;
		const [head, ...rest] = cmd.split(/\s+/);
		const arg = rest.join(" ");
		const h = head.toLowerCase();
		if (h === "help") print(["help ver dir cls date time echo whoami hostname ipconfig ping", "tasklist kill tree банк настройки камера часы qr exit shutdown restart"]);
		else if (h === "ver") print([`${OS.name} версия ${OS.version} (сборка ${OS.build})`]);
		else if (h === "cls") setLines([]);
		else if (h === "date") print([(/* @__PURE__ */ new Date()).toLocaleDateString("ru-RU")]);
		else if (h === "time") print([(/* @__PURE__ */ new Date()).toLocaleTimeString("ru-RU")]);
		else if (h === "echo") print([arg]);
		else if (h === "whoami") print([`${OS.hostname}\\${OS.user}`]);
		else if (h === "hostname") print([OS.hostname]);
		else if (h === "dir") print([
			" Каталог C:\\Users\\User",
			"",
			"26.09.2026  12:00    <DIR>          Documents",
			"26.09.2026  12:00    <DIR>          Downloads",
			"26.09.2026  12:00    <DIR>          Desktop",
			"               0 файлов"
		]);
		else if (h === "ipconfig") print([
			"Адаптер Ethernet AetherLink:",
			"   IPv4-адрес. . . . . . . . . : 192.168.1.42",
			"   Маска подсети . . . . . . . : 255.255.255.0",
			"   Основной шлюз . . . . . . . : 192.168.1.1"
		]);
		else if (h === "ping") print([
			`Обмен пакетами с ${arg || "aether.local"}:`,
			"Ответ от 192.168.1.1: число байт=32 время=4мс TTL=64",
			"Ответ от 192.168.1.1: число байт=32 время=5мс TTL=64",
			"Статистика: отправлено 4, получено 4, потерь 0%"
		]);
		else if (h === "tasklist") print([
			"Имя образа                     PID",
			"====================================",
			...windows.map((w, i) => `${w.title.padEnd(30)} ${1e3 + i}`)
		]);
		else if (h === "kill") {
			const t = windows.find((w) => w.title.toLowerCase().includes(arg.toLowerCase()) || w.appId === arg);
			if (t) {
				closeWin(t.id);
				print([`Процесс ${t.title} завершён.`]);
			} else print(["Не найден."]);
		} else if (h === "tree") print([
			"C:\\",
			"├─ Users",
			"│  └─ User",
			"│     ├─ Documents",
			"│     └─ Desktop",
			"├─ Windows",
			"└─ Program Files"
		]);
		else if (h === "банк" || h === "bank") openApp("bank");
		else if (h === "настройки" || h === "settings") openApp("settings");
		else if (h === "камера") openApp("camera");
		else if (h === "часы") openApp("clock");
		else if (h === "qr") openApp("qr");
		else if (h === "exit") {
			const w = windows.find((x) => x.appId === "terminal");
			if (w) closeWin(w.id);
		} else if (h === "shutdown") setPhase("shutdown");
		else if (h === "restart") setPhase("restart");
		else if (h === "apps") print(APPS.map((a) => a.id + " — " + a.name));
		else print([`'${head}' не является внутренней или внешней командой.`]);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "term",
		ref: box,
		onClick: () => box.current?.querySelector("input")?.focus(),
		children: [lines.map((l, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: l.startsWith(PROMPT) ? "cmd" : l.includes("не является") ? "err" : "ok",
			children: l || "\xA0"
		}, i)), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "cmd",
			children: PROMPT
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			value: input,
			autoFocus: true,
			spellCheck: false,
			onChange: (e) => setInput(e.target.value),
			onKeyDown: (e) => {
				if (e.key === "Enter") {
					run(input);
					setInput("");
				}
				if (e.key === "ArrowUp") {
					e.preventDefault();
					hi.current = Math.max(0, hi.current - 1);
					setInput(hist.current[hi.current] ?? "");
				}
				if (e.key === "ArrowDown") {
					e.preventDefault();
					hi.current = Math.min(hist.current.length, hi.current + 1);
					setInput(hist.current[hi.current] ?? "");
				}
			}
		})] })]
	});
}
function QRApp() {
	const [kind, setKind] = (0, import_react.useState)("text");
	const [text, setText] = (0, import_react.useState)("AetherOS");
	const [url, setUrl] = (0, import_react.useState)("https://aether.os");
	const [phone, setPhone] = (0, import_react.useState)("+79990000000");
	const [email, setEmail] = (0, import_react.useState)("vizor@aether.os");
	const [ssid, setSsid] = (0, import_react.useState)("Aether-5G");
	const [pass, setPass] = (0, import_react.useState)("secret");
	const [pay, setPay] = (0, import_react.useState)("1000");
	const canvas = (0, import_react.useRef)(null);
	const payload = () => {
		if (kind === "url") return url;
		if (kind === "phone") return `tel:${phone}`;
		if (kind === "email") return `mailto:${email}`;
		if (kind === "wifi") return `WIFI:S:${ssid};T:WPA;P:${pass};;`;
		if (kind === "pay") return `ST00012|Name=AetherBank|Sum=${Number(pay) * 100}|Purpose=Payment`;
		return text;
	};
	(0, import_react.useEffect)(() => {
		drawQR(canvas.current, payload());
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "app-pad scroll",
		style: { textAlign: "center" },
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				style: {
					display: "flex",
					gap: 6,
					flexWrap: "wrap",
					justifyContent: "center",
					marginBottom: 12
				},
				children: [
					["text", "Текст"],
					["url", "URL"],
					["phone", "Телефон"],
					["email", "Email"],
					["wifi", "Wi-Fi"],
					["pay", "Платёж"]
				].map(([k, l]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: `os-btn ${kind === k ? "primary" : ""}`,
					onClick: () => setKind(k),
					children: l
				}, k))
			}),
			kind === "text" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				className: "os-input",
				style: { width: "100%" },
				value: text,
				onChange: (e) => setText(e.target.value)
			}),
			kind === "url" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				className: "os-input",
				style: { width: "100%" },
				value: url,
				onChange: (e) => setUrl(e.target.value)
			}),
			kind === "phone" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				className: "os-input",
				style: { width: "100%" },
				value: phone,
				onChange: (e) => setPhone(e.target.value)
			}),
			kind === "email" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				className: "os-input",
				style: { width: "100%" },
				value: email,
				onChange: (e) => setEmail(e.target.value)
			}),
			kind === "wifi" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: "os-input",
					value: ssid,
					onChange: (e) => setSsid(e.target.value)
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: "os-input",
					value: pass,
					onChange: (e) => setPass(e.target.value)
				})]
			}),
			kind === "pay" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				className: "os-input",
				style: { width: "100%" },
				value: pay,
				onChange: (e) => setPay(e.target.value)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("canvas", {
				ref: canvas,
				width: 250,
				height: 250,
				style: {
					margin: "16px auto",
					display: "block",
					background: "#fff",
					borderRadius: 12
				}
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "muted",
				style: { wordBreak: "break-all" },
				children: payload()
			})
		]
	});
}
function drawQR(canvas, text) {
	if (!canvas) return;
	const n = 25;
	const ctx = canvas.getContext("2d");
	if (!ctx) return;
	const cell = canvas.width / n;
	ctx.fillStyle = "#fff";
	ctx.fillRect(0, 0, canvas.width, canvas.height);
	const grid = Array.from({ length: n }, () => Array(n).fill(false));
	const finder = (x, y) => {
		for (let i = 0; i < 7; i++) for (let j = 0; j < 7; j++) {
			const edge = i === 0 || i === 6 || j === 0 || j === 6;
			const inner = i >= 2 && i <= 4 && j >= 2 && j <= 4;
			grid[y + i][x + j] = edge || inner;
		}
	};
	finder(0, 0);
	finder(18, 0);
	finder(0, 18);
	let h = 2166136261;
	for (const c of text) {
		h ^= c.charCodeAt(0);
		h = Math.imul(h, 16777619);
	}
	let bit = h >>> 0;
	for (let y = 0; y < n; y++) for (let x = 0; x < n; x++) {
		if (x < 8 && y < 8 || x > 16 && y < 8 || x < 8 && y > 16 || y === 6 || x === 6) continue;
		bit = Math.imul(bit, 1103515245) + 12345 >>> 0;
		grid[y][x] = (bit & 256) !== 0;
	}
	for (let i = 0; i < n; i++) {
		grid[6][i] = i % 2 === 0;
		grid[i][6] = i % 2 === 0;
	}
	finder(0, 0);
	finder(18, 0);
	finder(0, 18);
	ctx.fillStyle = "#111";
	for (let y = 0; y < n; y++) for (let x = 0; x < n; x++) if (grid[y][x]) ctx.fillRect(x * cell, y * cell, cell, cell);
}
function RecorderApp() {
	const [rec, setRec] = (0, import_react.useState)(false);
	const [t, setT] = (0, import_react.useState)(0);
	const [clips, setClips] = (0, import_react.useState)([]);
	const recRef = (0, import_react.useRef)(null);
	const chunks = (0, import_react.useRef)([]);
	const notify = useOS((s) => s.notify);
	const allowed = useOS((s) => s.settings.micAllowed);
	(0, import_react.useEffect)(() => {
		if (!rec) return;
		const i = setInterval(() => setT((x) => x + 1), 1e3);
		return () => clearInterval(i);
	}, [rec]);
	const toggle = async () => {
		if (rec) {
			recRef.current?.stop();
			setRec(false);
			return;
		}
		if (!allowed) {
			notify({
				icon: "🎤",
				title: "Диктофон",
				body: "Микрофон отключён в параметрах"
			});
			return;
		}
		try {
			const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
			const mr = new MediaRecorder(stream);
			chunks.current = [];
			mr.ondataavailable = (e) => e.data.size && chunks.current.push(e.data);
			mr.onstop = () => {
				stream.getTracks().forEach((tr) => tr.stop());
				const blob = new Blob(chunks.current, { type: mr.mimeType || "audio/webm" });
				const url = URL.createObjectURL(blob);
				setClips((c) => [{
					id: String(Date.now()),
					url,
					dur: t,
					size: blob.size
				}, ...c]);
			};
			mr.start();
			recRef.current = mr;
			setT(0);
			setRec(true);
		} catch {
			notify({
				icon: "🎤",
				title: "Диктофон",
				body: "Нет доступа к микрофону"
			});
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "app-pad scroll",
		style: { textAlign: "center" },
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: toggle,
				style: {
					width: 96,
					height: 96,
					borderRadius: 99,
					border: "none",
					background: rec ? "var(--danger)" : "var(--accent)",
					color: "#fff",
					fontSize: 32,
					boxShadow: rec ? "0 0 0 12px color-mix(in srgb, var(--danger) 25%, transparent)" : void 0,
					animation: rec ? "pulse 1.2s ease-in-out infinite" : void 0
				},
				children: rec ? "■" : "●"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				style: {
					fontSize: 28,
					margin: "12px 0",
					fontVariantNumeric: "tabular-nums"
				},
				children: [
					String(Math.floor(t / 60)).padStart(2, "0"),
					":",
					String(t % 60).padStart(2, "0")
				]
			}),
			clips.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "card",
				style: {
					marginBottom: 8,
					textAlign: "left"
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("audio", {
					controls: true,
					src: c.url,
					style: { width: "100%" }
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "muted",
					style: {
						display: "flex",
						justifyContent: "space-between"
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [(c.size / 1024).toFixed(1), " КБ"] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: c.url,
						download: "record.webm",
						children: "Скачать"
					})]
				})]
			}, c.id))
		]
	});
}
var UNITS = {
	Длина: {
		м: 1,
		км: 1e3,
		см: .01,
		миля: 1609.34,
		фут: .3048
	},
	Масса: {
		кг: 1,
		г: .001,
		фунт: .453592,
		т: 1e3
	},
	Температура: {
		"°C": 1,
		"°F": 1,
		K: 1
	}
};
function ConverterApp() {
	const [cat, setCat] = (0, import_react.useState)("Длина");
	const [from, setFrom] = (0, import_react.useState)("м");
	const [to, setTo] = (0, import_react.useState)("км");
	const [v, setV] = (0, import_react.useState)("1000");
	const table = UNITS[cat];
	let out = 0;
	const n = Number(v) || 0;
	if (cat === "Температура") {
		let c = n;
		if (from === "°F") c = (n - 32) * 5 / 9;
		if (from === "K") c = n - 273.15;
		if (to === "°C") out = c;
		if (to === "°F") out = c * 9 / 5 + 32;
		if (to === "K") out = c + 273.15;
	} else out = n * table[from] / table[to];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "app-pad",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				style: {
					display: "flex",
					gap: 6,
					marginBottom: 12
				},
				children: Object.keys(UNITS).map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: `os-btn ${cat === c ? "primary" : ""}`,
					onClick: () => {
						setCat(c);
						const k = Object.keys(UNITS[c]);
						setFrom(k[0]);
						setTo(k[1]);
					},
					children: c
				}, c))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				className: "os-input",
				value: v,
				onChange: (e) => setV(e.target.value),
				style: {
					width: "100%",
					marginBottom: 8
				}
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
					className: "os-select",
					value: from,
					onChange: (e) => setFrom(e.target.value),
					children: Object.keys(table).map((u) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: u }, u))
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
					className: "os-select",
					value: to,
					onChange: (e) => setTo(e.target.value),
					children: Object.keys(table).map((u) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: u }, u))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				style: {
					fontSize: 28,
					marginTop: 16
				},
				children: [
					Number.isFinite(out) ? out.toPrecision(8).replace(/\.?0+$/, "") : "—",
					" ",
					to
				]
			})
		]
	});
}
function PasswordApp() {
	const [len, setLen] = (0, import_react.useState)(16);
	const [pwd, setPwd] = (0, import_react.useState)("");
	const gen = () => {
		const abc = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*";
		const a = new Uint32Array(len);
		crypto.getRandomValues(a);
		setPwd([...a].map((n) => abc[n % 70]).join(""));
	};
	(0, import_react.useEffect)(() => {
		gen();
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "app-pad",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "card",
				style: {
					fontFamily: "var(--font-mono)",
					fontSize: 18,
					wordBreak: "break-all"
				},
				children: pwd
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				className: "os-range",
				type: "range",
				min: 8,
				max: 32,
				value: len,
				onChange: (e) => setLen(Number(e.target.value)),
				style: { margin: "16px 0" }
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "muted",
				children: [len, " символов"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				style: {
					display: "flex",
					gap: 8,
					marginTop: 12
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "os-btn primary",
					onClick: gen,
					children: "Сгенерировать"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "os-btn",
					onClick: () => navigator.clipboard.writeText(pwd),
					children: "Копировать"
				})]
			})
		]
	});
}
function ColorApp() {
	const [c, setC] = (0, import_react.useState)("#0a84ff");
	const rgb = hexToRgb(c);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "app-pad",
		style: { textAlign: "center" },
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { style: {
				height: 120,
				borderRadius: 14,
				background: c,
				marginBottom: 12,
				border: "1px solid var(--border)"
			} }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				type: "color",
				value: c,
				onChange: (e) => setC(e.target.value)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				style: {
					marginTop: 12,
					fontFamily: "var(--font-mono)"
				},
				children: c.toUpperCase()
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "muted",
				children: [
					"rgb(",
					rgb.join(", "),
					")"
				]
			})
		]
	});
}
function hexToRgb(h) {
	const n = parseInt(h.slice(1), 16);
	return [
		n >> 16 & 255,
		n >> 8 & 255,
		n & 255
	];
}
var MAP = {
	explorer: ExplorerApp,
	bank: BankApp,
	store: StoreApp,
	browser: BrowserApp,
	camera: CameraApp,
	clock: ClockApp,
	qr: QRApp,
	recorder: RecorderApp,
	notepad: NotepadApp,
	calculator: CalculatorApp,
	paint: PaintApp,
	music: MusicApp,
	photos: PhotosApp,
	terminal: TerminalApp,
	settings: SettingsApp,
	weather: WeatherApp,
	about: AboutApp,
	notes: NotesApp,
	taskmgr: TaskManagerApp,
	minesweeper: Minesweeper,
	snake: SnakeGame,
	game2048: Game2048,
	memory: MemoryGame,
	tictactoe: TicTacToe,
	converter: ConverterApp,
	passwords: PasswordApp,
	colors: ColorApp
};
function AppHost({ appId, winId }) {
	const C = MAP[appId];
	return C ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(C, { winId }) : null;
}
var HANDLES = [
	"n",
	"s",
	"e",
	"w",
	"ne",
	"nw",
	"se",
	"sw"
];
function zoneFromPoint(x, y) {
	if (y < 16) return "max";
	if (x < 16) return "left";
	if (x > window.innerWidth - 16) return "right";
	return null;
}
function WindowFrame({ win }) {
	const ref = (0, import_react.useRef)(null);
	const focusedId = useOS((s) => s.focusedId);
	const focusWin = useOS((s) => s.focusWin);
	const closeWin = useOS((s) => s.closeWin);
	const minimizeWin = useOS((s) => s.minimizeWin);
	const toggleMax = useOS((s) => s.toggleMax);
	const moveWin = useOS((s) => s.moveWin);
	const resizeWin = useOS((s) => s.resizeWin);
	const snapWin = useOS((s) => s.snapWin);
	const setSnap = useOS((s) => s.setSnap);
	const setContextMenu = useOS((s) => s.setContextMenu);
	const focused = focusedId === win.id;
	const def = APP_MAP[win.appId];
	(0, import_react.useEffect)(() => {
		const el = ref.current;
		if (el && focused) {
			if (el.querySelector("input,textarea,[data-autofocus]") && document.activeElement?.tagName !== "INPUT") {}
		}
	}, [focused]);
	if (win.minimized) return null;
	const onDrag = (e) => {
		if (e.button !== 0) return;
		if (e.target.closest(".win-btns")) return;
		focusWin(win.id);
		const startX = e.clientX;
		const startY = e.clientY;
		const orig = {
			x: win.x,
			y: win.y,
			w: win.w,
			h: win.h,
			max: win.maximized
		};
		const el = ref.current;
		e.currentTarget.setPointerCapture(e.pointerId);
		const move = (ev) => {
			const dx = ev.clientX - startX;
			const dy = ev.clientY - startY;
			if (orig.max && (Math.abs(dx) > 6 || Math.abs(dy) > 6)) {
				const nw = orig.w;
				const nx = clampX(ev.clientX - nw / 2, nw);
				const ny = 0;
				if (el) {
					el.style.left = `${nx}px`;
					el.style.top = `${ny}px`;
					el.style.width = `${nw}px`;
					el.style.height = `${orig.h}px`;
					el.classList.remove("max");
				}
				setSnap(zoneFromPoint(ev.clientX, ev.clientY));
				return;
			}
			const nx = orig.x + dx;
			const ny = orig.y + dy;
			if (el && !orig.max) {
				el.style.left = `${nx}px`;
				el.style.top = `${Math.max(0, ny)}px`;
			}
			setSnap(zoneFromPoint(ev.clientX, ev.clientY));
		};
		const up = (ev) => {
			e.currentTarget.releasePointerCapture(e.pointerId);
			window.removeEventListener("pointermove", move);
			window.removeEventListener("pointerup", up);
			const zone = zoneFromPoint(ev.clientX, ev.clientY);
			if (zone) {
				snapWin(win.id, zone);
				return;
			}
			const dx = ev.clientX - startX;
			const dy = ev.clientY - startY;
			if (orig.max) {
				const nw = orig.w;
				moveWin(win.id, clampX(ev.clientX - nw / 2, nw), 0);
			} else moveWin(win.id, orig.x + dx, Math.max(0, orig.y + dy));
		};
		window.addEventListener("pointermove", move);
		window.addEventListener("pointerup", up);
	};
	const onResize = (dir) => (e) => {
		if (e.button !== 0 || win.maximized) return;
		e.stopPropagation();
		focusWin(win.id);
		const sx = e.clientX;
		const sy = e.clientY;
		const o = {
			x: win.x,
			y: win.y,
			w: win.w,
			h: win.h
		};
		const minW = def.minW;
		const minH = def.minH;
		const move = (ev) => {
			let { x, y, w, h } = o;
			const dx = ev.clientX - sx;
			const dy = ev.clientY - sy;
			if (dir.includes("e")) w = o.w + dx;
			if (dir.includes("s")) h = o.h + dy;
			if (dir.includes("w")) {
				w = o.w - dx;
				x = o.x + dx;
				if (w < minW) {
					x = o.x + o.w - minW;
					w = minW;
				}
			}
			if (dir.includes("n")) {
				h = o.h - dy;
				y = o.y + dy;
				if (h < minH) {
					y = o.y + o.h - minH;
					h = minH;
				}
			}
			w = Math.max(minW, w);
			h = Math.max(minH, h);
			y = Math.max(0, y);
			const el = ref.current;
			if (el) {
				el.style.left = `${x}px`;
				el.style.top = `${y}px`;
				el.style.width = `${w}px`;
				el.style.height = `${h}px`;
			}
		};
		const up = (ev) => {
			window.removeEventListener("pointermove", move);
			window.removeEventListener("pointerup", up);
			let { x, y, w, h } = o;
			const dx = ev.clientX - sx;
			const dy = ev.clientY - sy;
			if (dir.includes("e")) w = o.w + dx;
			if (dir.includes("s")) h = o.h + dy;
			if (dir.includes("w")) {
				w = Math.max(minW, o.w - dx);
				x = o.x + o.w - w;
			}
			if (dir.includes("n")) {
				h = Math.max(minH, o.h - dy);
				y = o.y + o.h - h;
			}
			resizeWin(win.id, x, Math.max(0, y), Math.max(minW, w), Math.max(minH, h));
		};
		window.addEventListener("pointermove", move);
		window.addEventListener("pointerup", up);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		ref,
		className: `win ${focused ? "" : "dim"} ${win.maximized ? "max" : ""}`,
		style: {
			left: win.x,
			top: win.y,
			width: win.w,
			height: win.h,
			zIndex: win.z
		},
		onPointerDown: () => {
			if (!focused) focusWin(win.id);
		},
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "titlebar",
				onPointerDown: onDrag,
				onDoubleClick: () => toggleMax(win.id),
				onContextMenu: (e) => {
					e.preventDefault();
					e.stopPropagation();
					setContextMenu({
						x: e.clientX,
						y: e.clientY,
						payload: win.id,
						items: [
							{
								label: "Свернуть",
								action: "min"
							},
							{
								label: win.maximized ? "Восстановить" : "Развернуть",
								action: "max"
							},
							{
								sep: true,
								label: ""
							},
							{
								label: "Закрыть",
								action: "close",
								danger: true
							}
						]
					});
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						style: { fontSize: 14 },
						children: win.icon
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "t",
						children: win.title
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "win-btns",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								"aria-label": "Свернуть",
								onClick: () => minimizeWin(win.id),
								children: "—"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								"aria-label": "Развернуть",
								onClick: () => toggleMax(win.id),
								children: win.maximized ? "❐" : "▢"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "x",
								"aria-label": "Закрыть",
								onClick: () => closeWin(win.id),
								children: "✕"
							})
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "win-body",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppHost, {
					appId: win.appId,
					winId: win.id
				})
			}),
			!win.maximized && HANDLES.map((h) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: `handle ${h}`,
				onPointerDown: onResize(h)
			}, h))
		]
	});
}
function clampX(x, w) {
	return Math.max(0, Math.min(window.innerWidth - w, x));
}
function OSShell() {
	const [ready, setReady] = (0, import_react.useState)(false);
	const hydrate = useOS((s) => s.hydrate);
	const phase = useOS((s) => s.phase);
	(0, import_react.useEffect)(() => {
		hydrate();
		setReady(true);
	}, [hydrate]);
	(0, import_react.useEffect)(() => {
		const t = setInterval(() => useOS.getState().setNow(Date.now()), 1e3);
		return () => clearInterval(t);
	}, []);
	(0, import_react.useEffect)(() => {
		const onKey = (e) => {
			if (e.key === "Escape") useOS.getState().closeOverlays();
			if (e.key === "Meta" || e.ctrlKey && e.key === "Escape") {
				e.preventDefault();
				useOS.getState().toggleFlyout("start");
			}
		};
		const onDown = (e) => {
			const t = e.target;
			if (t.closest(".flyout") || t.closest(".taskbar") || t.closest(".ctx") || t.closest(".start-btn")) return;
			const st = useOS.getState();
			if (st.flyout || st.contextMenu) {
				st.setFlyout(null);
				st.setContextMenu(null);
			}
		};
		window.addEventListener("keydown", onKey);
		window.addEventListener("pointerdown", onDown);
		return () => {
			window.removeEventListener("keydown", onKey);
			window.removeEventListener("pointerdown", onDown);
		};
	}, []);
	(0, import_react.useEffect)(() => {
		applyChrome(useOS.getState().settings);
	}, []);
	if (!ready) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "os-root",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BootScreen, {})
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "os-root",
		children: [
			phase === "boot" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BootScreen, {}),
			phase === "lock" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LockScreen, {}),
			(phase === "desktop" || phase === "lock") && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DesktopStage, { visible: phase === "desktop" }),
			(phase === "shutdown" || phase === "restart" || phase === "sleep") && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PowerScreen, { mode: phase })
		]
	});
}
function DesktopStage({ visible }) {
	const windows = useOS((s) => s.windows);
	const settings = useOS((s) => s.settings);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		style: {
			position: "absolute",
			inset: 0,
			opacity: visible ? 1 : 0,
			pointerEvents: visible ? "auto" : "none"
		},
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "wallpaper",
				style: { ["--wallpaper"]: `url(${settings.wallpaper})` }
			}),
			settings.nightlight && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "night-veil" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "brightness-veil" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Desktop, {}),
			windows.map((w) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WindowFrame, { win: w }, w.id)),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SnapPreview, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Flyouts, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ContextMenuLayer, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toasts, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Taskbar, {})
		]
	});
}
function BootScreen() {
	const setPhase = useOS((s) => s.setPhase);
	(0, import_react.useEffect)(() => {
		const t = setTimeout(() => setPhase("lock"), 2500);
		return () => clearTimeout(t);
	}, [setPhase]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "boot",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "boot-logo",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OsLogo, {
					size: 72,
					glow: true
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "boot-spin" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "boot-caption",
				children: [
					"Запуск ",
					OS.name,
					"..."
				]
			})
		]
	});
}
function LockScreen() {
	const [leaving, setLeaving] = (0, import_react.useState)(false);
	const setPhase = useOS((s) => s.setPhase);
	const now = useOS((s) => s.now);
	const settings = useOS((s) => s.settings);
	const notify = useOS((s) => s.notify);
	const d = new Date(now);
	const hh = settings.clock24 ? String(d.getHours()).padStart(2, "0") : String((d.getHours() + 11) % 12 + 1).padStart(2, "0");
	const mm = String(d.getMinutes()).padStart(2, "0");
	const days = [
		"воскресенье",
		"понедельник",
		"вторник",
		"среда",
		"четверг",
		"пятница",
		"суббота"
	];
	const months = [
		"января",
		"февраля",
		"марта",
		"апреля",
		"мая",
		"июня",
		"июля",
		"августа",
		"сентября",
		"октября",
		"ноября",
		"декабря"
	];
	const unlock = () => {
		if (leaving) return;
		setLeaving(true);
		setTimeout(() => {
			setPhase("desktop");
			notify({
				icon: "✨",
				title: `Добро пожаловать в ${OS.name}`,
				body: `Сборка ${OS.build} · ${OS.author}`
			});
		}, 400);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: `lock ${leaving ? "fade-out" : ""}`,
		onClick: unlock,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "wallpaper",
				style: { ["--wallpaper"]: `url(${settings.wallpaper})` }
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "lock-veil" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "lock-clock",
				children: [
					hh,
					":",
					mm
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "lock-date",
				children: [
					days[d.getDay()],
					", ",
					d.getDate(),
					" ",
					months[d.getMonth()]
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "lock-hint",
				children: "Нажмите, чтобы войти"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "lock-weather",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "t",
					children: "+12°"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "c",
					children: "Москва · облачно"
				})]
			})
		]
	});
}
function PowerScreen({ mode }) {
	const setPhase = useOS((s) => s.setPhase);
	const [done, setDone] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		if (mode === "sleep") {
			const t = setTimeout(() => setPhase("lock"), 2e3);
			return () => clearTimeout(t);
		}
		if (mode === "restart") {
			const t = setTimeout(() => window.location.reload(), 2500);
			return () => clearTimeout(t);
		}
		const t = setTimeout(() => setDone(true), 5e3);
		return () => clearTimeout(t);
	}, [mode, setPhase]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "power-screen",
		onClick: () => {
			if (done) {
				setPhase("boot");
				setDone(false);
			}
		},
		children: [!done && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "boot-spin" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			style: {
				marginTop: 24,
				color: "rgba(255,255,255,.55)"
			},
			children: done ? "Питание выключено. Нажмите, чтобы включить." : mode === "sleep" ? "Переход в спящий режим..." : mode === "restart" ? "Перезагрузка..." : "Завершение работы..."
		})]
	});
}
var SplitComponent = OSShell;
//#endregion
export { SplitComponent as component };
