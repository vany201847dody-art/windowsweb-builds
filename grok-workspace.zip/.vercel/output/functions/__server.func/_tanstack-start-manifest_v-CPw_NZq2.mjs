//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-CPw_NZq2.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-C6G-cfCh.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-C6G-cfCh.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-BVmmo5T_.js"]
	}
} });
//#endregion
export { tsrStartManifest };
