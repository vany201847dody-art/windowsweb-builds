import { createFileRoute } from "@tanstack/react-router";
import { OSShell } from "@/os/OSShell";

export const Route = createFileRoute("/")({ component: OSShell });
