import { create } from "zustand";
import { APPS, APP_MAP, DEFAULT_DESKTOP, OS, PINNED, WALLPAPERS, type AppId } from "./config";
import type {
  ContextMenuState,
  Flyout,
  OsNotification,
  Phase,
  Settings,
  SnapZone,
  WinState,
} from "./types";
import { clamp, loadJson, saveJson, uid } from "@/lib/utils";

const SETTINGS_KEY = `${OS.storageKey}_settings`;

export const defaultSettings = (): Settings => ({
  theme: "dark",
  accent: "#0a84ff",
  wallpaper: WALLPAPERS[0].url,
  iconSize: "md",
  animations: true,
  volume: 70,
  brightness: 100,
  clock24: true,
  showSeconds: false,
  banners: true,
  cameraAllowed: true,
  micAllowed: true,
  wifi: true,
  bluetooth: true,
  airplane: false,
  nightlight: false,
  focus: false,
  recording: false,
  mouseSpeed: 10,
  pcName: OS.hostname,
  desktopPins: [...DEFAULT_DESKTOP],
  installed: [],
});

function loadSettings(): Settings {
  const d = defaultSettings();
  const loaded = loadJson<Settings>(SETTINGS_KEY, d);
  if (!Array.isArray(loaded.desktopPins) || loaded.desktopPins.length === 0) {
    loaded.desktopPins = [...DEFAULT_DESKTOP];
  }
  if (!Array.isArray(loaded.installed)) loaded.installed = [];
  return loaded;
}

export function applyChrome(s: Settings) {
  if (typeof document === "undefined") return;
  const root = document.documentElement;
  root.dataset.theme = s.theme;
  root.style.setProperty("--accent", s.accent);
  root.style.setProperty("--brightness", String(s.brightness / 100));
  root.classList.toggle("no-anim", !s.animations);
  root.style.colorScheme = s.theme;
}

type OSStore = {
  hydrated: boolean;
  phase: Phase;
  windows: WinState[];
  zTop: number;
  focusedId: string | null;
  selectedIcon: AppId | null;
  flyout: Flyout;
  notifications: OsNotification[];
  unread: number;
  toasts: OsNotification[];
  settings: Settings;
  contextMenu: ContextMenuState;
  snap: { zone: SnapZone };
  cascade: number;
  now: number;

  hydrate: () => void;
  setPhase: (p: Phase) => void;
  setNow: (n: number) => void;
  patchSettings: (p: Partial<Settings>) => void;
  openApp: (id: AppId) => void;
  closeWin: (id: string) => void;
  focusWin: (id: string) => void;
  minimizeWin: (id: string) => void;
  toggleMax: (id: string) => void;
  restoreWin: (id: string) => void;
  taskbarClick: (id: string) => void;
  moveWin: (id: string, x: number, y: number) => void;
  resizeWin: (id: string, x: number, y: number, w: number, h: number) => void;
  snapWin: (id: string, zone: SnapZone) => void;
  setSnap: (zone: SnapZone) => void;
  selectIcon: (id: AppId | null) => void;
  setFlyout: (f: Flyout) => void;
  toggleFlyout: (f: Exclude<Flyout, null>) => void;
  notify: (n: Omit<OsNotification, "id" | "time">) => void;
  clearNotifs: () => void;
  dismissToast: (id: string) => void;
  setContextMenu: (m: ContextMenuState) => void;
  closeOverlays: () => void;
  installApp: (id: AppId) => void;
  pinDesktop: (id: AppId) => void;
  unpinDesktop: (id: AppId) => void;
};

function persistSettings(s: Settings) {
  saveJson(SETTINGS_KEY, s);
}

function taskbarH() {
  return 48;
}

function defaultPos(defW: number, defH: number, cascade: number) {
  const vw = typeof window === "undefined" ? 1280 : window.innerWidth;
  const vh = typeof window === "undefined" ? 800 : window.innerHeight;
  const maxW = Math.min(defW, vw - 24);
  const maxH = Math.min(defH, vh - taskbarH() - 16);
  const mobile = vw < 800;
  if (mobile) {
    return { x: 0, y: 0, w: vw, h: vh - taskbarH(), maximized: true };
  }
  const x = clamp(80 + (cascade % 8) * 28, 8, Math.max(8, vw - maxW - 8));
  const y = clamp(48 + (cascade % 8) * 24, 8, Math.max(8, vh - taskbarH() - maxH - 8));
  return { x, y, w: maxW, h: maxH, maximized: false };
}

export const useOS = create<OSStore>((set, get) => ({
  hydrated: false,
  phase: "boot",
  windows: [],
  zTop: 10,
  focusedId: null,
  selectedIcon: null,
  flyout: null,
  notifications: [],
  unread: 0,
  toasts: [],
  settings: defaultSettings(),
  contextMenu: null,
  snap: { zone: null },
  cascade: 0,
  now: Date.now(),

  hydrate: () => {
    const s = loadSettings();
    applyChrome(s);
    set({ settings: s, hydrated: true });
  },

  setPhase: (phase) => set({ phase, flyout: null, contextMenu: null }),
  setNow: (now) => set({ now }),

  patchSettings: (p) => {
    const settings = { ...get().settings, ...p };
    persistSettings(settings);
    applyChrome(settings);
    set({ settings });
  },

  openApp: (appId) => {
    const def = APP_MAP[appId];
    if (!def) return;
    const existing = get().windows.find((w) => w.appId === appId);
    if (existing) {
      const z = get().zTop + 1;
      set({
        windows: get().windows.map((w) =>
          w.id === existing.id ? { ...w, minimized: false, z } : w,
        ),
        zTop: z,
        focusedId: existing.id,
        flyout: null,
        contextMenu: null,
      });
      return;
    }
    const pos = defaultPos(def.w, def.h, get().cascade);
    const z = get().zTop + 1;
    const win: WinState = {
      id: uid("win"),
      appId,
      title: def.name,
      icon: def.icon,
      x: pos.x,
      y: pos.y,
      w: pos.w,
      h: pos.h,
      z,
      minimized: false,
      maximized: pos.maximized,
    };
    set({
      windows: [...get().windows, win],
      zTop: z,
      focusedId: win.id,
      cascade: get().cascade + 1,
      flyout: null,
      contextMenu: null,
    });
  },

  closeWin: (id) => {
    const windows = get().windows.filter((w) => w.id !== id);
    const focusedId =
      get().focusedId === id
        ? windows.filter((w) => !w.minimized).sort((a, b) => b.z - a.z)[0]?.id ?? null
        : get().focusedId;
    set({ windows, focusedId, contextMenu: null });
  },

  focusWin: (id) => {
    const z = get().zTop + 1;
    set({
      windows: get().windows.map((w) => (w.id === id ? { ...w, z, minimized: false } : w)),
      zTop: z,
      focusedId: id,
      flyout: null,
      contextMenu: null,
    });
  },

  minimizeWin: (id) => {
    const rest = get()
      .windows.filter((w) => w.id !== id && !w.minimized)
      .sort((a, b) => b.z - a.z)[0];
    set({
      windows: get().windows.map((w) => (w.id === id ? { ...w, minimized: true } : w)),
      focusedId: rest?.id ?? null,
      contextMenu: null,
    });
  },

  toggleMax: (id) => {
    set({
      windows: get().windows.map((w) => {
        if (w.id !== id) return w;
        if (w.maximized) {
          const p = w.prev ?? { x: 80, y: 60, w: 720, h: 480 };
          return { ...w, maximized: false, ...p, prev: undefined };
        }
        return {
          ...w,
          maximized: true,
          prev: { x: w.x, y: w.y, w: w.w, h: w.h },
        };
      }),
      contextMenu: null,
    });
  },

  restoreWin: (id) => get().focusWin(id),

  taskbarClick: (id) => {
    const w = get().windows.find((x) => x.id === id);
    if (!w) return;
    if (w.minimized) get().focusWin(id);
    else if (get().focusedId === id) get().minimizeWin(id);
    else get().focusWin(id);
  },

  moveWin: (id, x, y) => {
    set({
      windows: get().windows.map((w) => (w.id === id ? { ...w, x, y, maximized: false } : w)),
    });
  },

  resizeWin: (id, x, y, w, h) => {
    const def = get().windows.find((x) => x.id === id);
    const app = def ? APP_MAP[def.appId] : undefined;
    const minW = app?.minW ?? 320;
    const minH = app?.minH ?? 240;
    set({
      windows: get().windows.map((win) =>
        win.id === id
          ? { ...win, x, y, w: Math.max(minW, w), h: Math.max(minH, h), maximized: false }
          : win,
      ),
    });
  },

  snapWin: (id, zone) => {
    const vw = window.innerWidth;
    const vh = window.innerHeight - taskbarH();
    set({
      windows: get().windows.map((w) => {
        if (w.id !== id) return w;
        const prev = w.maximized ? w.prev : { x: w.x, y: w.y, w: w.w, h: w.h };
        if (zone === "left") return { ...w, maximized: false, prev, x: 0, y: 0, w: Math.floor(vw / 2), h: vh };
        if (zone === "right")
          return { ...w, maximized: false, prev, x: Math.floor(vw / 2), y: 0, w: Math.ceil(vw / 2), h: vh };
        if (zone === "max") return { ...w, maximized: true, prev };
        return w;
      }),
      snap: { zone: null },
    });
  },

  setSnap: (zone) => set({ snap: { zone } }),

  selectIcon: (selectedIcon) => set({ selectedIcon }),

  setFlyout: (flyout) => set({ flyout, contextMenu: null }),
  toggleFlyout: (f) => set({ flyout: get().flyout === f ? null : f, contextMenu: null }),

  notify: (n) => {
    const item: OsNotification = { ...n, id: uid("nt"), time: Date.now() };
    const notifications = [item, ...get().notifications].slice(0, 8);
    const banners = get().settings.banners && !get().settings.focus;
    set({
      notifications,
      unread: get().unread + 1,
      toasts: banners ? [item, ...get().toasts].slice(0, 3) : get().toasts,
    });
    if (banners) {
      setTimeout(() => {
        set({ toasts: get().toasts.filter((t) => t.id !== item.id) });
      }, 4500);
    }
  },

  clearNotifs: () => set({ notifications: [], unread: 0 }),
  dismissToast: (id) => set({ toasts: get().toasts.filter((t) => t.id !== id) }),

  setContextMenu: (contextMenu) => set({ contextMenu, flyout: contextMenu ? null : get().flyout }),

  closeOverlays: () => set({ flyout: null, contextMenu: null }),

  installApp: (id) => {
    const s = get().settings;
    const installed = s.installed.includes(id) ? s.installed : [...s.installed, id];
    const desktopPins = s.desktopPins.includes(id) ? s.desktopPins : [...s.desktopPins, id];
    const settings = { ...s, installed, desktopPins };
    persistSettings(settings);
    set({ settings });
  },

  pinDesktop: (id) => {
    const s = get().settings;
    if (s.desktopPins.includes(id)) return;
    const settings = { ...s, desktopPins: [...s.desktopPins, id] };
    persistSettings(settings);
    set({ settings });
  },

  unpinDesktop: (id) => {
    const s = get().settings;
    const settings = { ...s, desktopPins: s.desktopPins.filter((x) => x !== id) };
    persistSettings(settings);
    set({ settings });
  },
}));

export function appById(id: AppId) {
  return APPS.find((a) => a.id === id)!;
}

export { PINNED };
