import { useEffect, useState } from "react";
import { OS } from "./config";
import { Desktop } from "./Desktop";
import { Flyouts, ContextMenuLayer, Toasts, SnapPreview } from "./Flyouts";
import { OsLogo } from "./Logo";
import { Taskbar } from "./Taskbar";
import { WindowFrame } from "./WindowFrame";
import { applyChrome, useOS } from "./store";

export function OSShell() {
  const [ready, setReady] = useState(false);
  const hydrate = useOS((s) => s.hydrate);
  const phase = useOS((s) => s.phase);

  useEffect(() => {
    hydrate();
    setReady(true);
  }, [hydrate]);

  useEffect(() => {
    const t = setInterval(() => useOS.getState().setNow(Date.now()), 1000);
    return () => clearInterval(t);
  }, []);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        useOS.getState().closeOverlays();
      }
      if (e.key === "Meta" || (e.ctrlKey && e.key === "Escape")) {
        e.preventDefault();
        useOS.getState().toggleFlyout("start");
      }
    };
    const onDown = (e: PointerEvent) => {
      const t = e.target as HTMLElement;
      if (t.closest(".flyout") || t.closest(".taskbar") || t.closest(".ctx") || t.closest(".start-btn")) return;
      const st = useOS.getState();
      if (st.flyout || st.contextMenu) {
        st.setFlyout(null);
        st.setContextMenu(null);
      }
    };
    window.addEventListener("keydown", onKey);
    window.addEventListener("pointerdown", onDown);
    return () => {
      window.removeEventListener("keydown", onKey);
      window.removeEventListener("pointerdown", onDown);
    };
  }, []);

  useEffect(() => {
    applyChrome(useOS.getState().settings);
  }, []);

  if (!ready) {
    return (
      <div className="os-root">
        <BootScreen />
      </div>
    );
  }

  return (
    <div className="os-root">
      {phase === "boot" && <BootScreen />}
      {phase === "lock" && <LockScreen />}
      {(phase === "desktop" || phase === "lock") && <DesktopStage visible={phase === "desktop"} />}
      {(phase === "shutdown" || phase === "restart" || phase === "sleep") && <PowerScreen mode={phase} />}
    </div>
  );
}

function DesktopStage({ visible }: { visible: boolean }) {
  const windows = useOS((s) => s.windows);
  const settings = useOS((s) => s.settings);

  return (
    <div style={{ position: "absolute", inset: 0, opacity: visible ? 1 : 0, pointerEvents: visible ? "auto" : "none" }}>
      <div className="wallpaper" style={{ ["--wallpaper" as string]: `url(${settings.wallpaper})` }} />
      {settings.nightlight && <div className="night-veil" />}
      <div className="brightness-veil" />
      <Desktop />
      {windows.map((w) => (
        <WindowFrame key={w.id} win={w} />
      ))}
      <SnapPreview />
      <Flyouts />
      <ContextMenuLayer />
      <Toasts />
      <Taskbar />
    </div>
  );
}

function BootScreen() {
  const setPhase = useOS((s) => s.setPhase);
  useEffect(() => {
    const t = setTimeout(() => setPhase("lock"), 2500);
    return () => clearTimeout(t);
  }, [setPhase]);
  return (
    <div className="boot">
      <div className="boot-logo">
        <OsLogo size={72} glow />
      </div>
      <div className="boot-spin" />
      <div className="boot-caption">Запуск {OS.name}...</div>
    </div>
  );
}

function LockScreen() {
  const [leaving, setLeaving] = useState(false);
  const setPhase = useOS((s) => s.setPhase);
  const now = useOS((s) => s.now);
  const settings = useOS((s) => s.settings);
  const notify = useOS((s) => s.notify);
  const d = new Date(now);
  const hh = settings.clock24
    ? String(d.getHours()).padStart(2, "0")
    : String(((d.getHours() + 11) % 12) + 1).padStart(2, "0");
  const mm = String(d.getMinutes()).padStart(2, "0");
  const days = ["воскресенье", "понедельник", "вторник", "среда", "четверг", "пятница", "суббота"];
  const months = ["января", "февраля", "марта", "апреля", "мая", "июня", "июля", "августа", "сентября", "октября", "ноября", "декабря"];

  const unlock = () => {
    if (leaving) return;
    setLeaving(true);
    setTimeout(() => {
      setPhase("desktop");
      notify({ icon: "✨", title: `Добро пожаловать в ${OS.name}`, body: `Сборка ${OS.build} · ${OS.author}` });
    }, 400);
  };

  return (
    <div className={`lock ${leaving ? "fade-out" : ""}`} onClick={unlock}>
      <div className="wallpaper" style={{ ["--wallpaper" as string]: `url(${settings.wallpaper})` }} />
      <div className="lock-veil" />
      <div className="lock-clock">
        {hh}:{mm}
      </div>
      <div className="lock-date">
        {days[d.getDay()]}, {d.getDate()} {months[d.getMonth()]}
      </div>
      <div className="lock-hint">Нажмите, чтобы войти</div>
      <div className="lock-weather">
        <div className="t">+12°</div>
        <div className="c">Москва · облачно</div>
      </div>
    </div>
  );
}

function PowerScreen({ mode }: { mode: "shutdown" | "restart" | "sleep" }) {
  const setPhase = useOS((s) => s.setPhase);
  const [done, setDone] = useState(false);

  useEffect(() => {
    if (mode === "sleep") {
      const t = setTimeout(() => setPhase("lock"), 2000);
      return () => clearTimeout(t);
    }
    if (mode === "restart") {
      const t = setTimeout(() => window.location.reload(), 2500);
      return () => clearTimeout(t);
    }
    const t = setTimeout(() => setDone(true), 5000);
    return () => clearTimeout(t);
  }, [mode, setPhase]);

  const label =
    mode === "sleep" ? "Переход в спящий режим..." : mode === "restart" ? "Перезагрузка..." : "Завершение работы...";

  return (
    <div
      className="power-screen"
      onClick={() => {
        if (done) {
          setPhase("boot");
          setDone(false);
        }
      }}
    >
      {!done && <div className="boot-spin" />}
      <div style={{ marginTop: 24, color: "rgba(255,255,255,.55)" }}>{done ? "Питание выключено. Нажмите, чтобы включить." : label}</div>
    </div>
  );
}
