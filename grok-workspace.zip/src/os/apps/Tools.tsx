import { useEffect, useRef, useState } from "react";
import { useOS } from "../store";

type QrKind = "text" | "url" | "phone" | "email" | "wifi" | "pay";

export function QRApp() {
  const [kind, setKind] = useState<QrKind>("text");
  const [text, setText] = useState("AetherOS");
  const [url, setUrl] = useState("https://aether.os");
  const [phone, setPhone] = useState("+79990000000");
  const [email, setEmail] = useState("vizor@aether.os");
  const [ssid, setSsid] = useState("Aether-5G");
  const [pass, setPass] = useState("secret");
  const [pay, setPay] = useState("1000");
  const canvas = useRef<HTMLCanvasElement>(null);

  const payload = () => {
    if (kind === "url") return url;
    if (kind === "phone") return `tel:${phone}`;
    if (kind === "email") return `mailto:${email}`;
    if (kind === "wifi") return `WIFI:S:${ssid};T:WPA;P:${pass};;`;
    if (kind === "pay") return `ST00012|Name=AetherBank|Sum=${Number(pay) * 100}|Purpose=Payment`;
    return text;
  };

  useEffect(() => {
    drawQR(canvas.current, payload());
  });

  return (
    <div className="app-pad scroll" style={{ textAlign: "center" }}>
      <div style={{ display: "flex", gap: 6, flexWrap: "wrap", justifyContent: "center", marginBottom: 12 }}>
        {(
          [
            ["text", "Текст"],
            ["url", "URL"],
            ["phone", "Телефон"],
            ["email", "Email"],
            ["wifi", "Wi-Fi"],
            ["pay", "Платёж"],
          ] as const
        ).map(([k, l]) => (
          <button key={k} type="button" className={`os-btn ${kind === k ? "primary" : ""}`} onClick={() => setKind(k)}>
            {l}
          </button>
        ))}
      </div>
      {kind === "text" && <input className="os-input" style={{ width: "100%" }} value={text} onChange={(e) => setText(e.target.value)} />}
      {kind === "url" && <input className="os-input" style={{ width: "100%" }} value={url} onChange={(e) => setUrl(e.target.value)} />}
      {kind === "phone" && <input className="os-input" style={{ width: "100%" }} value={phone} onChange={(e) => setPhone(e.target.value)} />}
      {kind === "email" && <input className="os-input" style={{ width: "100%" }} value={email} onChange={(e) => setEmail(e.target.value)} />}
      {kind === "wifi" && (
        <div className="grid-2">
          <input className="os-input" value={ssid} onChange={(e) => setSsid(e.target.value)} />
          <input className="os-input" value={pass} onChange={(e) => setPass(e.target.value)} />
        </div>
      )}
      {kind === "pay" && <input className="os-input" style={{ width: "100%" }} value={pay} onChange={(e) => setPay(e.target.value)} />}
      <canvas ref={canvas} width={250} height={250} style={{ margin: "16px auto", display: "block", background: "#fff", borderRadius: 12 }} />
      <div className="muted" style={{ wordBreak: "break-all" }}>
        {payload()}
      </div>
    </div>
  );
}

function drawQR(canvas: HTMLCanvasElement | null, text: string) {
  if (!canvas) return;
  const n = 25;
  const ctx = canvas.getContext("2d");
  if (!ctx) return;
  const cell = canvas.width / n;
  ctx.fillStyle = "#fff";
  ctx.fillRect(0, 0, canvas.width, canvas.height);
  const grid = Array.from({ length: n }, () => Array(n).fill(false));
  const finder = (x: number, y: number) => {
    for (let i = 0; i < 7; i++)
      for (let j = 0; j < 7; j++) {
        const edge = i === 0 || i === 6 || j === 0 || j === 6;
        const inner = i >= 2 && i <= 4 && j >= 2 && j <= 4;
        grid[y + i][x + j] = edge || inner;
      }
  };
  finder(0, 0);
  finder(18, 0);
  finder(0, 18);
  let h = 2166136261;
  for (const c of text) {
    h ^= c.charCodeAt(0);
    h = Math.imul(h, 16777619);
  }
  let bit = h >>> 0;
  for (let y = 0; y < n; y++)
    for (let x = 0; x < n; x++) {
      const reserved = (x < 8 && y < 8) || (x > 16 && y < 8) || (x < 8 && y > 16) || y === 6 || x === 6;
      if (reserved) continue;
      bit = (Math.imul(bit, 1103515245) + 12345) >>> 0;
      grid[y][x] = (bit & 0x100) !== 0;
    }
  for (let i = 0; i < n; i++) {
    grid[6][i] = i % 2 === 0;
    grid[i][6] = i % 2 === 0;
  }
  finder(0, 0);
  finder(18, 0);
  finder(0, 18);
  ctx.fillStyle = "#111";
  for (let y = 0; y < n; y++)
    for (let x = 0; x < n; x++) if (grid[y][x]) ctx.fillRect(x * cell, y * cell, cell, cell);
}

export function RecorderApp() {
  const [rec, setRec] = useState(false);
  const [t, setT] = useState(0);
  const [clips, setClips] = useState<{ id: string; url: string; dur: number; size: number }[]>([]);
  const recRef = useRef<MediaRecorder | null>(null);
  const chunks = useRef<Blob[]>([]);
  const notify = useOS((s) => s.notify);
  const allowed = useOS((s) => s.settings.micAllowed);

  useEffect(() => {
    if (!rec) return;
    const i = setInterval(() => setT((x) => x + 1), 1000);
    return () => clearInterval(i);
  }, [rec]);

  const toggle = async () => {
    if (rec) {
      recRef.current?.stop();
      setRec(false);
      return;
    }
    if (!allowed) {
      notify({ icon: "🎤", title: "Диктофон", body: "Микрофон отключён в параметрах" });
      return;
    }
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mr = new MediaRecorder(stream);
      chunks.current = [];
      mr.ondataavailable = (e) => e.data.size && chunks.current.push(e.data);
      mr.onstop = () => {
        stream.getTracks().forEach((tr) => tr.stop());
        const blob = new Blob(chunks.current, { type: mr.mimeType || "audio/webm" });
        const url = URL.createObjectURL(blob);
        setClips((c) => [{ id: String(Date.now()), url, dur: t, size: blob.size }, ...c]);
      };
      mr.start();
      recRef.current = mr;
      setT(0);
      setRec(true);
    } catch {
      notify({ icon: "🎤", title: "Диктофон", body: "Нет доступа к микрофону" });
    }
  };

  return (
    <div className="app-pad scroll" style={{ textAlign: "center" }}>
      <button
        type="button"
        onClick={toggle}
        style={{
          width: 96,
          height: 96,
          borderRadius: 99,
          border: "none",
          background: rec ? "var(--danger)" : "var(--accent)",
          color: "#fff",
          fontSize: 32,
          boxShadow: rec ? "0 0 0 12px color-mix(in srgb, var(--danger) 25%, transparent)" : undefined,
          animation: rec ? "pulse 1.2s ease-in-out infinite" : undefined,
        }}
      >
        {rec ? "■" : "●"}
      </button>
      <div style={{ fontSize: 28, margin: "12px 0", fontVariantNumeric: "tabular-nums" }}>
        {String(Math.floor(t / 60)).padStart(2, "0")}:{String(t % 60).padStart(2, "0")}
      </div>
      {clips.map((c) => (
        <div key={c.id} className="card" style={{ marginBottom: 8, textAlign: "left" }}>
          <audio controls src={c.url} style={{ width: "100%" }} />
          <div className="muted" style={{ display: "flex", justifyContent: "space-between" }}>
            <span>{(c.size / 1024).toFixed(1)} КБ</span>
            <a href={c.url} download="record.webm">
              Скачать
            </a>
          </div>
        </div>
      ))}
    </div>
  );
}

const UNITS: Record<string, Record<string, number>> = {
  Длина: { м: 1, км: 1000, см: 0.01, миля: 1609.34, фут: 0.3048 },
  Масса: { кг: 1, г: 0.001, фунт: 0.453592, т: 1000 },
  Температура: { "°C": 1, "°F": 1, K: 1 },
};

export function ConverterApp() {
  const [cat, setCat] = useState("Длина");
  const [from, setFrom] = useState("м");
  const [to, setTo] = useState("км");
  const [v, setV] = useState("1000");
  const table = UNITS[cat];
  let out = 0;
  const n = Number(v) || 0;
  if (cat === "Температура") {
    let c = n;
    if (from === "°F") c = ((n - 32) * 5) / 9;
    if (from === "K") c = n - 273.15;
    if (to === "°C") out = c;
    if (to === "°F") out = (c * 9) / 5 + 32;
    if (to === "K") out = c + 273.15;
  } else out = (n * table[from]) / table[to];
  return (
    <div className="app-pad">
      <div style={{ display: "flex", gap: 6, marginBottom: 12 }}>
        {Object.keys(UNITS).map((c) => (
          <button key={c} type="button" className={`os-btn ${cat === c ? "primary" : ""}`} onClick={() => { setCat(c); const k = Object.keys(UNITS[c]); setFrom(k[0]); setTo(k[1]); }}>
            {c}
          </button>
        ))}
      </div>
      <input className="os-input" value={v} onChange={(e) => setV(e.target.value)} style={{ width: "100%", marginBottom: 8 }} />
      <div className="grid-2">
        <select className="os-select" value={from} onChange={(e) => setFrom(e.target.value)}>
          {Object.keys(table).map((u) => <option key={u}>{u}</option>)}
        </select>
        <select className="os-select" value={to} onChange={(e) => setTo(e.target.value)}>
          {Object.keys(table).map((u) => <option key={u}>{u}</option>)}
        </select>
      </div>
      <div style={{ fontSize: 28, marginTop: 16 }}>{Number.isFinite(out) ? out.toPrecision(8).replace(/\.?0+$/, "") : "—"} {to}</div>
    </div>
  );
}

export function PasswordApp() {
  const [len, setLen] = useState(16);
  const [pwd, setPwd] = useState("");
  const gen = () => {
    const abc = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*";
    const a = new Uint32Array(len);
    crypto.getRandomValues(a);
    setPwd([...a].map((n) => abc[n % abc.length]).join(""));
  };
  useEffect(() => { gen(); }, []);
  return (
    <div className="app-pad">
      <div className="card" style={{ fontFamily: "var(--font-mono)", fontSize: 18, wordBreak: "break-all" }}>{pwd}</div>
      <input className="os-range" type="range" min={8} max={32} value={len} onChange={(e) => setLen(Number(e.target.value))} style={{ margin: "16px 0" }} />
      <div className="muted">{len} символов</div>
      <div style={{ display: "flex", gap: 8, marginTop: 12 }}>
        <button type="button" className="os-btn primary" onClick={gen}>Сгенерировать</button>
        <button type="button" className="os-btn" onClick={() => navigator.clipboard.writeText(pwd)}>Копировать</button>
      </div>
    </div>
  );
}

export function ColorApp() {
  const [c, setC] = useState("#0a84ff");
  const rgb = hexToRgb(c);
  return (
    <div className="app-pad" style={{ textAlign: "center" }}>
      <div style={{ height: 120, borderRadius: 14, background: c, marginBottom: 12, border: "1px solid var(--border)" }} />
      <input type="color" value={c} onChange={(e) => setC(e.target.value)} />
      <div style={{ marginTop: 12, fontFamily: "var(--font-mono)" }}>{c.toUpperCase()}</div>
      <div className="muted">rgb({rgb.join(", ")})</div>
    </div>
  );
}

function hexToRgb(h: string) {
  const n = parseInt(h.slice(1), 16);
  return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
}
