import { useEffect, useRef, useState } from "react";
import { useOS } from "../store";

export function Minesweeper() {
  const W = 9;
  const H = 9;
  const M = 10;
  const [board, setBoard] = useState(() => makeBoard(W, H, M));
  const [dead, setDead] = useState(false);
  const [won, setWon] = useState(false);
  const notify = useOS((s) => s.notify);

  const uncover = (i: number) => {
    if (dead || won) return;
    setBoard((b) => {
      const next = b.map((c) => ({ ...c }));
      if (next[i].flag || next[i].open) return b;
      if (next[i].mine) {
        next.forEach((c) => {
          if (c.mine) c.open = true;
        });
        setDead(true);
        notify({ icon: "💣", title: "Сапёр", body: "Поражение" });
        return next;
      }
      const stack = [i];
      while (stack.length) {
        const cur = stack.pop()!;
        if (next[cur].open || next[cur].flag) continue;
        next[cur].open = true;
        if (next[cur].n === 0) {
          for (const nb of neigh(cur, W, H)) if (!next[nb].open && !next[nb].mine) stack.push(nb);
        }
      }
      const win = next.every((c) => c.mine || c.open);
      if (win) {
        setWon(true);
        notify({ icon: "🏆", title: "Сапёр", body: "Победа" });
      }
      return next;
    });
  };

  const flag = (i: number, e: React.MouseEvent) => {
    e.preventDefault();
    if (dead || won) return;
    setBoard((b) => b.map((c, idx) => (idx === i && !c.open ? { ...c, flag: !c.flag } : c)));
  };

  return (
    <div className="app-pad" style={{ textAlign: "center" }}>
      <div className="muted" style={{ marginBottom: 8 }}>
        {dead ? "Поражение" : won ? "Победа" : `Мины: ${M - board.filter((c) => c.flag).length}`}
      </div>
      <div style={{ display: "grid", gridTemplateColumns: `repeat(${W}, 32px)`, gap: 2, justifyContent: "center" }}>
        {board.map((c, i) => (
          <button
            key={i}
            type="button"
            onClick={() => uncover(i)}
            onContextMenu={(e) => flag(i, e)}
            style={{
              width: 32,
              height: 32,
              border: "none",
              borderRadius: 4,
              background: c.open ? "var(--hover)" : "var(--panel-solid)",
              color: c.mine && c.open ? "var(--danger)" : "var(--fg)",
              fontWeight: 700,
            }}
          >
            {c.open ? (c.mine ? "💣" : c.n || "") : c.flag ? "⚑" : ""}
          </button>
        ))}
      </div>
      <button
        type="button"
        className="os-btn"
        style={{ marginTop: 12 }}
        onClick={() => {
          setBoard(makeBoard(W, H, M));
          setDead(false);
          setWon(false);
        }}
      >
        Заново
      </button>
    </div>
  );
}

type Cell = { mine: boolean; open: boolean; flag: boolean; n: number };

function neigh(i: number, W: number, H: number) {
  const x = i % W;
  const y = Math.floor(i / W);
  const out: number[] = [];
  for (let dy = -1; dy <= 1; dy++)
    for (let dx = -1; dx <= 1; dx++) {
      if (!dx && !dy) continue;
      const nx = x + dx;
      const ny = y + dy;
      if (nx >= 0 && nx < W && ny >= 0 && ny < H) out.push(ny * W + nx);
    }
  return out;
}

function makeBoard(W: number, H: number, M: number): Cell[] {
  const cells: Cell[] = Array.from({ length: W * H }, () => ({ mine: false, open: false, flag: false, n: 0 }));
  let m = 0;
  while (m < M) {
    const i = Math.floor(Math.random() * cells.length);
    if (cells[i].mine) continue;
    cells[i].mine = true;
    m++;
  }
  cells.forEach((c, i) => {
    c.n = neigh(i, W, H).filter((n) => cells[n].mine).length;
  });
  return cells;
}

export function SnakeGame() {
  const canvas = useRef<HTMLCanvasElement>(null);
  const [score, setScore] = useState(0);
  const [over, setOver] = useState(false);
  const dir = useRef({ x: 1, y: 0 });
  const next = useRef({ x: 1, y: 0 });

  const [runId, setRunId] = useState(0);

  useEffect(() => {
    const c = canvas.current;
    if (!c) return;
    const ctx = c.getContext("2d")!;
    const N = 20;
    const cell = 18;
    c.width = N * cell;
    c.height = N * cell;
    let snake = [
      { x: 8, y: 10 },
      { x: 7, y: 10 },
      { x: 6, y: 10 },
    ];
    let food = { x: 14, y: 10 };
    let acc = 0;
    let last = performance.now();
    let dead = false;
    let sc = 0;
    const onKey = (e: KeyboardEvent) => {
      const k = e.key;
      const d = next.current;
      if (k === "ArrowUp" && dir.current.y !== 1) {
        d.x = 0;
        d.y = -1;
      }
      if (k === "ArrowDown" && dir.current.y !== -1) {
        d.x = 0;
        d.y = 1;
      }
      if (k === "ArrowLeft" && dir.current.x !== 1) {
        d.x = -1;
        d.y = 0;
      }
      if (k === "ArrowRight" && dir.current.x !== -1) {
        d.x = 1;
        d.y = 0;
      }
      if (k.startsWith("Arrow")) e.preventDefault();
    };
    window.addEventListener("keydown", onKey);
    let raf = 0;
    const loop = (now: number) => {
      const dt = Math.min(0.1, (now - last) / 1000);
      last = now;
      acc += dt;
      const step = 0.12;
      while (acc >= step && !dead) {
        acc -= step;
        dir.current = { ...next.current };
        const h = { x: snake[0].x + dir.current.x, y: snake[0].y + dir.current.y };
        if (h.x < 0 || h.y < 0 || h.x >= N || h.y >= N || snake.some((s) => s.x === h.x && s.y === h.y)) {
          dead = true;
          setOver(true);
          break;
        }
        snake = [h, ...snake];
        if (h.x === food.x && h.y === food.y) {
          sc += 10;
          setScore(sc);
          food = { x: Math.floor(Math.random() * N), y: Math.floor(Math.random() * N) };
        } else snake.pop();
      }
      ctx.fillStyle = "#111";
      ctx.fillRect(0, 0, c.width, c.height);
      ctx.fillStyle = "#30d158";
      snake.forEach((s, idx) => {
        ctx.globalAlpha = idx === 0 ? 1 : 0.75;
        ctx.fillRect(s.x * cell + 1, s.y * cell + 1, cell - 2, cell - 2);
      });
      ctx.globalAlpha = 1;
      ctx.fillStyle = "#ff453a";
      ctx.fillRect(food.x * cell + 2, food.y * cell + 2, cell - 4, cell - 4);
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener("keydown", onKey);
    };
  }, [runId]);

  return (
    <div className="app-pad" style={{ textAlign: "center" }}>
      <div className="muted">Счёт {score} {over ? "· конец. Нажмите «Заново»" : ""}</div>
      <canvas ref={canvas} style={{ margin: "8px auto", display: "block", borderRadius: 8 }} />
      {over && (
        <button type="button" className="os-btn primary" onClick={() => { setScore(0); setOver(false); dir.current = { x: 1, y: 0 }; next.current = { x: 1, y: 0 }; setRunId((n) => n + 1); }}>
          Заново
        </button>
      )}
    </div>
  );
}

export function Game2048() {
  const empty = () => Array.from({ length: 16 }, () => 0);
  const spawn = (b: number[]) => {
    const free = b.map((v, i) => (v === 0 ? i : -1)).filter((i) => i >= 0);
    if (!free.length) return b;
    const i = free[Math.floor(Math.random() * free.length)];
    const n = [...b];
    n[i] = Math.random() < 0.9 ? 2 : 4;
    return n;
  };
  const [board, setBoard] = useState(() => spawn(spawn(empty())));
  const [score, setScore] = useState(0);

  const slide = (row: number[]) => {
    const a = row.filter((x) => x);
    let s = 0;
    for (let i = 0; i < a.length - 1; i++) {
      if (a[i] === a[i + 1]) {
        a[i] *= 2;
        s += a[i];
        a[i + 1] = 0;
      }
    }
    const m = a.filter((x) => x);
    while (m.length < 4) m.push(0);
    return { row: m, s };
  };

  const move = (dir: "L" | "R" | "U" | "D") => {
    const g = [...board];
    let add = 0;
    const get = (r: number, c: number) => g[r * 4 + c];
    const set = (r: number, c: number, v: number) => (g[r * 4 + c] = v);
    if (dir === "L" || dir === "R") {
      for (let r = 0; r < 4; r++) {
        let row = [0, 1, 2, 3].map((c) => get(r, c));
        if (dir === "R") row.reverse();
        const res = slide(row);
        if (dir === "R") res.row.reverse();
        res.row.forEach((v, c) => set(r, c, v));
        add += res.s;
      }
    } else {
      for (let c = 0; c < 4; c++) {
        let col = [0, 1, 2, 3].map((r) => get(r, c));
        if (dir === "D") col.reverse();
        const res = slide(col);
        if (dir === "D") res.row.reverse();
        res.row.forEach((v, r) => set(r, c, v));
        add += res.s;
      }
    }
    if (g.some((v, i) => v !== board[i])) {
      setBoard(spawn(g));
      setScore((s) => s + add);
    }
  };

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const map: Record<string, "L" | "R" | "U" | "D"> = {
        ArrowLeft: "L",
        ArrowRight: "R",
        ArrowUp: "U",
        ArrowDown: "D",
      };
      if (map[e.key]) {
        e.preventDefault();
        move(map[e.key]);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  });

  return (
    <div className="app-pad" style={{ textAlign: "center" }}>
      <div style={{ marginBottom: 8 }}>Счёт {score}</div>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 70px)", gap: 6, justifyContent: "center" }}>
        {board.map((v, i) => (
          <div
            key={i}
            style={{
              height: 70,
              borderRadius: 8,
              display: "grid",
              placeItems: "center",
              background: v ? `color-mix(in srgb, var(--accent) ${Math.min(90, Math.log2(v) * 10)}%, var(--hover))` : "var(--hover)",
              fontWeight: 700,
              fontSize: v > 512 ? 16 : 20,
            }}
          >
            {v || ""}
          </div>
        ))}
      </div>
      <button type="button" className="os-btn" style={{ marginTop: 12 }} onClick={() => { setBoard(spawn(spawn(empty()))); setScore(0); }}>
        Заново
      </button>
    </div>
  );
}

const PAIRS = ["▲", "●", "■", "◆", "★", "✦", "⬡", "♥"];

export function MemoryGame() {
  const shuffle = () =>
    [...PAIRS, ...PAIRS]
      .map((v) => ({ v, k: Math.random() }))
      .sort((a, b) => a.k - b.k)
      .map((x, i) => ({ id: i, v: x.v, open: false, done: false }));
  const [cards, setCards] = useState(shuffle);
  const [sel, setSel] = useState<number[]>([]);
  const [moves, setMoves] = useState(0);
  const [t, setT] = useState(0);
  const [run, setRun] = useState(false);
  const notify = useOS((s) => s.notify);

  useEffect(() => {
    if (!run) return;
    const i = setInterval(() => setT((x) => x + 1), 1000);
    return () => clearInterval(i);
  }, [run]);

  const click = (i: number) => {
    if (cards[i].open || cards[i].done || sel.length === 2) return;
    if (!run) setRun(true);
    const nextSel = [...sel, i];
    const next = cards.map((c, idx) => (idx === i ? { ...c, open: true } : c));
    setCards(next);
    setSel(nextSel);
    if (nextSel.length === 2) {
      setMoves((m) => m + 1);
      const [a, b] = nextSel;
      if (next[a].v === next[b].v) {
        setTimeout(() => {
          setCards((c) => c.map((x, idx) => (idx === a || idx === b ? { ...x, done: true } : x)));
          setSel([]);
          if (next.filter((x) => x.done).length + 2 === next.length) {
            setRun(false);
            notify({ icon: "🧠", title: "Память", body: `Готово за ${moves + 1} ходов` });
          }
        }, 350);
      } else {
        setTimeout(() => {
          setCards((c) => c.map((x, idx) => (idx === a || idx === b ? { ...x, open: false } : x)));
          setSel([]);
        }, 700);
      }
    }
  };

  return (
    <div className="app-pad" style={{ textAlign: "center" }}>
      <div className="muted">
        Ходы {moves} · {t} с
      </div>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 64px)", gap: 8, justifyContent: "center", marginTop: 10 }}>
        {cards.map((c, i) => (
          <button
            key={c.id}
            type="button"
            onClick={() => click(i)}
            style={{
              height: 64,
              borderRadius: 10,
              border: "none",
              background: c.open || c.done ? "var(--accent)" : "var(--hover)",
              color: "#fff",
              fontSize: 22,
            }}
          >
            {c.open || c.done ? c.v : ""}
          </button>
        ))}
      </div>
      <button
        type="button"
        className="os-btn"
        style={{ marginTop: 12 }}
        onClick={() => {
          setCards(shuffle());
          setSel([]);
          setMoves(0);
          setT(0);
          setRun(false);
        }}
      >
        Заново
      </button>
    </div>
  );
}

export function TicTacToe() {
  const [b, setB] = useState<(null | "X" | "O")[]>(Array(9).fill(null));
  const [lock, setLock] = useState(false);
  const notify = useOS((s) => s.notify);
  const winner = win(b);

  const play = (i: number) => {
    if (b[i] || winner || lock) return;
    const next = [...b];
    next[i] = "X";
    const w = win(next);
    setB(next);
    if (w) {
      notify({ icon: "⭕", title: "Крестики-нолики", body: w === "X" ? "Вы победили" : w === "O" ? "ИИ победил" : "Ничья" });
      return;
    }
    setLock(true);
    setTimeout(() => {
      const ai = aiMove(next);
      if (ai >= 0) next[ai] = "O";
      setB([...next]);
      const w2 = win(next);
      if (w2) notify({ icon: "⭕", title: "Крестики-нолики", body: w2 === "O" ? "ИИ победил" : "Ничья" });
      setLock(false);
    }, 280);
  };

  return (
    <div className="app-pad" style={{ textAlign: "center" }}>
      <div className="muted">{winner ? (winner === "D" ? "Ничья" : `Победил ${winner}`) : "Ваш ход · крестики"}</div>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 72px)", gap: 8, justifyContent: "center", margin: 12 }}>
        {b.map((c, i) => (
          <button
            key={i}
            type="button"
            onClick={() => play(i)}
            style={{ height: 72, borderRadius: 12, border: "1px solid var(--border)", background: "var(--hover)", fontSize: 28 }}
          >
            {c ?? ""}
          </button>
        ))}
      </div>
      <button type="button" className="os-btn" onClick={() => { setB(Array(9).fill(null)); setLock(false); }}>
        Заново
      </button>
    </div>
  );
}

function win(b: (null | "X" | "O")[]) {
  const lines = [
    [0, 1, 2],
    [3, 4, 5],
    [6, 7, 8],
    [0, 3, 6],
    [1, 4, 7],
    [2, 5, 8],
    [0, 4, 8],
    [2, 4, 6],
  ];
  for (const [a, c, d] of lines) if (b[a] && b[a] === b[c] && b[a] === b[d]) return b[a];
  if (b.every(Boolean)) return "D";
  return null;
}

function aiMove(b: (null | "X" | "O")[]) {
  const tryWin = (p: "X" | "O") => {
    for (let i = 0; i < 9; i++) {
      if (b[i]) continue;
      const t = [...b];
      t[i] = p;
      if (win(t) === p) return i;
    }
    return -1;
  };
  const w = tryWin("O");
  if (w >= 0) return w;
  const bl = tryWin("X");
  if (bl >= 0) return bl;
  if (!b[4]) return 4;
  const corners = [0, 2, 6, 8].filter((i) => !b[i]);
  if (corners.length) return corners[Math.floor(Math.random() * corners.length)];
  const rest = b.map((v, i) => (v ? -1 : i)).filter((i) => i >= 0);
  return rest[0] ?? -1;
}
