import { useEffect, useRef, useState } from "react";
import { useOS } from "../store";

const TRACKS = [
  { title: "Night Drive", artist: "Aether", color: "#1d4ed8", seq: [220, 277, 330, 440] },
  { title: "Glass Rain", artist: "Vizor", color: "#0f766e", seq: [196, 247, 294, 392] },
  { title: "Northern Lights", artist: "Aurora", color: "#6d28d9", seq: [164, 196, 246, 329] },
];

export function MusicApp() {
  const [i, setI] = useState(0);
  const [play, setPlay] = useState(false);
  const [prog, setProg] = useState(0);
  const [dur] = useState(32);
  const canvas = useRef<HTMLCanvasElement>(null);
  const ctxRef = useRef<AudioContext | null>(null);
  const volume = useOS((s) => s.settings.volume);
  const t = TRACKS[i];

  useEffect(() => {
    if (!play) return;
    const AC = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    const ac = ctxRef.current ?? new AC();
    ctxRef.current = ac;
    ac.resume();
    let stop = false;
    let step = 0;
    const gain = ac.createGain();
    gain.gain.value = volume / 100 * 0.08;
    const analyser = ac.createAnalyser();
    analyser.fftSize = 64;
    gain.connect(analyser);
    analyser.connect(ac.destination);
    const osc = ac.createOscillator();
    osc.type = "sine";
    osc.frequency.value = t.seq[0];
    osc.connect(gain);
    osc.start();
    const id = setInterval(() => {
      step = (step + 1) % t.seq.length;
      osc.frequency.setTargetAtTime(t.seq[step], ac.currentTime, 0.05);
    }, 280);
    const data = new Uint8Array(analyser.frequencyBinCount);
    const loop = () => {
      if (stop) return;
      const c = canvas.current;
      const g = c?.getContext("2d");
      if (c && g) {
        analyser.getByteFrequencyData(data);
        g.clearRect(0, 0, c.width, c.height);
        const w = c.width / data.length;
        g.fillStyle = "#fff";
        data.forEach((v, idx) => {
          const h = (v / 255) * c.height;
          g.globalAlpha = 0.85;
          g.fillRect(idx * w + 1, c.height - h, w - 2, h);
        });
      }
      requestAnimationFrame(loop);
    };
    loop();
    const tick = setInterval(() => {
      setProg((p) => {
        if (p >= dur) {
          setI((x) => (x + 1) % TRACKS.length);
          return 0;
        }
        return p + 0.25;
      });
    }, 250);
    return () => {
      stop = true;
      clearInterval(id);
      clearInterval(tick);
      osc.stop();
      osc.disconnect();
    };
  }, [play, i, volume, t.seq, dur]);

  return (
    <div className="app-pad" style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 12 }}>
      <div style={{ width: 220, height: 220, borderRadius: 18, background: `linear-gradient(145deg, ${t.color}, #111)`, display: "grid", placeItems: "center" }}>
        <canvas ref={canvas} width={180} height={80} />
      </div>
      <div style={{ fontSize: 20, fontWeight: 600 }}>{t.title}</div>
      <div className="muted">{t.artist}</div>
      <input className="os-range" type="range" min={0} max={dur} value={prog} onChange={(e) => setProg(Number(e.target.value))} />
      <div className="muted" style={{ fontVariantNumeric: "tabular-nums" }}>
        {fmt(prog)} / {fmt(dur)}
      </div>
      <div style={{ display: "flex", gap: 10 }}>
        <button type="button" className="os-btn" onClick={() => { setI((x) => (x + TRACKS.length - 1) % TRACKS.length); setProg(0); }}>
          ⏮
        </button>
        <button type="button" className="os-btn primary" onClick={() => setPlay(!play)}>
          {play ? "⏸" : "▶"}
        </button>
        <button type="button" className="os-btn" onClick={() => { setI((x) => (x + 1) % TRACKS.length); setProg(0); }}>
          ⏭
        </button>
      </div>
    </div>
  );
}

function fmt(s: number) {
  return `${Math.floor(s / 60)}:${String(Math.floor(s % 60)).padStart(2, "0")}`;
}

const PHOTOS = [
  ["#0ea5e9", "#1d4ed8"],
  ["#f59e0b", "#b45309"],
  ["#34d399", "#065f46"],
  ["#f472b6", "#9d174d"],
  ["#818cf8", "#312e81"],
  ["#fb923c", "#7c2d12"],
  ["#22d3ee", "#155e75"],
  ["#a3e635", "#3f6212"],
  ["#e879f9", "#6b21a8"],
  ["#facc15", "#854d0e"],
  ["#94a3b8", "#1e293b"],
  ["#f43f5e", "#881337"],
];

export function PhotosApp() {
  const notify = useOS((s) => s.notify);
  return (
    <div className="app-pad scroll">
      <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 8 }}>
        {PHOTOS.map((g, i) => (
          <button
            key={i}
            type="button"
            style={{ aspectRatio: "1", borderRadius: 10, border: "none", background: `linear-gradient(135deg, ${g[0]}, ${g[1]})` }}
            onClick={() => notify({ icon: "🖼️", title: "Фотографии", body: `Снимок ${i + 1} · локальный альбом` })}
          />
        ))}
      </div>
    </div>
  );
}

const DAYS = [
  { d: "Сегодня", icon: "☁️", t: 12, n: 6 },
  { d: "Вт", icon: "🌦️", t: 10, n: 4 },
  { d: "Ср", icon: "🌧️", t: 8, n: 3 },
  { d: "Чт", icon: "⛅", t: 11, n: 5 },
  { d: "Пт", icon: "☀️", t: 14, n: 7 },
];

export function WeatherApp() {
  return (
    <div className="app-pad">
      <div className="muted">Москва</div>
      <div style={{ fontSize: 56, fontWeight: 200 }}>+12°</div>
      <div>Облачно · ощущается как +9°</div>
      <div className="grid-2" style={{ margin: "14px 0" }}>
        <div className="card">Влажность 72%</div>
        <div className="card">Ветер 4 м/с</div>
      </div>
      <div className="grid-3">
        {DAYS.map((x) => (
          <div key={x.d} className="card" style={{ textAlign: "center" }}>
            <div className="muted">{x.d}</div>
            <div style={{ fontSize: 24 }}>{x.icon}</div>
            <div>
              {x.t}° / {x.n}°
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
