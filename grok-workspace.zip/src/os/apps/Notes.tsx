import { useEffect, useState } from "react";
import { OS } from "../config";
import { loadJson, saveJson, uid } from "@/lib/utils";

type Note = { id: string; title: string; body: string; at: number };
const KEY = `${OS.storageKey}_notes`;

export function NotesApp() {
  const [notes, setNotes] = useState<Note[]>(() =>
    loadJson<Note[]>(KEY, [{ id: "n1", title: "Добро пожаловать", body: "Это ваши заметки в AetherOS.", at: Date.now() }]),
  );
  const [cur, setCur] = useState(notes[0]?.id ?? null);
  const note = notes.find((n) => n.id === cur);

  useEffect(() => {
    saveJson(KEY, notes);
  }, [notes]);

  const patch = (p: Partial<Note>) => {
    setNotes((list) => list.map((n) => (n.id === cur ? { ...n, ...p, at: Date.now() } : n)));
  };

  return (
    <div style={{ display: "grid", gridTemplateColumns: "220px 1fr", height: "100%" }}>
      <div className="side-nav">
        <button
          type="button"
          className="os-btn primary"
          style={{ width: "100%", marginBottom: 8 }}
          onClick={() => {
            const n = { id: uid("n"), title: "Новая заметка", body: "", at: Date.now() };
            setNotes([n, ...notes]);
            setCur(n.id);
          }}
        >
          + Новая заметка
        </button>
        {notes.map((n) => (
          <button key={n.id} type="button" className={n.id === cur ? "active" : ""} onClick={() => setCur(n.id)}>
            {n.title || "Без названия"}
          </button>
        ))}
      </div>
      {note ? (
        <div style={{ display: "flex", flexDirection: "column", minWidth: 0 }}>
          <input
            className="os-input"
            style={{ border: "none", borderRadius: 0, height: 44, fontSize: 16, background: "transparent" }}
            value={note.title}
            onChange={(e) => patch({ title: e.target.value })}
          />
          <textarea
            className="note-area"
            value={note.body}
            onChange={(e) => patch({ body: e.target.value })}
            placeholder="Текст заметки"
          />
        </div>
      ) : (
        <div className="muted" style={{ padding: 20 }}>
          Нет заметок
        </div>
      )}
    </div>
  );
}
