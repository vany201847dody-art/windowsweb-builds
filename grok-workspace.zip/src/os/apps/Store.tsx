import { useMemo, useState } from "react";
import { APPS, type AppId } from "../config";
import { useOS } from "../store";

const CATS = ["Все", "Игры", "Продуктивность", "Медиа", "Утилиты"] as const;

const MAP: Record<(typeof CATS)[number], string> = {
  Все: "",
  Игры: "games",
  Продуктивность: "productivity",
  Медиа: "media",
  Утилиты: "utilities",
};

export function StoreApp() {
  const [cat, setCat] = useState<(typeof CATS)[number]>("Все");
  const [q, setQ] = useState("");
  const [busy, setBusy] = useState<Record<string, number>>({});
  const installed = useOS((s) => s.settings.installed);
  const pins = useOS((s) => s.settings.desktopPins);
  const installApp = useOS((s) => s.installApp);
  const openApp = useOS((s) => s.openApp);
  const notify = useOS((s) => s.notify);

  const list = useMemo(() => {
    return APPS.filter((a) => {
      if (MAP[cat] && a.category !== MAP[cat]) return false;
      if (q && !a.name.toLowerCase().includes(q.toLowerCase())) return false;
      return a.id !== "store";
    });
  }, [cat, q]);

  const startInstall = (id: AppId, name: string) => {
    if (busy[id] != null) return;
    let p = 0;
    setBusy((b) => ({ ...b, [id]: 0 }));
    const t = setInterval(() => {
      p += 8 + Math.random() * 12;
      if (p >= 100) {
        clearInterval(t);
        setBusy((b) => ({ ...b, [id]: 100 }));
        setTimeout(() => {
          installApp(id);
          setBusy((b) => {
            const n = { ...b };
            delete n[id];
            return n;
          });
          notify({ icon: "🛒", title: "Установлено", body: `${name} добавлено на рабочий стол` });
        }, 500);
      } else setBusy((b) => ({ ...b, [id]: Math.min(99, Math.round(p)) }));
    }, 120);
  };

  return (
    <div className="app-pad scroll">
      <div style={{ display: "flex", gap: 8, marginBottom: 12, flexWrap: "wrap" }}>
        <input className="os-input" placeholder="Поиск" value={q} onChange={(e) => setQ(e.target.value)} style={{ flex: 1, minWidth: 160 }} />
        {CATS.map((c) => (
          <button key={c} type="button" className={`os-btn ${cat === c ? "primary" : ""}`} onClick={() => setCat(c)}>
            {c}
          </button>
        ))}
      </div>
      <div className="grid-2">
        {list.map((a) => {
          const done = installed.includes(a.id) || pins.includes(a.id);
          const prog = busy[a.id];
          return (
            <div key={a.id} className="card" style={{ display: "flex", gap: 12, alignItems: "center" }}>
              <div style={{ fontSize: 32 }}>{a.icon}</div>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontWeight: 600 }}>{a.name}</div>
                <div className="muted">{a.description}</div>
                <div className="subtle">{a.size}</div>
                {prog != null && (
                  <div style={{ height: 6, background: "var(--hover)", borderRadius: 99, marginTop: 6 }}>
                    <div style={{ width: `${prog}%`, height: "100%", background: "var(--accent)", borderRadius: 99 }} />
                  </div>
                )}
              </div>
              {prog != null ? (
                <button type="button" className="os-btn" disabled>
                  {prog < 100 ? `${prog}%` : "Установка..."}
                </button>
              ) : done ? (
                <button type="button" className="os-btn primary" onClick={() => openApp(a.id)}>
                  Открыть
                </button>
              ) : (
                <button type="button" className="os-btn" onClick={() => startInstall(a.id, a.name)}>
                  Установить
                </button>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
