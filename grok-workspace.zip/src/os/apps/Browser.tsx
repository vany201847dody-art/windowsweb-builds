import { useState } from "react";
import { OsLogo } from "../Logo";
import { OS } from "../config";

type Tab = { id: string; title: string; url: string; embed: string | null };

const HOME = "aether://home";

const ENGINES: { name: string; q: (s: string) => string; embed: (s: string) => string }[] = [
  { name: "Яндекс", q: (s) => `https://yandex.ru/search/?text=${encodeURIComponent(s)}`, embed: (s) => `https://yandex.ru/search/?text=${encodeURIComponent(s)}` },
  { name: "Google", q: (s) => `https://www.google.com/search?q=${encodeURIComponent(s)}`, embed: (s) => `https://www.google.com/search?igu=1&q=${encodeURIComponent(s)}` },
  { name: "Bing", q: (s) => `https://www.bing.com/search?q=${encodeURIComponent(s)}`, embed: (s) => `https://www.bing.com/search?q=${encodeURIComponent(s)}` },
  { name: "DuckDuckGo", q: (s) => `https://duckduckgo.com/?q=${encodeURIComponent(s)}`, embed: (s) => `https://html.duckduckgo.com/html/?q=${encodeURIComponent(s)}` },
];

const LINKS = [
  { name: "Wikipedia", url: "https://ru.wikipedia.org" },
  { name: "YouTube", url: "https://www.youtube.com" },
  { name: "GitHub", url: "https://github.com" },
  { name: "MDN", url: "https://developer.mozilla.org" },
  { name: "Unsplash", url: "https://unsplash.com" },
  { name: "Habr", url: "https://habr.com" },
];

function uid() {
  return Math.random().toString(36).slice(2, 8);
}

export function BrowserApp() {
  const [tabs, setTabs] = useState<Tab[]>([{ id: uid(), title: "Главная", url: HOME, embed: null }]);
  const [cur, setCur] = useState(0);
  const [addr, setAddr] = useState(HOME);
  const [engine, setEngine] = useState(0);
  const [hist, setHist] = useState<string[]>([HOME]);
  const [hi, setHi] = useState(0);
  const tab = tabs[cur];

  const go = (url: string, embed: string | null, title?: string) => {
    const next = { ...tabs[cur], url, embed, title: title ?? url };
    const copy = [...tabs];
    copy[cur] = next;
    setTabs(copy);
    setAddr(url);
    setHist((h) => [...h.slice(0, hi + 1), url]);
    setHi((i) => i + 1);
  };

  const search = (q: string) => {
    const e = ENGINES[engine];
    go(e.q(q), e.embed(q), q);
  };

  const submit = (raw: string) => {
    const v = raw.trim();
    if (!v) return;
    if (v === HOME || v.startsWith("aether://")) {
      go(HOME, null, "Главная");
      return;
    }
    if (/^https?:\/\//i.test(v) || v.includes(".")) {
      const url = /^https?:/i.test(v) ? v : "https://" + v;
      go(url, url, url.replace(/^https?:\/\//, "").split("/")[0]);
    } else search(v);
  };

  return (
    <div style={{ height: "100%", display: "flex", flexDirection: "column", background: "var(--win)" }}>
      <div style={{ display: "flex", gap: 6, padding: "6px 8px", borderBottom: "1px solid var(--border)", alignItems: "center" }}>
        <button type="button" className="os-btn" disabled={hi <= 0} onClick={() => { const u = hist[hi - 1]; setHi(hi - 1); setAddr(u); }}>
          ←
        </button>
        <button type="button" className="os-btn" disabled={hi >= hist.length - 1} onClick={() => { const u = hist[hi + 1]; setHi(hi + 1); setAddr(u); }}>
          →
        </button>
        <button type="button" className="os-btn" onClick={() => tab.embed && go(tab.url, tab.embed, tab.title)}>
          ↻
        </button>
        <input
          className="os-input"
          style={{ flex: 1 }}
          value={addr}
          onChange={(e) => setAddr(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && submit(addr)}
        />
        <button
          type="button"
          className="os-btn"
          onClick={() => window.open(tab.embed || (addr.startsWith("http") ? addr : ENGINES[engine].q(addr)), "_blank")}
        >
          Новая вкладка
        </button>
      </div>
      <div style={{ display: "flex", gap: 4, padding: "4px 8px", borderBottom: "1px solid var(--border)" }}>
        {tabs.map((t, i) => (
          <button key={t.id} type="button" className={`os-btn ${i === cur ? "primary" : ""}`} onClick={() => { setCur(i); setAddr(t.url); }}>
            {t.title.slice(0, 18)}
          </button>
        ))}
        <button
          type="button"
          className="os-btn"
          onClick={() => {
            const t = { id: uid(), title: "Главная", url: HOME, embed: null };
            setTabs([...tabs, t]);
            setCur(tabs.length);
            setAddr(HOME);
          }}
        >
          +
        </button>
      </div>
      <div style={{ flex: 1, minHeight: 0, position: "relative" }}>
        {tab.embed ? (
          <iframe title={tab.title} src={tab.embed} style={{ width: "100%", height: "100%", border: 0, background: "#fff" }} />
        ) : (
          <div className="scroll app-pad" style={{ textAlign: "center" }}>
            <div style={{ display: "grid", placeItems: "center", margin: "24px 0 8px" }}>
              <OsLogo size={48} glow />
            </div>
            <h2 style={{ fontWeight: 500, margin: "0 0 16px" }}>{OS.name} Browser</h2>
            <div style={{ display: "flex", gap: 8, maxWidth: 560, margin: "0 auto 18px" }}>
              <input
                className="os-input"
                style={{ flex: 1 }}
                placeholder="Поиск или адрес"
                value={addr === HOME ? "" : addr}
                onChange={(e) => setAddr(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && submit(addr)}
              />
              <button type="button" className="os-btn primary" onClick={() => submit(addr)}>
                Найти
              </button>
            </div>
            <div style={{ display: "flex", gap: 8, justifyContent: "center", flexWrap: "wrap", marginBottom: 22 }}>
              {ENGINES.map((e, i) => (
                <button key={e.name} type="button" className={`os-btn ${engine === i ? "primary" : ""}`} onClick={() => setEngine(i)}>
                  {e.name}
                </button>
              ))}
            </div>
            <div className="grid-3" style={{ maxWidth: 520, margin: "0 auto" }}>
              {LINKS.map((l) => (
                <button key={l.name} type="button" className="card" onClick={() => go(l.url, l.url, l.name)}>
                  {l.name}
                </button>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
