import { useEffect, useState } from "react";
import { OS } from "../config";
import { useOS } from "../store";

const KEY = `${OS.storageKey}_notepad`;

export function NotepadApp() {
  const [text, setText] = useState(() => (typeof localStorage !== "undefined" ? localStorage.getItem(KEY) ?? "" : ""));
  const [wrap, setWrap] = useState(true);
  const [menu, setMenu] = useState<string | null>(null);
  const notify = useOS((s) => s.notify);

  useEffect(() => {
    localStorage.setItem(KEY, text);
  }, [text]);

  const run = (id: string) => {
    setMenu(null);
    if (id === "new") setText("");
    if (id === "save") {
      localStorage.setItem(KEY, text);
      notify({ icon: "📝", title: "Блокнот", body: "Файл сохранён" });
    }
    if (id === "cut") {
      navigator.clipboard?.writeText(text);
      setText("");
    }
    if (id === "copy") navigator.clipboard?.writeText(text);
    if (id === "paste") navigator.clipboard?.readText().then((t) => setText((s) => s + t)).catch(() => {});
    if (id === "wrap") setWrap((v) => !v);
    if (id === "time") setText((s) => s + "\n" + new Date().toLocaleString("ru-RU"));
  };

  const menus: Record<string, { id: string; label: string }[]> = {
    Файл: [
      { id: "new", label: "Создать" },
      { id: "save", label: "Сохранить" },
    ],
    Правка: [
      { id: "cut", label: "Вырезать" },
      { id: "copy", label: "Копировать" },
      { id: "paste", label: "Вставить" },
      { id: "time", label: "Время и дата" },
    ],
    Формат: [{ id: "wrap", label: wrap ? "Не переносить" : "Переносить строки" }],
    Вид: [{ id: "wrap", label: "Перенос строк" }],
  };

  return (
    <div style={{ height: "100%", display: "flex", flexDirection: "column" }}>
      <div style={{ display: "flex", gap: 2, padding: "4px 8px", borderBottom: "1px solid var(--border)", position: "relative" }}>
        {Object.keys(menus).map((m) => (
          <button key={m} type="button" className="os-btn" style={{ height: 26 }} onClick={() => setMenu(menu === m ? null : m)}>
            {m}
          </button>
        ))}
        {menu && (
          <div className="ctx" style={{ left: 8, top: 34, position: "absolute" }}>
            {menus[menu].map((it) => (
              <button key={it.id} type="button" onClick={() => run(it.id)}>
                {it.label}
              </button>
            ))}
          </div>
        )}
      </div>
      <textarea
        className="note-area"
        value={text}
        onChange={(e) => setText(e.target.value)}
        spellCheck={false}
        style={{ whiteSpace: wrap ? "pre-wrap" : "pre" }}
        placeholder="Начните ввод…"
      />
    </div>
  );
}
