import { APPS, OS } from "../config";
import { OsLogo } from "../Logo";

export function AboutApp() {
  return (
    <div className="app-pad" style={{ textAlign: "center" }}>
      <div style={{ display: "grid", placeItems: "center", margin: "12px 0 8px" }}>
        <OsLogo size={72} glow />
      </div>
      <h2 style={{ margin: "8px 0 4px", fontWeight: 500 }}>{OS.name}</h2>
      <div className="muted">Версия {OS.version} · Сборка {OS.build} · {OS.year}</div>
      <div className="card" style={{ textAlign: "left", marginTop: 18 }}>
        <Row k="Автор" v={OS.author} />
        <Row k="Лицензия" v="PROPRIETARY · All Rights Reserved" />
        <Row k="Copyright" v={`© ${OS.year} ${OS.author}`} />
        <Row k="Технологии" v="HTML5, CSS3, Vanilla-совместимый React" />
        <Row k="Приложения" v={String(APPS.length)} />
        <Row k="Разделы" v="Система, Персонализация, Сеть, Банк, Игры" />
      </div>
      <div style={{ marginTop: 28, fontSize: 18, letterSpacing: "0.08em", textTransform: "uppercase", color: "var(--fg-muted)" }}>
        Все права защищены
      </div>
    </div>
  );
}

function Row({ k, v }: { k: string; v: string }) {
  return (
    <div style={{ display: "flex", justifyContent: "space-between", gap: 12, padding: "8px 0", borderBottom: "1px solid var(--border)" }}>
      <span className="muted">{k}</span>
      <span>{v}</span>
    </div>
  );
}
