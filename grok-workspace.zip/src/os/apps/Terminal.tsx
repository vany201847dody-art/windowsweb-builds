import { useEffect, useRef, useState } from "react";
import { APPS, OS } from "../config";
import { useOS } from "../store";

const PROMPT = `C:\\Users\\${OS.user}>`;

export function TerminalApp() {
  const [lines, setLines] = useState<string[]>([`${OS.name} [версия ${OS.version} сборка ${OS.build}]`, "(c) Vizor, 2026. Все права защищены.", ""]);
  const [input, setInput] = useState("");
  const hist = useRef<string[]>([]);
  const hi = useRef(-1);
  const box = useRef<HTMLDivElement>(null);
  const openApp = useOS((s) => s.openApp);
  const setPhase = useOS((s) => s.setPhase);
  const windows = useOS((s) => s.windows);
  const closeWin = useOS((s) => s.closeWin);

  useEffect(() => {
    box.current?.scrollTo(0, box.current.scrollHeight);
  }, [lines]);

  const print = (more: string[]) => setLines((l) => [...l, ...more]);

  const run = (raw: string) => {
    const cmd = raw.trim();
    print([`${PROMPT}${cmd}`]);
    if (!cmd) return;
    hist.current.push(cmd);
    hi.current = hist.current.length;
    const [head, ...rest] = cmd.split(/\s+/);
    const arg = rest.join(" ");
    const h = head.toLowerCase();
    if (h === "help") {
      print(["help ver dir cls date time echo whoami hostname ipconfig ping", "tasklist kill tree банк настройки камера часы qr exit shutdown restart"]);
    } else if (h === "ver") print([`${OS.name} версия ${OS.version} (сборка ${OS.build})`]);
    else if (h === "cls") setLines([]);
    else if (h === "date") print([new Date().toLocaleDateString("ru-RU")]);
    else if (h === "time") print([new Date().toLocaleTimeString("ru-RU")]);
    else if (h === "echo") print([arg]);
    else if (h === "whoami") print([`${OS.hostname}\\${OS.user}`]);
    else if (h === "hostname") print([OS.hostname]);
    else if (h === "dir") {
      print([" Каталог C:\\Users\\User", "", "26.09.2026  12:00    <DIR>          Documents", "26.09.2026  12:00    <DIR>          Downloads", "26.09.2026  12:00    <DIR>          Desktop", "               0 файлов"]);
    } else if (h === "ipconfig") {
      print(["Адаптер Ethernet AetherLink:", "   IPv4-адрес. . . . . . . . . : 192.168.1.42", "   Маска подсети . . . . . . . : 255.255.255.0", "   Основной шлюз . . . . . . . : 192.168.1.1"]);
    } else if (h === "ping") {
      const host = arg || "aether.local";
      print([`Обмен пакетами с ${host}:`, "Ответ от 192.168.1.1: число байт=32 время=4мс TTL=64", "Ответ от 192.168.1.1: число байт=32 время=5мс TTL=64", "Статистика: отправлено 4, получено 4, потерь 0%"]);
    } else if (h === "tasklist") {
      print(["Имя образа                     PID", "====================================", ...windows.map((w, i) => `${w.title.padEnd(30)} ${1000 + i}`)]);
    } else if (h === "kill") {
      const t = windows.find((w) => w.title.toLowerCase().includes(arg.toLowerCase()) || w.appId === arg);
      if (t) {
        closeWin(t.id);
        print([`Процесс ${t.title} завершён.`]);
      } else print(["Не найден."]);
    } else if (h === "tree") {
      print(["C:\\", "├─ Users", "│  └─ User", "│     ├─ Documents", "│     └─ Desktop", "├─ Windows", "└─ Program Files"]);
    } else if (h === "банк" || h === "bank") openApp("bank");
    else if (h === "настройки" || h === "settings") openApp("settings");
    else if (h === "камера") openApp("camera");
    else if (h === "часы") openApp("clock");
    else if (h === "qr") openApp("qr");
    else if (h === "exit") {
      const w = windows.find((x) => x.appId === "terminal");
      if (w) closeWin(w.id);
    } else if (h === "shutdown") setPhase("shutdown");
    else if (h === "restart") setPhase("restart");
    else if (h === "apps") print(APPS.map((a) => a.id + " — " + a.name));
    else print([`'${head}' не является внутренней или внешней командой.`]);
  };

  return (
    <div className="term" ref={box} onClick={() => box.current?.querySelector("input")?.focus()}>
      {lines.map((l, i) => (
        <div key={i} className={l.startsWith(PROMPT) ? "cmd" : l.includes("не является") ? "err" : "ok"}>
          {l || "\u00a0"}
        </div>
      ))}
      <div>
        <span className="cmd">{PROMPT}</span>
        <input
          value={input}
          autoFocus
          spellCheck={false}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === "Enter") {
              run(input);
              setInput("");
            }
            if (e.key === "ArrowUp") {
              e.preventDefault();
              hi.current = Math.max(0, hi.current - 1);
              setInput(hist.current[hi.current] ?? "");
            }
            if (e.key === "ArrowDown") {
              e.preventDefault();
              hi.current = Math.min(hist.current.length, hi.current + 1);
              setInput(hist.current[hi.current] ?? "");
            }
          }}
        />
      </div>
    </div>
  );
}
