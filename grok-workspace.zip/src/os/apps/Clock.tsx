import { useEffect, useMemo, useState } from "react";
import { useOS } from "../store";

const CITIES = [
  { name: "Москва", flag: "🇷🇺", tz: "Europe/Moscow" },
  { name: "Лондон", flag: "🇬🇧", tz: "Europe/London" },
  { name: "Нью-Йорк", flag: "🇺🇸", tz: "America/New_York" },
  { name: "Токио", flag: "🇯🇵", tz: "Asia/Tokyo" },
  { name: "Дубай", flag: "🇦🇪", tz: "Asia/Dubai" },
  { name: "Сидней", flag: "🇦🇺", tz: "Australia/Sydney" },
];

export function ClockApp() {
  const [tab, setTab] = useState<"analog" | "world" | "stop" | "timer">("analog");
  return (
    <div style={{ height: "100%", display: "flex", flexDirection: "column" }}>
      <div className="tabs" style={{ padding: "8px 10px" }}>
        {[
          ["analog", "Аналоговые"],
          ["world", "Мировые"],
          ["stop", "Секундомер"],
          ["timer", "Таймер"],
        ].map(([k, l]) => (
          <button key={k} type="button" className={tab === k ? "on" : ""} onClick={() => setTab(k as typeof tab)}>
            {l}
          </button>
        ))}
      </div>
      <div className="scroll" style={{ flex: 1 }}>
        {tab === "analog" && <Analog />}
        {tab === "world" && <World />}
        {tab === "stop" && <Stopwatch />}
        {tab === "timer" && <Timer />}
      </div>
    </div>
  );
}

function Analog() {
  const now = useOS((s) => s.now);
  const d = new Date(now);
  const s = d.getSeconds() + d.getMilliseconds() / 1000;
  const m = d.getMinutes() + s / 60;
  const h = (d.getHours() % 12) + m / 60;
  return (
    <div style={{ display: "grid", placeItems: "center", padding: 20 }}>
      <svg width="240" height="240" viewBox="0 0 200 200">
        <circle cx="100" cy="100" r="96" fill="var(--hover)" stroke="var(--border-strong)" />
        {Array.from({ length: 60 }, (_, i) => {
          const a = (i / 60) * Math.PI * 2 - Math.PI / 2;
          const inner = i % 5 === 0 ? 78 : 86;
          return (
            <line
              key={i}
              x1={100 + Math.cos(a) * inner}
              y1={100 + Math.sin(a) * inner}
              x2={100 + Math.cos(a) * 92}
              y2={100 + Math.sin(a) * 92}
              stroke="var(--fg)"
              strokeWidth={i % 5 === 0 ? 2 : 1}
              opacity={i % 5 === 0 ? 0.9 : 0.4}
            />
          );
        })}
        <line x1="100" y1="100" x2={100 + Math.cos((h / 12) * Math.PI * 2 - Math.PI / 2) * 48} y2={100 + Math.sin((h / 12) * Math.PI * 2 - Math.PI / 2) * 48} stroke="var(--fg)" strokeWidth="4" strokeLinecap="round" />
        <line x1="100" y1="100" x2={100 + Math.cos((m / 60) * Math.PI * 2 - Math.PI / 2) * 68} y2={100 + Math.sin((m / 60) * Math.PI * 2 - Math.PI / 2) * 68} stroke="var(--fg)" strokeWidth="3" strokeLinecap="round" />
        <line x1="100" y1="100" x2={100 + Math.cos((s / 60) * Math.PI * 2 - Math.PI / 2) * 78} y2={100 + Math.sin((s / 60) * Math.PI * 2 - Math.PI / 2) * 78} stroke="var(--accent)" strokeWidth="1.5" />
        <circle cx="100" cy="100" r="4" fill="var(--accent)" />
      </svg>
      <div style={{ fontSize: 28, marginTop: 8, fontVariantNumeric: "tabular-nums" }}>
        {d.toLocaleTimeString("ru-RU")}
      </div>
    </div>
  );
}

function World() {
  const now = useOS((s) => s.now);
  return (
    <div className="app-pad grid-2">
      {CITIES.map((c) => (
        <div key={c.name} className="card">
          <div>
            {c.flag} {c.name}
          </div>
          <div style={{ fontSize: 22, fontVariantNumeric: "tabular-nums" }}>
            {new Date(now).toLocaleTimeString("ru-RU", { timeZone: c.tz, hour: "2-digit", minute: "2-digit", second: "2-digit" })}
          </div>
        </div>
      ))}
    </div>
  );
}

function Stopwatch() {
  const [run, setRun] = useState(false);
  const [t, setT] = useState(0);
  const [laps, setLaps] = useState<number[]>([]);
  useEffect(() => {
    if (!run) return;
    let raf = 0;
    let last = performance.now();
    const loop = (now: number) => {
      const dt = Math.min(0.1, (now - last) / 1000);
      last = now;
      setT((x) => x + dt);
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, [run]);
  const fmt = (x: number) => {
    const m = Math.floor(x / 60);
    const s = x % 60;
    return `${String(m).padStart(2, "0")}:${s.toFixed(2).padStart(5, "0")}`;
  };
  return (
    <div className="app-pad" style={{ textAlign: "center" }}>
      <div style={{ fontSize: 48, fontVariantNumeric: "tabular-nums" }}>{fmt(t)}</div>
      <div style={{ display: "flex", gap: 8, justifyContent: "center", margin: 12 }}>
        <button type="button" className="os-btn primary" onClick={() => setRun(!run)}>
          {run ? "Пауза" : "Старт"}
        </button>
        <button type="button" className="os-btn" onClick={() => setLaps([t, ...laps])}>
          Круг
        </button>
        <button
          type="button"
          className="os-btn"
          onClick={() => {
            setRun(false);
            setT(0);
            setLaps([]);
          }}
        >
          Сброс
        </button>
      </div>
      {laps.map((l, i) => (
        <div key={i} className="muted">
          #{laps.length - i} · {fmt(l)}
        </div>
      ))}
    </div>
  );
}

function Timer() {
  const [h, setH] = useState(0);
  const [m, setM] = useState(5);
  const [s, setS] = useState(0);
  const [left, setLeft] = useState<number | null>(null);
  const [run, setRun] = useState(false);
  const notify = useOS((s) => s.notify);
  const total = h * 3600 + m * 60 + s;
  useEffect(() => {
    if (!run || left == null) return;
    let raf = 0;
    let last = performance.now();
    const loop = (now: number) => {
      const dt = Math.min(0.1, (now - last) / 1000);
      last = now;
      setLeft((x) => {
        if (x == null) return x;
        const n = x - dt;
        if (n <= 0) {
          setRun(false);
          notify({ icon: "🕐", title: "Таймер", body: "Время вышло" });
          return 0;
        }
        return n;
      });
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, [run, left, notify]);
  const show = left ?? total;
  const hh = Math.floor(show / 3600);
  const mm = Math.floor((show % 3600) / 60);
  const ss = Math.floor(show % 60);
  return (
    <div className="app-pad" style={{ textAlign: "center" }}>
      <div style={{ fontSize: 42, fontVariantNumeric: "tabular-nums" }}>
        {String(hh).padStart(2, "0")}:{String(mm).padStart(2, "0")}:{String(ss).padStart(2, "0")}
      </div>
      {left == null && (
        <div style={{ display: "flex", gap: 8, justifyContent: "center", marginTop: 12 }}>
          <Num v={h} set={setH} max={23} />
          <Num v={m} set={setM} max={59} />
          <Num v={s} set={setS} max={59} />
        </div>
      )}
      <div style={{ display: "flex", gap: 8, justifyContent: "center", marginTop: 12 }}>
        <button
          type="button"
          className="os-btn primary"
          onClick={() => {
            if (left == null) setLeft(total);
            setRun((r) => !r);
          }}
        >
          {run ? "Пауза" : "Старт"}
        </button>
        <button
          type="button"
          className="os-btn"
          onClick={() => {
            setRun(false);
            setLeft(null);
          }}
        >
          Сброс
        </button>
      </div>
    </div>
  );
}

function Num({ v, set, max }: { v: number; set: (n: number) => void; max: number }) {
  return (
    <input
      className="os-input"
      style={{ width: 64, textAlign: "center" }}
      value={v}
      onChange={(e) => set(Math.max(0, Math.min(max, Number(e.target.value) || 0)))}
    />
  );
}

void useMemo;
