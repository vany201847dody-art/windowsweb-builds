import { useEffect, useRef, useState } from "react";

export function PaintApp() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const wrapRef = useRef<HTMLDivElement>(null);
  const [color, setColor] = useState("#0a84ff");
  const [size, setSize] = useState(6);
  const [tool, setTool] = useState<"brush" | "erase">("brush");
  const drawing = useRef(false);
  const last = useRef<{ x: number; y: number } | null>(null);

  const fit = () => {
    const c = canvasRef.current;
    const w = wrapRef.current;
    if (!c || !w) return;
    const dpr = Math.min(2, window.devicePixelRatio || 1);
    const rect = w.getBoundingClientRect();
    const img = c.getContext("2d")?.getImageData(0, 0, c.width, c.height);
    c.width = Math.max(1, rect.width * dpr);
    c.height = Math.max(1, rect.height * dpr);
    const ctx = c.getContext("2d");
    if (!ctx) return;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.fillStyle = "#ffffff";
    ctx.fillRect(0, 0, rect.width, rect.height);
    if (img) {
      /* keep blank on first size */
    }
  };

  useEffect(() => {
    fit();
    const ro = new ResizeObserver(fit);
    if (wrapRef.current) ro.observe(wrapRef.current);
    return () => ro.disconnect();
  }, []);

  const pos = (e: React.PointerEvent) => {
    const r = canvasRef.current!.getBoundingClientRect();
    return { x: e.clientX - r.left, y: e.clientY - r.top };
  };

  const stroke = (from: { x: number; y: number }, to: { x: number; y: number }) => {
    const ctx = canvasRef.current?.getContext("2d");
    if (!ctx) return;
    ctx.lineCap = "round";
    ctx.lineJoin = "round";
    ctx.lineWidth = size;
    ctx.strokeStyle = tool === "erase" ? "#ffffff" : color;
    ctx.beginPath();
    ctx.moveTo(from.x, from.y);
    ctx.lineTo(to.x, to.y);
    ctx.stroke();
  };

  return (
    <div style={{ height: "100%", display: "flex", flexDirection: "column" }}>
      <div style={{ display: "flex", gap: 8, alignItems: "center", padding: 8, borderBottom: "1px solid var(--border)" }}>
        <input type="color" value={color} onChange={(e) => setColor(e.target.value)} />
        <input className="os-range" style={{ width: 120 }} type="range" min={1} max={40} value={size} onChange={(e) => setSize(Number(e.target.value))} />
        <span className="muted">{size}px</span>
        <button type="button" className={`os-btn ${tool === "brush" ? "primary" : ""}`} onClick={() => setTool("brush")}>
          Кисть
        </button>
        <button type="button" className={`os-btn ${tool === "erase" ? "primary" : ""}`} onClick={() => setTool("erase")}>
          Ластик
        </button>
        <button
          type="button"
          className="os-btn"
          onClick={() => {
            const c = canvasRef.current;
            const ctx = c?.getContext("2d");
            if (!c || !ctx) return;
            ctx.setTransform(1, 0, 0, 1, 0, 0);
            ctx.fillStyle = "#fff";
            ctx.fillRect(0, 0, c.width, c.height);
            const dpr = Math.min(2, window.devicePixelRatio || 1);
            ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
          }}
        >
          Очистить
        </button>
      </div>
      <div ref={wrapRef} style={{ flex: 1, minHeight: 0 }}>
        <canvas
          ref={canvasRef}
          style={{ width: "100%", height: "100%", display: "block", cursor: "crosshair", touchAction: "none" }}
          onPointerDown={(e) => {
            drawing.current = true;
            last.current = pos(e);
            (e.target as HTMLElement).setPointerCapture(e.pointerId);
            stroke(last.current, last.current);
          }}
          onPointerMove={(e) => {
            if (!drawing.current || !last.current) return;
            const p = pos(e);
            stroke(last.current, p);
            last.current = p;
          }}
          onPointerUp={() => {
            drawing.current = false;
            last.current = null;
          }}
        />
      </div>
    </div>
  );
}
