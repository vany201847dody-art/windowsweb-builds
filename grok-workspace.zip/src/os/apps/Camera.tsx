import { useEffect, useRef, useState } from "react";
import { useOS } from "../store";

type Shot = { id: string; type: "photo" | "video"; url: string; at: number };

export function CameraApp() {
  const videoRef = useRef<HTMLVideoElement>(null);
  const recRef = useRef<MediaRecorder | null>(null);
  const chunks = useRef<Blob[]>([]);
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [err, setErr] = useState<string | null>(null);
  const [mode, setMode] = useState<"photo" | "video">("photo");
  const [facing, setFacing] = useState<"user" | "environment">("user");
  const [rec, setRec] = useState(false);
  const [t, setT] = useState(0);
  const [shots, setShots] = useState<Shot[]>([]);
  const [view, setView] = useState<number | null>(null);
  const [flash, setFlash] = useState(false);
  const notify = useOS((s) => s.notify);
  const allowed = useOS((s) => s.settings.cameraAllowed);

  const start = async () => {
    setErr(null);
    if (!allowed) {
      setErr("Камера отключена в параметрах конфиденциальности.");
      return;
    }
    try {
      stream?.getTracks().forEach((t) => t.stop());
      const s = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: facing, width: { ideal: 1280 }, height: { ideal: 720 } },
        audio: mode === "video",
      });
      setStream(s);
      if (videoRef.current) {
        videoRef.current.srcObject = s;
        await videoRef.current.play();
      }
    } catch {
      setErr("Нет доступа к камере. Разрешите использование или подключите устройство.");
    }
  };

  useEffect(() => {
    start();
    return () => stream?.getTracks().forEach((t) => t.stop());
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [facing, allowed]);

  useEffect(() => {
    if (!rec) return;
    const i = setInterval(() => setT((x) => x + 1), 1000);
    return () => clearInterval(i);
  }, [rec]);

  const snap = () => {
    const v = videoRef.current;
    if (!v) return;
    setFlash(true);
    setTimeout(() => setFlash(false), 180);
    const c = document.createElement("canvas");
    c.width = v.videoWidth || 1280;
    c.height = v.videoHeight || 720;
    const ctx = c.getContext("2d");
    if (!ctx) return;
    if (facing === "user") {
      ctx.translate(c.width, 0);
      ctx.scale(-1, 1);
    }
    ctx.drawImage(v, 0, 0);
    c.toBlob((b) => {
      if (!b) return;
      const url = URL.createObjectURL(b);
      setShots((s) => [{ id: String(Date.now()), type: "photo", url, at: Date.now() }, ...s]);
      notify({ icon: "📷", title: "Камера", body: "Снимок сохранён" });
    }, "image/jpeg", 0.92);
  };

  const toggleRec = () => {
    if (rec) {
      recRef.current?.stop();
      setRec(false);
      return;
    }
    if (!stream) return;
    try {
      const recd = new MediaRecorder(stream);
      chunks.current = [];
      recd.ondataavailable = (e) => e.data.size && chunks.current.push(e.data);
      recd.onstop = () => {
        const blob = new Blob(chunks.current, { type: recd.mimeType || "video/webm" });
        const url = URL.createObjectURL(blob);
        setShots((s) => [{ id: String(Date.now()), type: "video", url, at: Date.now() }, ...s]);
      };
      recd.start();
      recRef.current = recd;
      setT(0);
      setRec(true);
    } catch {
      setErr("Запись недоступна в этом браузере.");
    }
  };

  const cur = view != null ? shots[view] : null;

  return (
    <div className="viewfinder">
      {err ? (
        <div style={{ height: "100%", display: "grid", placeItems: "center", padding: 24, textAlign: "center" }}>
          <div>
            <div style={{ fontSize: 40, marginBottom: 8 }}>📷</div>
            <p>{err}</p>
            <button type="button" className="os-btn primary" onClick={start}>
              Повторить
            </button>
          </div>
        </div>
      ) : (
        <>
          <video
            ref={videoRef}
            playsInline
            muted
            style={{ width: "100%", height: "100%", objectFit: "cover", transform: facing === "user" ? "scaleX(-1)" : undefined }}
          />
          <div className="corner tl" />
          <div className="corner tr" />
          <div className="corner bl" />
          <div className="corner br" />
          {flash && <div style={{ position: "absolute", inset: 0, background: "#fff", opacity: 0.7 }} />}
          {rec && (
            <div style={{ position: "absolute", top: 16, left: "50%", transform: "translateX(-50%)", color: "#ff3b30", fontWeight: 600 }}>
              ● REC {String(Math.floor(t / 60)).padStart(2, "0")}:{String(t % 60).padStart(2, "0")}
            </div>
          )}
          <div style={{ position: "absolute", top: 12, right: 12, display: "flex", gap: 6 }}>
            {shots.slice(0, 4).map((s, i) =>
              s.type === "photo" ? (
                <img key={s.id} src={s.url} alt="" onClick={() => setView(i)} style={{ width: 48, height: 48, objectFit: "cover", borderRadius: 8, cursor: "pointer" }} />
              ) : (
                <div key={s.id} onClick={() => setView(i)} style={{ width: 48, height: 48, borderRadius: 8, background: "#111", display: "grid", placeItems: "center", cursor: "pointer" }}>
                  ▶
                </div>
              ),
            )}
          </div>
          <div style={{ position: "absolute", bottom: 16, left: 0, right: 0, display: "flex", justifyContent: "center", gap: 12, alignItems: "center" }}>
            <button type="button" className={`os-btn ${mode === "photo" ? "primary" : ""}`} onClick={() => setMode("photo")}>
              Фото
            </button>
            <button
              type="button"
              onClick={mode === "photo" ? snap : toggleRec}
              style={{
                width: 64,
                height: 64,
                borderRadius: 99,
                border: "3px solid #fff",
                background: rec ? "#ff3b30" : "#fff",
              }}
            />
            <button type="button" className={`os-btn ${mode === "video" ? "primary" : ""}`} onClick={() => setMode("video")}>
              Видео
            </button>
            <button type="button" className="os-btn" onClick={() => setFacing(facing === "user" ? "environment" : "user")}>
              ↺
            </button>
          </div>
        </>
      )}
      {cur && (
        <div style={{ position: "absolute", inset: 0, background: "#000", zIndex: 4, display: "flex", flexDirection: "column" }}>
          {cur.type === "photo" ? (
            <img src={cur.url} alt="" style={{ flex: 1, objectFit: "contain" }} />
          ) : (
            <video src={cur.url} controls style={{ flex: 1 }} />
          )}
          <div style={{ display: "flex", gap: 8, justifyContent: "center", padding: 10 }}>
            <button type="button" className="os-btn" disabled={view === 0} onClick={() => setView((v) => Math.max(0, (v ?? 0) - 1))}>
              ←
            </button>
            <a className="os-btn primary" href={cur.url} download={`aether-${cur.type}`}>
              Скачать
            </a>
            <button type="button" className="os-btn" disabled={view === shots.length - 1} onClick={() => setView((v) => Math.min(shots.length - 1, (v ?? 0) + 1))}>
              →
            </button>
            <button type="button" className="os-btn" onClick={() => setView(null)}>
              Закрыть
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
