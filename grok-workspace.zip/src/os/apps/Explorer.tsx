import { useMemo, useState } from "react";

type Entry = { name: string; icon: string; kind: "folder" | "file"; size?: string };

const TREE: Record<string, Entry[]> = {
  "Этот компьютер": [
    { name: "Документы", icon: "📁", kind: "folder" },
    { name: "Загрузки", icon: "📁", kind: "folder" },
    { name: "Изображения", icon: "📁", kind: "folder" },
    { name: "Музыка", icon: "📁", kind: "folder" },
    { name: "Видео", icon: "📁", kind: "folder" },
    { name: "Диск C:", icon: "💽", kind: "folder", size: "128 ГБ" },
    { name: "Диск D:", icon: "💽", kind: "folder", size: "512 ГБ" },
  ],
  Документы: [
    { name: "Резюме.docx", icon: "📄", kind: "file", size: "48 КБ" },
    { name: "Заметки.txt", icon: "📝", kind: "file", size: "3 КБ" },
    { name: "Бюджет.xlsx", icon: "📊", kind: "file", size: "112 КБ" },
    { name: "Проекты", icon: "📁", kind: "folder" },
  ],
  Проекты: [
    { name: "AetherOS", icon: "📁", kind: "folder" },
    { name: "readme.md", icon: "📄", kind: "file", size: "2 КБ" },
  ],
  AetherOS: [{ name: "index.html", icon: "🌐", kind: "file", size: "1.2 МБ" }],
  Загрузки: [
    { name: "setup.exe", icon: "📦", kind: "file", size: "84 МБ" },
    { name: "photo.jpg", icon: "🖼️", kind: "file", size: "3.1 МБ" },
    { name: "archive.zip", icon: "🗜️", kind: "file", size: "22 МБ" },
  ],
  Изображения: [
    { name: "Отпуск", icon: "📁", kind: "folder" },
    { name: "wallpaper.jpg", icon: "🖼️", kind: "file", size: "4.8 МБ" },
    { name: "logo.png", icon: "🖼️", kind: "file", size: "220 КБ" },
  ],
  Отпуск: [
    { name: "море.jpg", icon: "🖼️", kind: "file", size: "2.4 МБ" },
    { name: "горы.jpg", icon: "🖼️", kind: "file", size: "3.0 МБ" },
  ],
  Музыка: [
    { name: "Night Drive.mp3", icon: "🎵", kind: "file", size: "8 МБ" },
    { name: "Glass Rain.mp3", icon: "🎵", kind: "file", size: "7 МБ" },
  ],
  Видео: [{ name: "demo.mp4", icon: "🎬", kind: "file", size: "120 МБ" }],
  "Диск C:": [
    { name: "Windows", icon: "📁", kind: "folder" },
    { name: "Users", icon: "📁", kind: "folder" },
    { name: "Program Files", icon: "📁", kind: "folder" },
  ],
  Windows: [{ name: "System32", icon: "📁", kind: "folder" }],
  Users: [{ name: "User", icon: "📁", kind: "folder" }],
  User: [
    { name: "Desktop", icon: "📁", kind: "folder" },
    { name: "Documents", icon: "📁", kind: "folder" },
  ],
  "Program Files": [{ name: "Aether", icon: "📁", kind: "folder" }],
  "Диск D:": [
    { name: "Games", icon: "📁", kind: "folder" },
    { name: "Backup", icon: "📁", kind: "folder" },
  ],
  Games: [{ name: "Snake", icon: "📁", kind: "folder" }],
  Backup: [{ name: "2026-01.zip", icon: "🗜️", kind: "file", size: "2 ГБ" }],
};

const SIDE = ["Этот компьютер", "Документы", "Загрузки", "Изображения", "Музыка", "Видео", "Диск C:", "Диск D:"];

export function ExplorerApp() {
  const [path, setPath] = useState<string[]>(["Этот компьютер"]);
  const cur = path[path.length - 1];
  const items = TREE[cur] ?? [];

  const crumbs = useMemo(() => path, [path]);

  return (
    <div className="finder">
      <div className="side-nav">
        {SIDE.map((n) => (
          <button key={n} type="button" className={cur === n ? "active" : ""} onClick={() => setPath([n])}>
            {n}
          </button>
        ))}
      </div>
      <div style={{ display: "flex", flexDirection: "column", minWidth: 0 }}>
        <div style={{ display: "flex", gap: 8, alignItems: "center", padding: "8px 12px", borderBottom: "1px solid var(--border)" }}>
          <button type="button" className="os-btn" disabled={path.length < 2} onClick={() => setPath(path.slice(0, -1))}>
            ←
          </button>
          <div className="muted" style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
            {crumbs.map((c, i) => (
              <button
                key={c + i}
                type="button"
                className="os-btn"
                style={{ height: 26, padding: "0 8px" }}
                onClick={() => setPath(path.slice(0, i + 1))}
              >
                {c}
              </button>
            ))}
          </div>
        </div>
        <div className="file-grid scroll">
          {items.map((it) => (
            <button
              key={it.name}
              type="button"
              className="file-cell"
              onDoubleClick={() => {
                if (it.kind === "folder") setPath([...path, it.name]);
              }}
              onClick={() => {
                if (it.kind === "folder") setPath([...path, it.name]);
              }}
            >
              <span style={{ fontSize: 28 }}>{it.icon}</span>
              <span>{it.name}</span>
              {it.size && <span className="subtle">{it.size}</span>}
            </button>
          ))}
          {items.length === 0 && <div className="muted">Папка пуста</div>}
        </div>
      </div>
    </div>
  );
}
