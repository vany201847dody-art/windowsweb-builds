import type { ComponentType } from "react";
import type { AppId } from "../config";
import { AboutApp } from "./About";
import { BankApp } from "./Bank";
import { BrowserApp } from "./Browser";
import { CalculatorApp } from "./Calculator";
import { CameraApp } from "./Camera";
import { ClockApp } from "./Clock";
import { ExplorerApp } from "./Explorer";
import { Game2048, MemoryGame, Minesweeper, SnakeGame, TicTacToe } from "./Games";
import { MusicApp, PhotosApp, WeatherApp } from "./Media";
import { NotepadApp } from "./Notepad";
import { NotesApp } from "./Notes";
import { PaintApp } from "./Paint";
import { SettingsApp } from "./Settings";
import { StoreApp } from "./Store";
import { TaskManagerApp } from "./TaskManager";
import { TerminalApp } from "./Terminal";
import { ColorApp, ConverterApp, PasswordApp, QRApp, RecorderApp } from "./Tools";

const MAP: Record<AppId, ComponentType<{ winId?: string }>> = {
  explorer: ExplorerApp,
  bank: BankApp,
  store: StoreApp,
  browser: BrowserApp,
  camera: CameraApp,
  clock: ClockApp,
  qr: QRApp,
  recorder: RecorderApp,
  notepad: NotepadApp,
  calculator: CalculatorApp,
  paint: PaintApp,
  music: MusicApp,
  photos: PhotosApp,
  terminal: TerminalApp,
  settings: SettingsApp,
  weather: WeatherApp,
  about: AboutApp,
  notes: NotesApp,
  taskmgr: TaskManagerApp,
  minesweeper: Minesweeper,
  snake: SnakeGame,
  game2048: Game2048,
  memory: MemoryGame,
  tictactoe: TicTacToe,
  converter: ConverterApp,
  passwords: PasswordApp,
  colors: ColorApp,
};

export function AppHost({ appId, winId }: { appId: AppId; winId: string }) {
  const C = MAP[appId];
  return C ? <C winId={winId} /> : null;
}
