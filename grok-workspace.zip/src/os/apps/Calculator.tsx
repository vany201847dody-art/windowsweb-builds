import { useState } from "react";

function tokenize(src: string): (number | string)[] {
  const out: (number | string)[] = [];
  let i = 0;
  while (i < src.length) {
    const c = src[i];
    if (c === " ") {
      i++;
      continue;
    }
    if ("+-×÷*/%()".includes(c)) {
      const op = c === "*" ? "×" : c === "/" ? "÷" : c;
      out.push(op);
      i++;
      continue;
    }
    if (c === "." || (c >= "0" && c <= "9")) {
      let s = "";
      while (i < src.length && ((src[i] >= "0" && src[i] <= "9") || src[i] === ".")) s += src[i++];
      out.push(Number(s));
      continue;
    }
    throw new Error("bad");
  }
  return out;
}

function parse(tokens: (number | string)[]): number {
  let i = 0;
  const peek = () => tokens[i];
  const eat = () => tokens[i++];
  const primary = (): number => {
    const t = eat();
    if (typeof t === "number") return t;
    if (t === "(") {
      const v = expr();
      eat();
      return v;
    }
    if (t === "−" || t === "-") return -primary();
    if (t === "+") return primary();
    throw new Error("bad");
  };
  const unary = (): number => {
    const t = peek();
    if (t === "−" || t === "-" || t === "+") {
      eat();
      return t === "+" ? unary() : -unary();
    }
    return primary();
  };
  const term = (): number => {
    let v = unary();
    while (peek() === "×" || peek() === "÷" || peek() === "%") {
      const op = eat();
      const r = unary();
      if (op === "×") v *= r;
      else if (op === "%") v = (v * r) / 100;
      else {
        if (r === 0) throw new Error("div0");
        v /= r;
      }
    }
    return v;
  };
  const expr = (): number => {
    let v = term();
    while (peek() === "+" || peek() === "−" || peek() === "-") {
      const op = eat();
      const r = term();
      v = op === "+" ? v + r : v - r;
    }
    return v;
  };
  const v = expr();
  return v;
}

function evalExpr(s: string) {
  const t = tokenize(s.replace(/,/g, "."));
  return parse(t);
}

export function CalculatorApp() {
  const [expr, setExpr] = useState("");
  const [prev, setPrev] = useState("");
  const [mem, setMem] = useState<number | null>(null);

  const push = (k: string) => {
    if (k === "C") {
      setExpr("");
      setPrev("");
      return;
    }
    if (k === "←") {
      setExpr((e) => e.slice(0, -1));
      return;
    }
    if (k === "±") {
      setExpr((e) => (e.startsWith("−") ? e.slice(1) : "−" + e));
      return;
    }
    if (k === "=") {
      try {
        const v = evalExpr(expr || "0");
        setPrev(expr + " =");
        setExpr(String(+v.toPrecision(12)));
        setMem(v);
      } catch {
        setPrev("Ошибка");
      }
      return;
    }
    setExpr((e) => e + k);
  };

  const keys = ["C", "±", "%", "÷", "7", "8", "9", "×", "4", "5", "6", "−", "1", "2", "3", "+", "0", ".", "←", "="];

  return (
    <div className="app-pad" style={{ display: "flex", flexDirection: "column", gap: 12 }}>
      <div className="card" style={{ textAlign: "right", minHeight: 76 }}>
        <div className="muted" style={{ fontSize: 12, minHeight: 16 }}>
          {prev || (mem != null ? `Ans = ${mem}` : " ")}
        </div>
        <div style={{ fontSize: 28, fontVariantNumeric: "tabular-nums", wordBreak: "break-all" }}>{expr || "0"}</div>
      </div>
      <div className="calc-grid">
        {keys.map((k) => (
          <button
            key={k}
            type="button"
            className={`calc-key ${k === "=" ? "eq" : "÷×−+%".includes(k) ? "op" : ""}`}
            onClick={() => push(k)}
          >
            {k}
          </button>
        ))}
      </div>
    </div>
  );
}
