import { useState } from "react";
import { ACCENTS, APPS, OS, WALLPAPERS } from "../config";
import { OsLogo } from "../Logo";
import { defaultSettings, useOS } from "../store";
import { saveJson } from "@/lib/utils";

const SECTIONS = [
  "Система",
  "Персонализация",
  "Приложения",
  "Время и язык",
  "Сеть",
  "Звук",
  "Уведомления",
  "Конфиденциальность",
  "Обновление",
  "Мышь",
  "Память",
  "Данные",
  "О системе",
];

export function SettingsApp() {
  const [sec, setSec] = useState("Система");
  const s = useOS((s) => s.settings);
  const patch = useOS((s) => s.patchSettings);
  const setPhase = useOS((s) => s.setPhase);
  const notify = useOS((s) => s.notify);
  const windows = useOS((s) => s.windows);

  return (
    <div style={{ display: "flex", height: "100%" }}>
      <div className="side-nav">
        {SECTIONS.map((n) => (
          <button key={n} type="button" className={sec === n ? "active" : ""} onClick={() => setSec(n)}>
            {n}
          </button>
        ))}
      </div>
      <div className="scroll app-pad" style={{ flex: 1 }}>
        {sec === "Система" && (
          <div>
            <h3 style={{ marginTop: 0 }}>{s.pcName}</h3>
            <Row k="ОС" v={`${OS.name} ${OS.version}`} />
            <Row k="Сборка" v={OS.build} />
            <input className="os-input" style={{ width: "100%", margin: "10px 0" }} value={s.pcName} onChange={(e) => patch({ pcName: e.target.value })} />
            <button type="button" className="os-btn" onClick={() => setPhase("restart")}>
              Перезагрузка
            </button>
          </div>
        )}
        {sec === "Персонализация" && (
          <div>
            <div className="muted">Тема</div>
            <div style={{ display: "flex", gap: 8, margin: "8px 0 14px" }}>
              <button type="button" className={`os-btn ${s.theme === "dark" ? "primary" : ""}`} onClick={() => patch({ theme: "dark" })}>
                Тёмная
              </button>
              <button type="button" className={`os-btn ${s.theme === "light" ? "primary" : ""}`} onClick={() => patch({ theme: "light" })}>
                Светлая
              </button>
            </div>
            <div className="muted">Обои</div>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 8, margin: "8px 0 14px" }}>
              {WALLPAPERS.map((w) => (
                <button
                  key={w.id}
                  type="button"
                  onClick={() => patch({ wallpaper: w.url })}
                  title={w.name}
                  style={{
                    aspectRatio: "16/10",
                    borderRadius: 8,
                    border: s.wallpaper === w.url ? "2px solid var(--accent)" : "1px solid var(--border)",
                    background: `url(${w.url}) center/cover`,
                  }}
                />
              ))}
            </div>
            <div className="muted">Акцент</div>
            <div style={{ display: "flex", gap: 8, flexWrap: "wrap", margin: "8px 0 14px" }}>
              {ACCENTS.map((c) => (
                <button
                  key={c}
                  type="button"
                  onClick={() => patch({ accent: c })}
                  style={{
                    width: 28,
                    height: 28,
                    borderRadius: 99,
                    background: c,
                    border: s.accent === c ? "2px solid #fff" : "2px solid transparent",
                    boxShadow: s.accent === c ? "0 0 0 2px var(--fg)" : undefined,
                  }}
                />
              ))}
            </div>
            <div className="muted">Иконки</div>
            <div style={{ display: "flex", gap: 8, margin: "8px 0" }}>
              {(["sm", "md", "lg"] as const).map((x) => (
                <button key={x} type="button" className={`os-btn ${s.iconSize === x ? "primary" : ""}`} onClick={() => patch({ iconSize: x })}>
                  {x === "sm" ? "Мелкие" : x === "md" ? "Средние" : "Крупные"}
                </button>
              ))}
            </div>
            <label style={{ display: "flex", gap: 8, alignItems: "center", marginTop: 12 }}>
              <input type="checkbox" checked={s.animations} onChange={(e) => patch({ animations: e.target.checked })} />
              Анимации
            </label>
          </div>
        )}
        {sec === "Приложения" && (
          <div>
            {APPS.map((a) => (
              <div key={a.id} className="card" style={{ marginBottom: 6, display: "flex", justifyContent: "space-between" }}>
                <span>
                  {a.icon} {a.name}
                </span>
                <span className="muted">{a.size}</span>
              </div>
            ))}
          </div>
        )}
        {sec === "Время и язык" && (
          <div>
            <label style={{ display: "flex", gap: 8, marginBottom: 10 }}>
              <input type="checkbox" checked={s.clock24} onChange={(e) => patch({ clock24: e.target.checked })} />
              24-часовой формат
            </label>
            <label style={{ display: "flex", gap: 8 }}>
              <input type="checkbox" checked={s.showSeconds} onChange={(e) => patch({ showSeconds: e.target.checked })} />
              Показывать секунды
            </label>
            <p className="muted">Язык интерфейса: русский</p>
          </div>
        )}
        {sec === "Сеть" && (
          <div>
            <Toggle label="Wi-Fi" on={s.wifi} onChange={(v) => patch({ wifi: v, airplane: v ? false : s.airplane })} />
            <Toggle label="Bluetooth" on={s.bluetooth} onChange={(v) => patch({ bluetooth: v })} />
            <Toggle label="Авиарежим" on={s.airplane} onChange={(v) => patch({ airplane: v, wifi: v ? false : s.wifi })} />
            <div className="card" style={{ marginTop: 10 }}>
              Aether-5G · {s.wifi ? "подключено" : "отключено"}
            </div>
          </div>
        )}
        {sec === "Звук" && (
          <div>
            <div className="muted">Громкость {s.volume}%</div>
            <input className="os-range" type="range" min={0} max={100} value={s.volume} onChange={(e) => patch({ volume: Number(e.target.value) })} />
          </div>
        )}
        {sec === "Уведомления" && (
          <Toggle label="Показывать баннеры" on={s.banners} onChange={(v) => patch({ banners: v })} />
        )}
        {sec === "Конфиденциальность" && (
          <div>
            <Toggle label="Камера" on={s.cameraAllowed} onChange={(v) => patch({ cameraAllowed: v })} />
            <Toggle label="Микрофон" on={s.micAllowed} onChange={(v) => patch({ micAllowed: v })} />
          </div>
        )}
        {sec === "Обновление" && (
          <div>
            <p>AetherOS в актуальном состоянии · {OS.build}</p>
            <button
              type="button"
              className="os-btn primary"
              onClick={() => {
                notify({ icon: "⬇️", title: "Центр обновления", body: "Новых обновлений нет" });
              }}
            >
              Проверить наличие обновлений
            </button>
          </div>
        )}
        {sec === "Мышь" && (
          <div>
            <div className="muted">Скорость {s.mouseSpeed}</div>
            <input className="os-range" type="range" min={1} max={20} value={s.mouseSpeed} onChange={(e) => patch({ mouseSpeed: Number(e.target.value) })} />
          </div>
        )}
        {sec === "Память" && (
          <div>
            <Bar label="Диск C:" used={42} total={128} />
            <Bar label="Диск D:" used={180} total={512} />
            <p className="muted">Открыто окон: {windows.length}</p>
            <button
              type="button"
              className="os-btn"
              onClick={() => notify({ icon: "🧹", title: "Память", body: "Временные файлы очищены (симуляция)" })}
            >
              Очистка
            </button>
          </div>
        )}
        {sec === "Данные" && (
          <div>
            <button
              type="button"
              className="os-btn"
              onClick={() => {
                const blob = new Blob([JSON.stringify({ settings: s }, null, 2)], { type: "application/json" });
                const a = document.createElement("a");
                a.href = URL.createObjectURL(blob);
                a.download = "aetheros-backup.json";
                a.click();
              }}
            >
              Экспорт JSON
            </button>
            <label className="os-btn" style={{ display: "inline-grid", placeItems: "center", marginLeft: 8 }}>
              Импорт JSON
              <input
                type="file"
                accept="application/json"
                hidden
                onChange={(e) => {
                  const f = e.target.files?.[0];
                  if (!f) return;
                  f.text().then((t) => {
                    try {
                      const data = JSON.parse(t);
                      if (data.settings) patch(data.settings);
                      notify({ icon: "⚙️", title: "Данные", body: "Импорт выполнен" });
                    } catch {
                      notify({ icon: "⚙️", title: "Данные", body: "Файл повреждён" });
                    }
                  });
                }}
              />
            </label>
            <button
              type="button"
              className="os-btn danger"
              style={{ marginLeft: 8 }}
              onClick={() => {
                Object.keys(localStorage)
                  .filter((k) => k.startsWith(OS.storageKey))
                  .forEach((k) => localStorage.removeItem(k));
                patch(defaultSettings());
                saveJson(`${OS.storageKey}_settings`, defaultSettings());
                notify({ icon: "⚠️", title: "Сброс", body: "Настройки сброшены" });
              }}
            >
              Сброс
            </button>
          </div>
        )}
        {sec === "О системе" && (
          <div style={{ textAlign: "center" }}>
            <OsLogo size={56} glow />
            <h3>{OS.name}</h3>
            <p className="muted">
              {OS.version} ({OS.build}) · © {OS.year} {OS.author}
            </p>
            <p>PROPRIETARY · All Rights Reserved</p>
          </div>
        )}
      </div>
    </div>
  );
}

function Row({ k, v }: { k: string; v: string }) {
  return (
    <div style={{ display: "flex", justifyContent: "space-between", padding: "8px 0", borderBottom: "1px solid var(--border)" }}>
      <span className="muted">{k}</span>
      <span>{v}</span>
    </div>
  );
}

function Toggle({ label, on, onChange }: { label: string; on: boolean; onChange: (v: boolean) => void }) {
  return (
    <label style={{ display: "flex", justifyContent: "space-between", padding: "10px 0", borderBottom: "1px solid var(--border)" }}>
      {label}
      <input type="checkbox" checked={on} onChange={(e) => onChange(e.target.checked)} />
    </label>
  );
}

function Bar({ label, used, total }: { label: string; used: number; total: number }) {
  const p = Math.round((used / total) * 100);
  return (
    <div className="card" style={{ marginBottom: 8 }}>
      <div style={{ display: "flex", justifyContent: "space-between" }}>
        <span>{label}</span>
        <span className="muted">
          {used} / {total} ГБ
        </span>
      </div>
      <div style={{ height: 8, background: "var(--hover)", borderRadius: 99, marginTop: 8 }}>
        <div style={{ width: `${p}%`, height: "100%", background: "var(--accent)", borderRadius: 99 }} />
      </div>
    </div>
  );
}
