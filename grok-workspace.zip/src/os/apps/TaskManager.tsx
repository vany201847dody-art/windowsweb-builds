import { useState } from "react";
import { useOS } from "../store";

export function TaskManagerApp() {
  const windows = useOS((s) => s.windows);
  const closeWin = useOS((s) => s.closeWin);
  const [, bump] = useState(0);
  return (
    <div className="app-pad">
      <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 10 }}>
        <strong>Процессы</strong>
        <button type="button" className="os-btn" onClick={() => bump((n) => n + 1)}>
          Обновить
        </button>
      </div>
      <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 13 }}>
        <thead>
          <tr className="muted" style={{ textAlign: "left" }}>
            <th style={{ padding: 6 }}>Приложение</th>
            <th>ОЗУ</th>
            <th>ЦП</th>
            <th></th>
          </tr>
        </thead>
        <tbody>
          {windows.map((w) => {
            const ram = 80 + (w.z * 13) % 220;
            const cpu = ((w.z * 7) % 18) + (w.minimized ? 0 : 4);
            return (
              <tr key={w.id} style={{ borderTop: "1px solid var(--border)" }}>
                <td style={{ padding: 6 }}>
                  {w.icon} {w.title}
                </td>
                <td>{ram} МБ</td>
                <td>{cpu}%</td>
                <td>
                  <button type="button" className="os-btn danger" onClick={() => closeWin(w.id)}>
                    Завершить
                  </button>
                </td>
              </tr>
            );
          })}
          {windows.length === 0 && (
            <tr>
              <td colSpan={4} className="muted" style={{ padding: 12 }}>
                Нет запущенных приложений
              </td>
            </tr>
          )}
        </tbody>
      </table>
    </div>
  );
}
