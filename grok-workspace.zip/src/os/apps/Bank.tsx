import { useMemo, useState } from "react";
import { OS } from "../config";
import { formatRub, loadJson, saveJson, uid } from "@/lib/utils";
import { useOS } from "../store";

const KEY = `${OS.storageKey}_bank`;

type Card = {
  id: string;
  name: string;
  brand: "Visa" | "Mastercard" | "МИР";
  last4: string;
  balance: number;
  blocked: boolean;
  pin: string;
  limit: number;
  grad: string;
};
type Piggy = { id: string; name: string; balance: number; rate: number };
type Deposit = { id: string; amount: number; months: number; rate: number; start: number };
type Credit = { id: string; amount: number; months: number; rate: number; remaining: number; monthly: number };
type Contact = { id: string; name: string; account: string };
type Auto = { id: string; name: string; amount: number; period: 1 | 7 | 30; last: number; cardId: string };
type Tx = { id: string; type: "in" | "out"; amount: number; desc: string; time: number; cardId: string };
type PayFn = (cardId: string, amount: number, desc: string, type?: "in" | "out") => string | null;

type Bank = {
  user: { name: string; pin: string } | null;
  cards: Card[];
  piggy: Piggy[];
  deposits: Deposit[];
  credits: Credit[];
  contacts: Contact[];
  autos: Auto[];
  txs: Tx[];
  fxLock: number;
};

const GRADS = [
  "linear-gradient(135deg,#1b3a6b,#4f8cff)",
  "linear-gradient(135deg,#3b1d4a,#c084fc)",
  "linear-gradient(135deg,#143d2a,#34d399)",
  "linear-gradient(135deg,#4a2c0a,#f59e0b)",
];

function seed(name: string, pin: string): Bank {
  const a = uid("c");
  const b = uid("c");
  const c = uid("c");
  return {
    user: { name, pin },
    cards: [
      { id: a, name: "Aether Gold", brand: "Visa", last4: "4412", balance: 62000, blocked: false, pin, limit: 150000, grad: GRADS[0] },
      { id: b, name: "Aether Black", brand: "Mastercard", last4: "8821", balance: 28000, blocked: false, pin, limit: 80000, grad: GRADS[1] },
      { id: c, name: "Зарплатная", brand: "МИР", last4: "3055", balance: 10000, blocked: false, pin, limit: 50000, grad: GRADS[2] },
    ],
    piggy: [{ id: uid("p"), name: "Отпуск", balance: 0, rate: 8 }],
    deposits: [],
    credits: [],
    contacts: [
      { id: uid("k"), name: "Анна", account: "40817810000000000012" },
      { id: uid("k"), name: "Максим", account: "40817810000000000077" },
    ],
    autos: [],
    txs: [{ id: uid("t"), type: "in", amount: 100000, desc: "Стартовый баланс", time: Date.now() - 86400000, cardId: a }],
    fxLock: Date.now(),
  };
}

const empty: Bank = { user: null, cards: [], piggy: [], deposits: [], credits: [], contacts: [], autos: [], txs: [], fxLock: 0 };

const TABS = [
  "Главная",
  "Карты",
  "Перевод",
  "Между своими",
  "Копилка",
  "Вклады",
  "Кредиты",
  "Валюта",
  "ЖКХ",
  "Автоплатежи",
  "Контакты",
  "История",
] as const;

const FX: { code: string; name: string; rub: number }[] = [
  { code: "USD", name: "Доллар США", rub: 92.4 },
  { code: "EUR", name: "Евро", rub: 99.1 },
  { code: "CNY", name: "Юань", rub: 12.7 },
  { code: "GBP", name: "Фунт", rub: 118.2 },
  { code: "JPY", name: "Иена", rub: 0.62 },
  { code: "KZT", name: "Тенге", rub: 0.19 },
];

const UTIL = [
  { name: "Электричество", amount: 1850 },
  { name: "Вода", amount: 640 },
  { name: "Газ", amount: 420 },
  { name: "Интернет", amount: 790 },
  { name: "Телефон", amount: 550 },
  { name: "Домофон", amount: 180 },
];

function annuity(P: number, annual: number, n: number) {
  const r = annual / 12 / 100;
  if (r === 0) return P / n;
  return (P * r * Math.pow(1 + r, n)) / (Math.pow(1 + r, n) - 1);
}

export function BankApp() {
  const [bank, setBank] = useState<Bank>(() => loadJson(KEY, empty));
  const [tab, setTab] = useState<(typeof TABS)[number]>("Главная");
  const [name, setName] = useState("");
  const [pin, setPin] = useState("");
  const notify = useOS((s) => s.notify);

  const save = (next: Bank) => {
    setBank(next);
    saveJson(KEY, next);
  };

  const total = bank.cards.reduce((s, c) => s + c.balance, 0);

  const pay: PayFn = (cardId, amount, desc, type = "out") => {
    const card = bank.cards.find((c) => c.id === cardId);
    if (!card || card.blocked) return "Карта недоступна";
    if (type === "out" && card.balance < amount) return "Недостаточно средств";
    const cards = bank.cards.map((c) =>
      c.id === cardId ? { ...c, balance: c.balance + (type === "in" ? amount : -amount) } : c,
    );
    const txs = [{ id: uid("t"), type, amount, desc, time: Date.now(), cardId }, ...bank.txs];
    save({ ...bank, cards, txs });
    return null;
  };

  if (!bank.user) {
    return (
      <div className="app-pad" style={{ display: "grid", placeItems: "center", height: "100%" }}>
        <div className="card" style={{ width: "min(360px,100%)" }}>
          <h2 style={{ marginTop: 0 }}>{OS.bankName}</h2>
          <p className="muted">Вход или регистрация. Стартовый баланс 100 000 ₽</p>
          <input className="os-input" style={{ width: "100%", marginBottom: 8 }} placeholder="Имя" value={name} onChange={(e) => setName(e.target.value)} />
          <input className="os-input" style={{ width: "100%", marginBottom: 12 }} placeholder="PIN · 4 цифры" maxLength={4} value={pin} onChange={(e) => setPin(e.target.value.replace(/\D/g, "").slice(0, 4))} />
          <button
            type="button"
            className="os-btn primary"
            style={{ width: "100%" }}
            onClick={() => {
              if (name.trim().length < 2 || pin.length !== 4) return;
              save(seed(name.trim(), pin));
              notify({ icon: "🏦", title: OS.bankName, body: `Добро пожаловать, ${name.trim()}` });
            }}
          >
            Войти
          </button>
        </div>
      </div>
    );
  }

  return (
    <div style={{ height: "100%", display: "flex", flexDirection: "column" }}>
      <div style={{ padding: "10px 12px 0" }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
          <strong>{OS.bankName}</strong>
          <span className="muted">{bank.user.name}</span>
        </div>
        <div className="tabs" style={{ marginTop: 8 }}>
          {TABS.map((t) => (
            <button key={t} type="button" className={tab === t ? "on" : ""} onClick={() => setTab(t)}>
              {t}
            </button>
          ))}
        </div>
      </div>
      <div className="scroll" style={{ padding: 12, flex: 1 }}>
        {tab === "Главная" && <Home bank={bank} total={total} />}
        {tab === "Карты" && <Cards bank={bank} save={save} />}
        {tab === "Перевод" && <Transfer bank={bank} pay={pay} save={save} />}
        {tab === "Между своими" && <Internal bank={bank} save={save} />}
        {tab === "Копилка" && <PiggyTab bank={bank} save={save} />}
        {tab === "Вклады" && <Deposits bank={bank} save={save} />}
        {tab === "Кредиты" && <Credits bank={bank} save={save} />}
        {tab === "Валюта" && <Fx bank={bank} save={save} />}
        {tab === "ЖКХ" && <Utils bank={bank} pay={pay} />}
        {tab === "Автоплатежи" && <Autos bank={bank} save={save} pay={pay} />}
        {tab === "Контакты" && <Contacts bank={bank} save={save} />}
        {tab === "История" && <History bank={bank} />}
      </div>
    </div>
  );
}

function Home({ bank, total }: { bank: Bank; total: number }) {
  const last = bank.txs.slice(0, 5);
  return (
    <div>
      <div className="muted">Совокупный баланс</div>
      <div style={{ fontSize: 32, fontWeight: 500, marginBottom: 12 }}>{formatRub(total)}</div>
      <div style={{ display: "flex", gap: 10, overflow: "auto", paddingBottom: 8 }}>
        {bank.cards.map((c) => (
          <div key={c.id} className="bank-card" style={{ background: c.grad, minWidth: 240 }}>
            <div style={{ display: "flex", justifyContent: "space-between" }}>
              <span>{c.brand}</span>
              <span>•• {c.last4}</span>
            </div>
            <div>
              <div style={{ opacity: 0.85, fontSize: 12 }}>{c.name}</div>
              <div style={{ fontSize: 22 }}>{formatRub(c.balance)}</div>
            </div>
          </div>
        ))}
      </div>
      <div className="grid-3" style={{ margin: "12px 0" }}>
        <Stat k="Карты" v={String(bank.cards.length)} />
        <Stat k="Вклады" v={String(bank.deposits.length)} />
        <Stat k="Кредиты" v={String(bank.credits.length)} />
      </div>
      <div className="card">
        <div style={{ fontWeight: 600, marginBottom: 8 }}>Курсы валют</div>
        {FX.slice(0, 4).map((f) => (
          <div key={f.code} style={{ display: "flex", justifyContent: "space-between", padding: "4px 0" }}>
            <span>{f.code}</span>
            <span>{f.rub.toFixed(2)} ₽</span>
          </div>
        ))}
      </div>
      <div className="card" style={{ marginTop: 10 }}>
        <div style={{ fontWeight: 600, marginBottom: 8 }}>Последние операции</div>
        {last.length === 0 && <div className="muted">Пусто</div>}
        {last.map((t) => (
          <div key={t.id} style={{ display: "flex", justifyContent: "space-between", padding: "6px 0", borderTop: "1px solid var(--border)" }}>
            <span>{t.desc}</span>
            <span style={{ color: t.type === "in" ? "var(--ok)" : "var(--fg)" }}>
              {t.type === "in" ? "+" : "−"}
              {formatRub(t.amount)}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}

function Stat({ k, v }: { k: string; v: string }) {
  return (
    <div className="card">
      <div className="muted">{k}</div>
      <div style={{ fontSize: 22 }}>{v}</div>
    </div>
  );
}

function Cards({ bank, save }: { bank: Bank; save: (b: Bank) => void }) {
  const [pin, setPin] = useState("");
  return (
    <div>
      {bank.cards.map((c) => (
        <div key={c.id} className="card" style={{ marginBottom: 10 }}>
          <div className="bank-card" style={{ background: c.grad, marginBottom: 10 }}>
            <div>
              {c.brand} · {c.name}
            </div>
            <div>{formatRub(c.balance)}</div>
          </div>
          <div className="muted">
            Лимит {formatRub(c.limit)} {c.blocked ? "· заблокирована" : ""}
          </div>
          <div style={{ display: "flex", gap: 6, marginTop: 8, flexWrap: "wrap" }}>
            <button type="button" className="os-btn" onClick={() => save({ ...bank, cards: bank.cards.map((x) => (x.id === c.id ? { ...x, blocked: !x.blocked } : x)) })}>
              {c.blocked ? "Разблокировать" : "Заблокировать"}
            </button>
            <input
              className="os-input"
              style={{ width: 90 }}
              placeholder="лимит"
              onBlur={(e) => {
                const n = Number(e.target.value);
                if (n > 0) save({ ...bank, cards: bank.cards.map((x) => (x.id === c.id ? { ...x, limit: n } : x)) });
              }}
            />
            <input className="os-input" style={{ width: 80 }} placeholder="PIN" maxLength={4} value={pin} onChange={(e) => setPin(e.target.value.replace(/\D/g, ""))} />
            <button
              type="button"
              className="os-btn"
              onClick={() => {
                if (pin.length === 4) save({ ...bank, cards: bank.cards.map((x) => (x.id === c.id ? { ...x, pin } : x)) });
              }}
            >
              Сменить PIN
            </button>
          </div>
        </div>
      ))}
      <button
        type="button"
        className="os-btn primary"
        onClick={() => {
          const n: Card = {
            id: uid("c"),
            name: "Новая карта",
            brand: "Visa",
            last4: String(Math.floor(1000 + Math.random() * 9000)),
            balance: 0,
            blocked: false,
            pin: bank.user?.pin ?? "0000",
            limit: 40000,
            grad: GRADS[bank.cards.length % GRADS.length],
          };
          save({ ...bank, cards: [...bank.cards, n] });
        }}
      >
        Выпустить карту
      </button>
    </div>
  );
}

function Transfer({ bank, pay, save }: { bank: Bank; pay: PayFn; save: (b: Bank) => void }) {
  const [from, setFrom] = useState(bank.cards[0]?.id);
  const [who, setWho] = useState("");
  const [acc, setAcc] = useState("");
  const [amount, setAmount] = useState("1000");
  const [err, setErr] = useState("");
  return (
    <div className="card">
      <select className="os-select" style={{ width: "100%", marginBottom: 8 }} value={from} onChange={(e) => setFrom(e.target.value)}>
        {bank.cards.map((c) => (
          <option key={c.id} value={c.id}>
            {c.name} · {formatRub(c.balance)}
          </option>
        ))}
      </select>
      <input className="os-input" style={{ width: "100%", marginBottom: 8 }} placeholder="Имя получателя" value={who} onChange={(e) => setWho(e.target.value)} />
      <input className="os-input" style={{ width: "100%", marginBottom: 8 }} placeholder="Счёт" value={acc} onChange={(e) => setAcc(e.target.value)} />
      <input className="os-input" style={{ width: "100%", marginBottom: 8 }} value={amount} onChange={(e) => setAmount(e.target.value)} />
      {err && <div style={{ color: "var(--danger)", marginBottom: 8 }}>{err}</div>}
      <button
        type="button"
        className="os-btn primary"
        onClick={() => {
          const n = Number(amount);
          const e = pay(from, n, `Перевод ${who || acc || "получателю"}`);
          setErr(e ?? "");
          if (!e && who) {
            const latest = loadJson<Bank>(KEY, bank);
            save({
              ...latest,
              contacts: latest.contacts.some((c) => c.name === who)
                ? latest.contacts
                : [...latest.contacts, { id: uid("k"), name: who, account: acc || "—" }],
            });
          }
        }}
      >
        Отправить
      </button>
      <div className="muted" style={{ margin: "12px 0 6px" }}>
        Быстрый перевод
      </div>
      {bank.contacts.map((c) => (
        <button
          key={c.id}
          type="button"
          className="os-btn"
          style={{ marginRight: 6, marginBottom: 6 }}
          onClick={() => {
            setWho(c.name);
            setAcc(c.account);
          }}
        >
          {c.name}
        </button>
      ))}
    </div>
  );
}

function Internal({ bank, save }: { bank: Bank; save: (b: Bank) => void }) {
  const [from, setFrom] = useState(bank.cards[0]?.id);
  const [to, setTo] = useState(bank.cards[1]?.id ?? bank.piggy[0]?.id);
  const [amount, setAmount] = useState("500");
  const [err, setErr] = useState("");
  return (
    <div className="card">
      <div className="muted">Откуда</div>
      <select className="os-select" style={{ width: "100%", margin: "6px 0 10px" }} value={from} onChange={(e) => setFrom(e.target.value)}>
        {bank.cards.map((c) => (
          <option key={c.id} value={c.id}>
            {c.name}
          </option>
        ))}
      </select>
      <div className="muted">Куда</div>
      <select className="os-select" style={{ width: "100%", margin: "6px 0 10px" }} value={to} onChange={(e) => setTo(e.target.value)}>
        {bank.cards
          .filter((c) => c.id !== from)
          .map((c) => (
            <option key={c.id} value={c.id}>
              {c.name}
            </option>
          ))}
        {bank.piggy.map((p) => (
          <option key={p.id} value={p.id}>
            Копилка: {p.name}
          </option>
        ))}
      </select>
      <input className="os-input" value={amount} onChange={(e) => setAmount(e.target.value)} style={{ width: "100%", marginBottom: 8 }} />
      {err && <div style={{ color: "var(--danger)" }}>{err}</div>}
      <button
        type="button"
        className="os-btn primary"
        onClick={() => {
          const n = Number(amount);
          const src = bank.cards.find((c) => c.id === from);
          if (!src || src.blocked || src.balance < n) {
            setErr("Недостаточно средств");
            return;
          }
          let cards = bank.cards.map((c) => (c.id === from ? { ...c, balance: c.balance - n } : c));
          let piggy = bank.piggy;
          if (bank.cards.some((c) => c.id === to)) cards = cards.map((c) => (c.id === to ? { ...c, balance: c.balance + n } : c));
          else piggy = piggy.map((p) => (p.id === to ? { ...p, balance: p.balance + n } : p));
          save({
            ...bank,
            cards,
            piggy,
            txs: [{ id: uid("t"), type: "out", amount: n, desc: "Перевод между своими", time: Date.now(), cardId: from }, ...bank.txs],
          });
          setErr("");
        }}
      >
        Перевести
      </button>
    </div>
  );
}

function PiggyTab({ bank, save }: { bank: Bank; save: (b: Bank) => void }) {
  const [name, setName] = useState("На цель");
  const [rate, setRate] = useState("7");
  return (
    <div>
      {bank.piggy.map((p) => (
        <div key={p.id} className="card" style={{ marginBottom: 8 }}>
          <div style={{ display: "flex", justifyContent: "space-between" }}>
            <strong>{p.name}</strong>
            <span>{formatRub(p.balance)}</span>
          </div>
          <div className="muted">{p.rate}% годовых</div>
          <div style={{ display: "flex", gap: 6, marginTop: 8 }}>
            <button
              type="button"
              className="os-btn"
              onClick={() => {
                const card = bank.cards[0];
                if (!card || card.balance < 500) return;
                save({
                  ...bank,
                  cards: bank.cards.map((c, i) => (i === 0 ? { ...c, balance: c.balance - 500 } : c)),
                  piggy: bank.piggy.map((x) => (x.id === p.id ? { ...x, balance: x.balance + 500 } : x)),
                  txs: [{ id: uid("t"), type: "out", amount: 500, desc: `Копилка «${p.name}»`, time: Date.now(), cardId: card.id }, ...bank.txs],
                });
              }}
            >
              +500 ₽
            </button>
            <button
              type="button"
              className="os-btn danger"
              onClick={() => {
                const card = bank.cards[0];
                if (!card) return;
                save({
                  ...bank,
                  cards: bank.cards.map((c, i) => (i === 0 ? { ...c, balance: c.balance + p.balance } : c)),
                  piggy: bank.piggy.filter((x) => x.id !== p.id),
                  txs: [{ id: uid("t"), type: "in", amount: p.balance, desc: `Закрытие копилки «${p.name}»`, time: Date.now(), cardId: card.id }, ...bank.txs],
                });
              }}
            >
              Закрыть
            </button>
          </div>
        </div>
      ))}
      <div className="card">
        <input className="os-input" value={name} onChange={(e) => setName(e.target.value)} style={{ width: "100%", marginBottom: 8 }} />
        <input className="os-input" value={rate} onChange={(e) => setRate(e.target.value)} style={{ width: "100%", marginBottom: 8 }} placeholder="% годовых" />
        <button type="button" className="os-btn primary" onClick={() => save({ ...bank, piggy: [...bank.piggy, { id: uid("p"), name, balance: 0, rate: Number(rate) || 7 }] })}>
          Создать копилку
        </button>
      </div>
    </div>
  );
}

function Deposits({ bank, save }: { bank: Bank; save: (b: Bank) => void }) {
  const offers = [
    { months: 3, rate: 6 },
    { months: 6, rate: 8 },
    { months: 12, rate: 11 },
    { months: 24, rate: 13 },
  ];
  const [amount, setAmount] = useState("10000");
  return (
    <div>
      <div className="grid-2">
        {offers.map((o) => (
          <div key={o.months} className="card">
            <div style={{ fontSize: 22 }}>{o.rate}%</div>
            <div className="muted">{o.months} мес.</div>
            <button
              type="button"
              className="os-btn primary"
              style={{ marginTop: 8 }}
              onClick={() => {
                const n = Number(amount);
                const card = bank.cards[0];
                if (!card || card.balance < n) return;
                save({
                  ...bank,
                  cards: bank.cards.map((c, i) => (i === 0 ? { ...c, balance: c.balance - n } : c)),
                  deposits: [...bank.deposits, { id: uid("d"), amount: n, months: o.months, rate: o.rate, start: Date.now() }],
                  txs: [{ id: uid("t"), type: "out", amount: n, desc: `Вклад ${o.months} мес.`, time: Date.now(), cardId: card.id }, ...bank.txs],
                });
              }}
            >
              Открыть
            </button>
          </div>
        ))}
      </div>
      <input className="os-input" value={amount} onChange={(e) => setAmount(e.target.value)} style={{ width: "100%", margin: "10px 0" }} />
      {bank.deposits.map((d) => {
        const end = new Date(d.start);
        end.setMonth(end.getMonth() + d.months);
        return (
          <div key={d.id} className="card" style={{ marginTop: 8 }}>
            {formatRub(d.amount)} · {d.rate}% · до {end.toLocaleDateString("ru-RU")}
          </div>
        );
      })}
    </div>
  );
}

function Credits({ bank, save }: { bank: Bank; save: (b: Bank) => void }) {
  const [P, setP] = useState("50000");
  const [n, setN] = useState("12");
  const [r, setR] = useState("14");
  const monthly = useMemo(() => annuity(Number(P) || 0, Number(r) || 0, Number(n) || 1), [P, n, r]);
  return (
    <div>
      <div className="card">
        <div className="grid-3">
          <input className="os-input" value={P} onChange={(e) => setP(e.target.value)} />
          <input className="os-input" value={n} onChange={(e) => setN(e.target.value)} />
          <input className="os-input" value={r} onChange={(e) => setR(e.target.value)} />
        </div>
        <div style={{ margin: "10px 0" }}>Платёж: {formatRub(monthly)}</div>
        <button
          type="button"
          className="os-btn primary"
          onClick={() => {
            const amount = Number(P);
            const months = Number(n);
            const rate = Number(r);
            const m = annuity(amount, rate, months);
            const card = bank.cards[0];
            if (!card) return;
            save({
              ...bank,
              cards: bank.cards.map((c, i) => (i === 0 ? { ...c, balance: c.balance + amount } : c)),
              credits: [...bank.credits, { id: uid("cr"), amount, months, rate, remaining: amount, monthly: m }],
              txs: [{ id: uid("t"), type: "in", amount, desc: "Выдача кредита", time: Date.now(), cardId: card.id }, ...bank.txs],
            });
          }}
        >
          Оформить
        </button>
      </div>
      {bank.credits.map((c) => (
        <div key={c.id} className="card" style={{ marginTop: 8 }}>
          Остаток {formatRub(c.remaining)} · {formatRub(c.monthly)} / мес
          <div style={{ marginTop: 8, display: "flex", gap: 6 }}>
            <button
              type="button"
              className="os-btn"
              onClick={() => {
                const card = bank.cards[0];
                const payAmt = Math.min(c.monthly, c.remaining);
                if (!card || card.balance < payAmt) return;
                save({
                  ...bank,
                  cards: bank.cards.map((x, i) => (i === 0 ? { ...x, balance: x.balance - payAmt } : x)),
                  credits: bank.credits
                    .map((x) => (x.id === c.id ? { ...x, remaining: x.remaining - payAmt } : x))
                    .filter((x) => x.remaining > 1),
                  txs: [{ id: uid("t"), type: "out", amount: payAmt, desc: "Платёж по кредиту", time: Date.now(), cardId: card.id }, ...bank.txs],
                });
              }}
            >
              Платёж
            </button>
            <button
              type="button"
              className="os-btn"
              onClick={() => {
                const card = bank.cards[0];
                if (!card || card.balance < c.remaining) return;
                save({
                  ...bank,
                  cards: bank.cards.map((x, i) => (i === 0 ? { ...x, balance: x.balance - c.remaining } : x)),
                  credits: bank.credits.filter((x) => x.id !== c.id),
                  txs: [{ id: uid("t"), type: "out", amount: c.remaining, desc: "Досрочное погашение", time: Date.now(), cardId: card.id }, ...bank.txs],
                });
              }}
            >
              Погасить досрочно
            </button>
          </div>
        </div>
      ))}
    </div>
  );
}

function Fx({ bank, save }: { bank: Bank; save: (b: Bank) => void }) {
  const [code, setCode] = useState("USD");
  const [amount, setAmount] = useState("100");
  const rate = FX.find((f) => f.code === code)!.rub;
  const rub = (Number(amount) || 0) * rate;
  return (
    <div className="card">
      {FX.map((f) => (
        <div key={f.code} style={{ display: "flex", justifyContent: "space-between", padding: "4px 0" }}>
          <span>
            {f.code} · {f.name}
          </span>
          <span>{f.rub.toFixed(2)} ₽</span>
        </div>
      ))}
      <div className="grid-2" style={{ marginTop: 12 }}>
        <select className="os-select" value={code} onChange={(e) => setCode(e.target.value)}>
          {FX.map((f) => (
            <option key={f.code}>{f.code}</option>
          ))}
        </select>
        <input className="os-input" value={amount} onChange={(e) => setAmount(e.target.value)} />
      </div>
      <div style={{ margin: "10px 0" }}>= {formatRub(rub)}</div>
      <button
        type="button"
        className="os-btn primary"
        onClick={() => {
          const card = bank.cards[0];
          if (!card || card.balance < rub) return;
          save({
            ...bank,
            cards: bank.cards.map((c, i) => (i === 0 ? { ...c, balance: c.balance - rub } : c)),
            txs: [{ id: uid("t"), type: "out", amount: rub, desc: `Покупка ${amount} ${code}`, time: Date.now(), cardId: card.id }, ...bank.txs],
          });
        }}
      >
        Купить
      </button>
    </div>
  );
}

function Utils({ bank, pay }: { bank: Bank; pay: PayFn }) {
  const from = bank.cards[0]?.id;
  return (
    <div className="grid-2">
      {UTIL.map((u) => (
        <div key={u.name} className="card">
          <div>{u.name}</div>
          <div className="muted">{formatRub(u.amount)}</div>
          <button type="button" className="os-btn primary" style={{ marginTop: 8 }} onClick={() => pay(from, u.amount, `ЖКХ · ${u.name}`)}>
            Оплатить
          </button>
        </div>
      ))}
    </div>
  );
}

function Autos({ bank, save, pay }: { bank: Bank; save: (b: Bank) => void; pay: PayFn }) {
  const [name, setName] = useState("Интернет");
  const [amount, setAmount] = useState("790");
  const [period, setPeriod] = useState<1 | 7 | 30>(30);
  return (
    <div>
      {bank.autos.map((a) => (
        <div key={a.id} className="card" style={{ marginBottom: 8, display: "flex", justifyContent: "space-between" }}>
          <div>
            {a.name} · {formatRub(a.amount)} / {a.period} дн.
          </div>
          <button type="button" className="os-btn" onClick={() => save({ ...bank, autos: bank.autos.filter((x) => x.id !== a.id) })}>
            Удалить
          </button>
        </div>
      ))}
      <div className="card">
        <input className="os-input" value={name} onChange={(e) => setName(e.target.value)} style={{ width: "100%", marginBottom: 8 }} />
        <input className="os-input" value={amount} onChange={(e) => setAmount(e.target.value)} style={{ width: "100%", marginBottom: 8 }} />
        <select className="os-select" value={period} onChange={(e) => setPeriod(Number(e.target.value) as 1 | 7 | 30)} style={{ width: "100%", marginBottom: 8 }}>
          <option value={1}>Каждый день</option>
          <option value={7}>Раз в неделю</option>
          <option value={30}>Раз в месяц</option>
        </select>
        <button
          type="button"
          className="os-btn primary"
          onClick={() => {
            const cardId = bank.cards[0]?.id;
            save({
              ...bank,
              autos: [...bank.autos, { id: uid("a"), name, amount: Number(amount), period, last: Date.now(), cardId }],
            });
            pay(cardId, Number(amount), `Автоплатёж · ${name}`);
          }}
        >
          Создать
        </button>
      </div>
    </div>
  );
}

function Contacts({ bank, save }: { bank: Bank; save: (b: Bank) => void }) {
  const [name, setName] = useState("");
  const [account, setAccount] = useState("");
  return (
    <div>
      {bank.contacts.map((c) => (
        <div key={c.id} className="card" style={{ marginBottom: 8, display: "flex", justifyContent: "space-between" }}>
          <div>
            <div>{c.name}</div>
            <div className="muted">{c.account}</div>
          </div>
          <button type="button" className="os-btn" onClick={() => save({ ...bank, contacts: bank.contacts.filter((x) => x.id !== c.id) })}>
            Удалить
          </button>
        </div>
      ))}
      <div className="card">
        <input className="os-input" placeholder="Имя" value={name} onChange={(e) => setName(e.target.value)} style={{ width: "100%", marginBottom: 8 }} />
        <input className="os-input" placeholder="Счёт" value={account} onChange={(e) => setAccount(e.target.value)} style={{ width: "100%", marginBottom: 8 }} />
        <button type="button" className="os-btn primary" onClick={() => save({ ...bank, contacts: [...bank.contacts, { id: uid("k"), name, account }] })}>
          Добавить
        </button>
      </div>
    </div>
  );
}

function History({ bank }: { bank: Bank }) {
  const [f, setF] = useState<"all" | "in" | "out">("all");
  const list = bank.txs.filter((t) => f === "all" || t.type === f);
  return (
    <div>
      <div style={{ display: "flex", gap: 6, marginBottom: 8 }}>
        {(["all", "in", "out"] as const).map((x) => (
          <button key={x} type="button" className={`os-btn ${f === x ? "primary" : ""}`} onClick={() => setF(x)}>
            {x === "all" ? "Все" : x === "in" ? "Поступления" : "Списания"}
          </button>
        ))}
      </div>
      {list.map((t) => (
        <div key={t.id} className="card" style={{ marginBottom: 6, display: "flex", justifyContent: "space-between" }}>
          <div>
            <div>{t.desc}</div>
            <div className="subtle">{new Date(t.time).toLocaleString("ru-RU")}</div>
          </div>
          <div style={{ color: t.type === "in" ? "var(--ok)" : "var(--fg)" }}>
            {t.type === "in" ? "+" : "−"}
            {formatRub(t.amount)}
          </div>
        </div>
      ))}
    </div>
  );
}
