type Props = { size?: number; glow?: boolean; className?: string };

export function OsLogo({ size = 48, glow = false, className }: Props) {
  const g = Math.max(2, size * 0.08);
  const s = (size - g) / 2;
  return (
    <svg
      width={size}
      height={size}
      viewBox={`0 0 ${size} ${size}`}
      className={className}
      aria-hidden
      style={glow ? { filter: "drop-shadow(0 0 12px color-mix(in srgb, var(--accent) 70%, transparent))" } : undefined}
    >
      <rect x="0" y="0" width={s} height={s} rx={Math.max(2, s * 0.16)} fill="var(--accent)" />
      <rect x={s + g} y="0" width={s} height={s} rx={Math.max(2, s * 0.16)} fill="var(--accent)" />
      <rect x="0" y={s + g} width={s} height={s} rx={Math.max(2, s * 0.16)} fill="var(--accent)" />
      <rect x={s + g} y={s + g} width={s} height={s} rx={Math.max(2, s * 0.16)} fill="var(--accent)" />
    </svg>
  );
}

export function StartGlyph({ size = 18 }: { size?: number }) {
  return <OsLogo size={size} />;
}
