import { APP_MAP, PINNED } from "./config";
import { OsLogo } from "./Logo";
import { useOS } from "./store";
import { dateShort, timeStr } from "@/lib/utils";
import type { AppId } from "./config";

export function Taskbar() {
  const windows = useOS((s) => s.windows);
  const focusedId = useOS((s) => s.focusedId);
  const flyout = useOS((s) => s.flyout);
  const unread = useOS((s) => s.unread);
  const settings = useOS((s) => s.settings);
  const now = useOS((s) => s.now);
  const toggleFlyout = useOS((s) => s.toggleFlyout);
  const openApp = useOS((s) => s.openApp);
  const taskbarClick = useOS((s) => s.taskbarClick);
  const setContextMenu = useOS((s) => s.setContextMenu);

  const running = windows.filter((w) => !PINNED.includes(w.appId as (typeof PINNED)[number]));
  const date = new Date(now);

  const onTaskCtx = (e: React.MouseEvent, winId?: string, appId?: AppId) => {
    e.preventDefault();
    e.stopPropagation();
    const win = winId ? windows.find((w) => w.id === winId) : windows.find((w) => w.appId === appId);
    useOS.getState().setFlyout(null);
    setContextMenu({
      x: e.clientX,
      y: e.clientY,
      payload: win?.id ?? appId,
      items: win
        ? [
            { label: win.minimized ? "Развернуть" : "Свернуть", action: win.minimized ? "restore" : "min" },
            { label: "Развернуть окно", action: "max" },
            { sep: true, label: "" },
            { label: "Закрыть", action: "close", danger: true },
          ]
        : [{ label: "Открыть", action: "open-app" }],
    });
  };

  const volIcon = settings.volume === 0 ? "🔇" : settings.volume < 40 ? "🔉" : "🔊";

  return (
    <div className="taskbar" onContextMenu={(e) => e.preventDefault()}>
      <button
        type="button"
        className="start-btn"
        aria-label="Пуск"
        onClick={() => toggleFlyout("start")}
      >
        <OsLogo size={18} />
      </button>

      <div className="task-center">
        <button type="button" className="search-pill" onClick={() => toggleFlyout("start")}>
          <span>⌕</span>
          <span>Поиск</span>
        </button>
        {PINNED.map((id) => {
          const app = APP_MAP[id];
          const win = windows.find((w) => w.appId === id);
          const focused = win && focusedId === win.id && !win.minimized;
          return (
            <button
              key={id}
              type="button"
              className={`task-btn ${win ? "open" : ""} ${focused ? "focused active" : ""}`}
              title={app.name}
              onClick={() => (win ? taskbarClick(win.id) : openApp(id))}
              onContextMenu={(e) => onTaskCtx(e, win?.id, id)}
            >
              <span>{app.icon}</span>
              {win && <span className="dash" />}
            </button>
          );
        })}
        {running.map((w) => (
          <button
            key={w.id}
            type="button"
            className={`task-btn open ${focusedId === w.id && !w.minimized ? "focused active" : ""}`}
            title={w.title}
            onClick={() => taskbarClick(w.id)}
            onContextMenu={(e) => onTaskCtx(e, w.id, w.appId)}
          >
            <span>{w.icon}</span>
            <span className="dash" />
          </button>
        ))}
      </div>

      <div className="tray">
        <button
          type="button"
          className="tray-btn"
          title="Громкость"
          onClick={() => toggleFlyout("volume")}
        >
          {volIcon}
        </button>
        <button
          type="button"
          className="tray-btn"
          title="Сеть"
          onClick={() => toggleFlyout("wifi")}
        >
          {settings.airplane ? "✈" : settings.wifi ? "📶" : "⛔"}
        </button>
        <button
          type="button"
          className="tray-btn"
          title="Батарея"
          onClick={() => toggleFlyout("battery")}
        >
          🔋
        </button>
        <button
          type="button"
          className={`tray-btn ${flyout === "calendar" ? "active" : ""}`}
          onClick={() => toggleFlyout("calendar")}
        >
          <div className="tray-clock">
            <div>{timeStr(date, settings.clock24, settings.showSeconds)}</div>
            <div className="d">{dateShort(date)}</div>
          </div>
        </button>
        <button
          type="button"
          className="tray-btn"
          style={{ position: "relative" }}
          title="Уведомления"
          onClick={() => {
            toggleFlyout("notify");
            useOS.setState({ unread: 0 });
          }}
        >
          🔔
          {unread > 0 && <span className="badge">{unread > 9 ? "9+" : unread}</span>}
        </button>
      </div>
    </div>
  );
}
