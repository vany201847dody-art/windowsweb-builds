import type { AppId } from "./config";

export type Phase = "boot" | "lock" | "desktop" | "sleep" | "shutdown" | "restart";

export type Flyout =
  | null
  | "start"
  | "calendar"
  | "volume"
  | "notify"
  | "search"
  | "power"
  | "wifi"
  | "battery";

export type WinState = {
  id: string;
  appId: AppId;
  title: string;
  icon: string;
  x: number;
  y: number;
  w: number;
  h: number;
  z: number;
  minimized: boolean;
  maximized: boolean;
  prev?: { x: number; y: number; w: number; h: number };
};

export type OsNotification = {
  id: string;
  icon: string;
  title: string;
  body: string;
  time: number;
};

export type CtxItem = {
  label: string;
  action?: string;
  danger?: boolean;
  sep?: boolean;
  disabled?: boolean;
};

export type ContextMenuState = {
  x: number;
  y: number;
  items: CtxItem[];
  payload?: string;
} | null;

export type SnapZone = "left" | "right" | "max" | null;

export type Settings = {
  theme: "dark" | "light";
  accent: string;
  wallpaper: string;
  iconSize: "sm" | "md" | "lg";
  animations: boolean;
  volume: number;
  brightness: number;
  clock24: boolean;
  showSeconds: boolean;
  banners: boolean;
  cameraAllowed: boolean;
  micAllowed: boolean;
  wifi: boolean;
  bluetooth: boolean;
  airplane: boolean;
  nightlight: boolean;
  focus: boolean;
  recording: boolean;
  mouseSpeed: number;
  pcName: string;
  desktopPins: AppId[];
  installed: AppId[];
};

export type StoreState = {
  install: "idle" | "downloading" | "installing" | "done";
  progress: number;
};
