export const OS = {
  name: "AetherOS",
  version: "1.0",
  build: "10.0.26026",
  year: 2026,
  author: "Vizor",
  license: "PROPRIETARY",
  bankName: "AetherBank",
  hostname: "AETHER-PC",
  user: "User",
  storageKey: "AetherOS",
} as const;

export const ACCENTS = [
  "#0a84ff",
  "#5e5ce6",
  "#bf5af2",
  "#ff375f",
  "#ff9f0a",
  "#30d158",
  "#64d2ff",
  "#ac8e68",
  "#ffd60a",
  "#ff453a",
] as const;

export const WALLPAPERS = [
  {
    id: "summit",
    name: "Вершины",
    url: "https://images.unsplash.com/photo-1519681393784-d120267933ba?auto=format&fit=crop&w=1920&q=80",
  },
  {
    id: "aurora",
    name: "Сияние",
    url: "https://images.unsplash.com/photo-1531366936337-7c912a4589a7?auto=format&fit=crop&w=1920&q=80",
  },
  {
    id: "lake",
    name: "Озеро",
    url: "https://images.unsplash.com/photo-1501785888041-af3ef285b470?auto=format&fit=crop&w=1920&q=80",
  },
  {
    id: "dusk",
    name: "Закат",
    url: "https://images.unsplash.com/photo-1470071459604-3b5ec3a7fe05?auto=format&fit=crop&w=1920&q=80",
  },
  {
    id: "ocean",
    name: "Океан",
    url: "https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&w=1920&q=80",
  },
  {
    id: "city",
    name: "Ночной город",
    url: "https://images.unsplash.com/photo-1480714378408-67cf0d13bc1b?auto=format&fit=crop&w=1920&q=80",
  },
  {
    id: "forest",
    name: "Лес",
    url: "https://images.unsplash.com/photo-1441974231531-c6227db76b6e?auto=format&fit=crop&w=1920&q=80",
  },
  {
    id: "space",
    name: "Космос",
    url: "https://images.unsplash.com/photo-1462331947965-b7a2cfe63d3d?auto=format&fit=crop&w=1920&q=80",
  },
] as const;

export type AppId =
  | "explorer"
  | "bank"
  | "store"
  | "browser"
  | "camera"
  | "clock"
  | "qr"
  | "recorder"
  | "notepad"
  | "calculator"
  | "paint"
  | "music"
  | "photos"
  | "terminal"
  | "settings"
  | "weather"
  | "about"
  | "notes"
  | "taskmgr"
  | "minesweeper"
  | "snake"
  | "game2048"
  | "memory"
  | "tictactoe"
  | "converter"
  | "passwords"
  | "colors";

export type AppDef = {
  id: AppId;
  name: string;
  icon: string;
  category: "system" | "productivity" | "media" | "games" | "utilities";
  w: number;
  h: number;
  minW: number;
  minH: number;
  desktop: boolean;
  description: string;
  size: string;
};

export const APPS: AppDef[] = [
  { id: "explorer", name: "Этот компьютер", icon: "💻", category: "system", w: 820, h: 540, minW: 520, minH: 360, desktop: true, description: "Файлы и диски", size: "18 МБ" },
  { id: "bank", name: "AetherBank", icon: "🏦", category: "productivity", w: 980, h: 640, minW: 720, minH: 480, desktop: true, description: "Банк и платежи", size: "42 МБ" },
  { id: "store", name: "Магазин приложений", icon: "🛒", category: "system", w: 900, h: 600, minW: 640, minH: 420, desktop: true, description: "Каталог Aether Store", size: "28 МБ" },
  { id: "browser", name: "Браузер", icon: "🌐", category: "system", w: 1020, h: 680, minW: 640, minH: 420, desktop: true, description: "Веб-обозреватель", size: "86 МБ" },
  { id: "camera", name: "Камера", icon: "📷", category: "media", w: 860, h: 560, minW: 560, minH: 400, desktop: true, description: "Фото и видео", size: "31 МБ" },
  { id: "clock", name: "Часы", icon: "🕐", category: "utilities", w: 720, h: 560, minW: 480, minH: 400, desktop: true, description: "Мировое время и таймеры", size: "9 МБ" },
  { id: "qr", name: "QR-код", icon: "📱", category: "utilities", w: 560, h: 620, minW: 420, minH: 480, desktop: true, description: "Генератор QR-кодов", size: "4 МБ" },
  { id: "recorder", name: "Диктофон", icon: "🎤", category: "media", w: 520, h: 560, minW: 380, minH: 420, desktop: true, description: "Запись голоса", size: "12 МБ" },
  { id: "notepad", name: "Блокнот", icon: "📝", category: "productivity", w: 640, h: 480, minW: 420, minH: 280, desktop: true, description: "Простой текстовый редактор", size: "3 МБ" },
  { id: "calculator", name: "Калькулятор", icon: "🧮", category: "utilities", w: 340, h: 500, minW: 300, minH: 440, desktop: true, description: "Инженерные вычисления", size: "2 МБ" },
  { id: "paint", name: "Paint", icon: "🎨", category: "media", w: 860, h: 580, minW: 560, minH: 400, desktop: true, description: "Рисование", size: "15 МБ" },
  { id: "music", name: "Музыка", icon: "🎵", category: "media", w: 420, h: 640, minW: 360, minH: 520, desktop: true, description: "Плеер Aether Music", size: "54 МБ" },
  { id: "photos", name: "Фотографии", icon: "🖼️", category: "media", w: 860, h: 580, minW: 560, minH: 400, desktop: true, description: "Галерея", size: "22 МБ" },
  { id: "terminal", name: "Терминал", icon: "⌨️", category: "system", w: 720, h: 460, minW: 480, minH: 280, desktop: true, description: "Командная строка", size: "6 МБ" },
  { id: "settings", name: "Параметры", icon: "⚙️", category: "system", w: 900, h: 600, minW: 640, minH: 420, desktop: true, description: "Настройки системы", size: "19 МБ" },
  { id: "weather", name: "Погода", icon: "☁️", category: "utilities", w: 640, h: 520, minW: 420, minH: 360, desktop: true, description: "Прогноз по Москве", size: "11 МБ" },
  { id: "about", name: "О системе", icon: "ℹ️", category: "system", w: 520, h: 560, minW: 400, minH: 420, desktop: true, description: "Сведения об AetherOS", size: "1 МБ" },
  { id: "notes", name: "Заметки", icon: "📒", category: "productivity", w: 780, h: 540, minW: 520, minH: 360, desktop: false, description: "Быстрые заметки", size: "8 МБ" },
  { id: "taskmgr", name: "Диспетчер задач", icon: "📊", category: "system", w: 640, h: 460, minW: 480, minH: 320, desktop: false, description: "Процессы и ресурсы", size: "7 МБ" },
  { id: "minesweeper", name: "Сапёр", icon: "💣", category: "games", w: 420, h: 520, minW: 360, minH: 440, desktop: false, description: "Классический сапёр 9×9", size: "5 МБ" },
  { id: "snake", name: "Змейка", icon: "🐍", category: "games", w: 480, h: 560, minW: 400, minH: 480, desktop: false, description: "Соберите яблоки", size: "4 МБ" },
  { id: "game2048", name: "2048", icon: "🔢", category: "games", w: 440, h: 560, minW: 380, minH: 480, desktop: false, description: "Сложите плитки до 2048", size: "3 МБ" },
  { id: "memory", name: "Память", icon: "🧠", category: "games", w: 520, h: 560, minW: 420, minH: 460, desktop: false, description: "Найди пары", size: "4 МБ" },
  { id: "tictactoe", name: "Крестики-нолики", icon: "⭕", category: "games", w: 420, h: 520, minW: 360, minH: 440, desktop: false, description: "Партия против ИИ", size: "3 МБ" },
  { id: "converter", name: "Конвертер", icon: "↔️", category: "utilities", w: 480, h: 420, minW: 360, minH: 320, desktop: false, description: "Единицы измерения", size: "2 МБ" },
  { id: "passwords", name: "Пароли", icon: "🔐", category: "utilities", w: 480, h: 460, minW: 360, minH: 360, desktop: false, description: "Генератор паролей", size: "2 МБ" },
  { id: "colors", name: "Пипетка", icon: "🌈", category: "utilities", w: 420, h: 480, minW: 340, minH: 360, desktop: false, description: "Палитра и HEX", size: "2 МБ" },
];

export const APP_MAP = Object.fromEntries(APPS.map((a) => [a.id, a])) as Record<AppId, AppDef>;

export const PINNED: AppId[] = ["explorer", "browser", "bank", "store", "camera", "settings"];

export const DEFAULT_DESKTOP: AppId[] = APPS.filter((a) => a.desktop).map((a) => a.id);
