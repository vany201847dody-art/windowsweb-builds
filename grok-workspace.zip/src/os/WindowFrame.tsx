import { useEffect, useRef, type PointerEvent as ReactPointerEvent } from "react";
import { APP_MAP } from "./config";
import { useOS } from "./store";
import type { SnapZone, WinState } from "./types";
import { AppHost } from "./apps/AppHost";

const HANDLES = ["n", "s", "e", "w", "ne", "nw", "se", "sw"] as const;

function zoneFromPoint(x: number, y: number): SnapZone {
  if (y < 16) return "max";
  if (x < 16) return "left";
  if (x > window.innerWidth - 16) return "right";
  return null;
}

export function WindowFrame({ win }: { win: WinState }) {
  const ref = useRef<HTMLDivElement>(null);
  const focusedId = useOS((s) => s.focusedId);
  const focusWin = useOS((s) => s.focusWin);
  const closeWin = useOS((s) => s.closeWin);
  const minimizeWin = useOS((s) => s.minimizeWin);
  const toggleMax = useOS((s) => s.toggleMax);
  const moveWin = useOS((s) => s.moveWin);
  const resizeWin = useOS((s) => s.resizeWin);
  const snapWin = useOS((s) => s.snapWin);
  const setSnap = useOS((s) => s.setSnap);
  const setContextMenu = useOS((s) => s.setContextMenu);
  const focused = focusedId === win.id;
  const def = APP_MAP[win.appId];

  useEffect(() => {
    const el = ref.current;
    if (el && focused) {
      const inp = el.querySelector<HTMLElement>("input,textarea,[data-autofocus]");
      if (inp && document.activeElement?.tagName !== "INPUT") {
        /* don't steal typing */
      }
    }
  }, [focused]);

  if (win.minimized) return null;

  const onDrag = (e: ReactPointerEvent) => {
    if (e.button !== 0) return;
    if ((e.target as HTMLElement).closest(".win-btns")) return;
    focusWin(win.id);
    const startX = e.clientX;
    const startY = e.clientY;
    const orig = { x: win.x, y: win.y, w: win.w, h: win.h, max: win.maximized };
    const el = ref.current;
    (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);

    const move = (ev: PointerEvent) => {
      const dx = ev.clientX - startX;
      const dy = ev.clientY - startY;
      if (orig.max && (Math.abs(dx) > 6 || Math.abs(dy) > 6)) {
        const nw = orig.w;
        const nx = clampX(ev.clientX - nw / 2, nw);
        const ny = 0;
        if (el) {
          el.style.left = `${nx}px`;
          el.style.top = `${ny}px`;
          el.style.width = `${nw}px`;
          el.style.height = `${orig.h}px`;
          el.classList.remove("max");
        }
        setSnap(zoneFromPoint(ev.clientX, ev.clientY));
        return;
      }
      const nx = orig.x + dx;
      const ny = orig.y + dy;
      if (el && !orig.max) {
        el.style.left = `${nx}px`;
        el.style.top = `${Math.max(0, ny)}px`;
      }
      setSnap(zoneFromPoint(ev.clientX, ev.clientY));
    };
    const up = (ev: PointerEvent) => {
      (e.currentTarget as HTMLElement).releasePointerCapture(e.pointerId);
      window.removeEventListener("pointermove", move);
      window.removeEventListener("pointerup", up);
      const zone = zoneFromPoint(ev.clientX, ev.clientY);
      if (zone) {
        snapWin(win.id, zone);
        return;
      }
      const dx = ev.clientX - startX;
      const dy = ev.clientY - startY;
      if (orig.max) {
        const nw = orig.w;
        moveWin(win.id, clampX(ev.clientX - nw / 2, nw), 0);
      } else {
        moveWin(win.id, orig.x + dx, Math.max(0, orig.y + dy));
      }
    };
    window.addEventListener("pointermove", move);
    window.addEventListener("pointerup", up);
  };

  const onResize = (dir: (typeof HANDLES)[number]) => (e: ReactPointerEvent) => {
    if (e.button !== 0 || win.maximized) return;
    e.stopPropagation();
    focusWin(win.id);
    const sx = e.clientX;
    const sy = e.clientY;
    const o = { x: win.x, y: win.y, w: win.w, h: win.h };
    const minW = def.minW;
    const minH = def.minH;
    const move = (ev: PointerEvent) => {
      let { x, y, w, h } = o;
      const dx = ev.clientX - sx;
      const dy = ev.clientY - sy;
      if (dir.includes("e")) w = o.w + dx;
      if (dir.includes("s")) h = o.h + dy;
      if (dir.includes("w")) {
        w = o.w - dx;
        x = o.x + dx;
        if (w < minW) {
          x = o.x + o.w - minW;
          w = minW;
        }
      }
      if (dir.includes("n")) {
        h = o.h - dy;
        y = o.y + dy;
        if (h < minH) {
          y = o.y + o.h - minH;
          h = minH;
        }
      }
      w = Math.max(minW, w);
      h = Math.max(minH, h);
      y = Math.max(0, y);
      const el = ref.current;
      if (el) {
        el.style.left = `${x}px`;
        el.style.top = `${y}px`;
        el.style.width = `${w}px`;
        el.style.height = `${h}px`;
      }
    };
    const up = (ev: PointerEvent) => {
      window.removeEventListener("pointermove", move);
      window.removeEventListener("pointerup", up);
      let { x, y, w, h } = o;
      const dx = ev.clientX - sx;
      const dy = ev.clientY - sy;
      if (dir.includes("e")) w = o.w + dx;
      if (dir.includes("s")) h = o.h + dy;
      if (dir.includes("w")) {
        w = Math.max(minW, o.w - dx);
        x = o.x + o.w - w;
      }
      if (dir.includes("n")) {
        h = Math.max(minH, o.h - dy);
        y = o.y + o.h - h;
      }
      resizeWin(win.id, x, Math.max(0, y), Math.max(minW, w), Math.max(minH, h));
    };
    window.addEventListener("pointermove", move);
    window.addEventListener("pointerup", up);
  };

  return (
    <div
      ref={ref}
      className={`win ${focused ? "" : "dim"} ${win.maximized ? "max" : ""}`}
      style={{
        left: win.x,
        top: win.y,
        width: win.w,
        height: win.h,
        zIndex: win.z,
      }}
      onPointerDown={() => {
        if (!focused) focusWin(win.id);
      }}
    >
      <div
        className="titlebar"
        onPointerDown={onDrag}
        onDoubleClick={() => toggleMax(win.id)}
        onContextMenu={(e) => {
          e.preventDefault();
          e.stopPropagation();
          setContextMenu({
            x: e.clientX,
            y: e.clientY,
            payload: win.id,
            items: [
              { label: "Свернуть", action: "min" },
              { label: win.maximized ? "Восстановить" : "Развернуть", action: "max" },
              { sep: true, label: "" },
              { label: "Закрыть", action: "close", danger: true },
            ],
          });
        }}
      >
        <span style={{ fontSize: 14 }}>{win.icon}</span>
        <span className="t">{win.title}</span>
        <div className="win-btns">
          <button type="button" aria-label="Свернуть" onClick={() => minimizeWin(win.id)}>
            —
          </button>
          <button type="button" aria-label="Развернуть" onClick={() => toggleMax(win.id)}>
            {win.maximized ? "❐" : "▢"}
          </button>
          <button type="button" className="x" aria-label="Закрыть" onClick={() => closeWin(win.id)}>
            ✕
          </button>
        </div>
      </div>
      <div className="win-body">
        <AppHost appId={win.appId} winId={win.id} />
      </div>
      {!win.maximized &&
        HANDLES.map((h) => <div key={h} className={`handle ${h}`} onPointerDown={onResize(h)} />)}
    </div>
  );
}

function clampX(x: number, w: number) {
  return Math.max(0, Math.min(window.innerWidth - w, x));
}
