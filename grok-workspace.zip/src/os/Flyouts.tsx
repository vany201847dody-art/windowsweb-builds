import { useMemo, useState } from "react";
import { APPS, OS, type AppId } from "./config";
import { useOS } from "./store";
import { dateLong, dayName, monthNom, timeStr } from "@/lib/utils";

export function Flyouts() {
  const flyout = useOS((s) => s.flyout);
  if (!flyout) return null;
  if (flyout === "start" || flyout === "search") return <StartMenu />;
  if (flyout === "calendar") return <CalendarFlyout />;
  if (flyout === "volume") return <VolumeFlyout />;
  if (flyout === "notify") return <NotifyCenter />;
  if (flyout === "power") return <PowerMenu />;
  if (flyout === "wifi") return <WifiFlyout />;
  if (flyout === "battery") return <BatteryFlyout />;
  return null;
}

function StartMenu() {
  const [q, setQ] = useState("");
  const [power, setPower] = useState(false);
  const openApp = useOS((s) => s.openApp);
  const settings = useOS((s) => s.settings);
  const query = q.trim().toLowerCase();
  const apps = APPS.filter((a) => !query || a.name.toLowerCase().includes(query) || a.id.includes(query));

  return (
    <div className="flyout start-menu" onPointerDown={(e) => e.stopPropagation()}>
      <div style={{ position: "relative" }}>
        <span style={{ position: "absolute", left: 14, top: 10, color: "var(--fg-muted)" }}>⌕</span>
        <input
          className="start-search"
          placeholder="Поиск приложений"
          value={q}
          autoFocus
          onChange={(e) => setQ(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === "Enter" && apps[0]) {
              openApp(apps[0].id);
            }
          }}
        />
      </div>
      <div style={{ margin: "14px 4px 4px", fontWeight: 600, fontSize: 13 }}>Приложения</div>
      <div className="start-grid">
        {apps.map((a) => (
          <button
            key={a.id}
            type="button"
            className="start-app"
            onClick={() => openApp(a.id)}
          >
            <span className="g">{a.icon}</span>
            <span>{a.name}</span>
          </button>
        ))}
        {apps.length === 0 && <div className="muted" style={{ gridColumn: "1 / -1", padding: 20 }}>Ничего не найдено</div>}
      </div>
      <div className="start-footer">
        <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
          <div
            style={{
              width: 32,
              height: 32,
              borderRadius: 99,
              background: "var(--accent)",
              display: "grid",
              placeItems: "center",
              color: "#fff",
              fontWeight: 600,
            }}
          >
            {OS.user[0]}
          </div>
          <div>
            <div style={{ fontSize: 13 }}>{OS.user}</div>
            <div className="subtle" style={{ fontSize: 11 }}>
              {settings.pcName}
            </div>
          </div>
        </div>
        <button type="button" className="os-btn" onClick={() => setPower((v) => !v)} title="Питание">
          ⏻
        </button>
      </div>
      {power && (
        <div
          style={{
            position: "absolute",
            right: 16,
            bottom: 64,
            background: "var(--panel-solid)",
            border: "1px solid var(--border)",
            borderRadius: 10,
            padding: 6,
            minWidth: 200,
            boxShadow: "var(--shadow-md)",
          }}
        >
          <PowerItems />
        </div>
      )}
    </div>
  );
}

function PowerMenu() {
  return (
    <div
      className="flyout"
      style={{ right: 12, bottom: 60, minWidth: 220, padding: 8 }}
      onPointerDown={(e) => e.stopPropagation()}
    >
      <PowerItems />
    </div>
  );
}

function PowerItems() {
  const setPhase = useOS((s) => s.setPhase);
  const setFlyout = useOS((s) => s.setFlyout);
  return (
    <>
      <MenuRow
        label="Спящий режим"
        onClick={() => {
          setFlyout(null);
          setPhase("sleep");
        }}
      />
      <MenuRow
        label="Завершение работы"
        onClick={() => {
          setFlyout(null);
          setPhase("shutdown");
        }}
      />
      <MenuRow
        label="Перезагрузка"
        onClick={() => {
          setFlyout(null);
          setPhase("restart");
        }}
      />
    </>
  );
}

function MenuRow({ label, onClick }: { label: string; onClick: () => void }) {
  return (
    <button type="button" className="os-btn" style={{ width: "100%", textAlign: "left", marginBottom: 4 }} onClick={onClick}>
      {label}
    </button>
  );
}

function CalendarFlyout() {
  const now = useOS((s) => s.now);
  const settings = useOS((s) => s.settings);
  const [cursor, setCursor] = useState(() => new Date());
  const d = new Date(now);
  const cells = useMemo(() => buildMonth(cursor), [cursor]);

  return (
    <div className="flyout" style={{ right: 12, width: 320, padding: 18 }} onPointerDown={(e) => e.stopPropagation()}>
      <div style={{ fontSize: 36, fontWeight: 200, fontVariantNumeric: "tabular-nums" }}>
        {timeStr(d, settings.clock24, true)}
      </div>
      <div className="muted" style={{ marginBottom: 12, textTransform: "capitalize" }}>
        {dateLong(d)}
      </div>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 8 }}>
        <button type="button" className="os-btn" onClick={() => setCursor(addMonth(cursor, -1))}>
          ‹
        </button>
        <div style={{ fontWeight: 600, textTransform: "capitalize" }}>
          {monthNom(cursor)} {cursor.getFullYear()}
        </div>
        <button type="button" className="os-btn" onClick={() => setCursor(addMonth(cursor, 1))}>
          ›
        </button>
      </div>
      <div className="cal-grid muted" style={{ marginBottom: 4, fontSize: 11 }}>
        {["Пн", "Вт", "Ср", "Чт", "Пт", "Сб", "Вс"].map((x) => (
          <div key={x}>{x}</div>
        ))}
      </div>
      <div className="cal-grid">
        {cells.map((c, i) => {
          const today =
            c.date.getDate() === d.getDate() &&
            c.date.getMonth() === d.getMonth() &&
            c.date.getFullYear() === d.getFullYear();
          return (
            <button key={i} type="button" className={`cal-cell ${c.out ? "out" : ""} ${today ? "today" : ""}`}>
              {c.date.getDate()}
            </button>
          );
        })}
      </div>
    </div>
  );
}

function buildMonth(cursor: Date) {
  const y = cursor.getFullYear();
  const m = cursor.getMonth();
  const first = new Date(y, m, 1);
  const start = (first.getDay() + 6) % 7;
  const days: { date: Date; out: boolean }[] = [];
  for (let i = 0; i < 42; i++) {
    const date = new Date(y, m, i - start + 1);
    days.push({ date, out: date.getMonth() !== m });
  }
  return days;
}

function addMonth(d: Date, n: number) {
  return new Date(d.getFullYear(), d.getMonth() + n, 1);
}

function VolumeFlyout() {
  const settings = useOS((s) => s.settings);
  const patch = useOS((s) => s.patchSettings);
  const icon = settings.volume === 0 ? "🔇" : settings.volume < 40 ? "🔉" : "🔊";
  return (
    <div className="flyout" style={{ right: 140, width: 280, padding: 18 }} onPointerDown={(e) => e.stopPropagation()}>
      <div style={{ fontSize: 36, textAlign: "center" }}>{icon}</div>
      <div style={{ display: "flex", alignItems: "center", gap: 10, marginTop: 12 }}>
        <input
          className="os-range"
          type="range"
          min={0}
          max={100}
          value={settings.volume}
          onChange={(e) => patch({ volume: Number(e.target.value) })}
        />
        <span style={{ width: 36, textAlign: "right", fontVariantNumeric: "tabular-nums" }}>{settings.volume}%</span>
      </div>
    </div>
  );
}

function NotifyCenter() {
  const settings = useOS((s) => s.settings);
  const patch = useOS((s) => s.patchSettings);
  const notifications = useOS((s) => s.notifications);
  const clearNotifs = useOS((s) => s.clearNotifs);
  const tiles: { key: keyof typeof settings; label: string; icon: string }[] = [
    { key: "wifi", label: "Wi-Fi", icon: "📶" },
    { key: "bluetooth", label: "Bluetooth", icon: "🔷" },
    { key: "airplane", label: "Авиарежим", icon: "✈" },
    { key: "nightlight", label: "Ночной свет", icon: "🌙" },
    { key: "focus", label: "Фокус", icon: "🎯" },
    { key: "recording", label: "Запись экрана", icon: "⏺" },
  ];

  return (
    <div className="flyout" style={{ right: 8, width: 360, maxWidth: "calc(100vw - 16px)", padding: 14 }} onPointerDown={(e) => e.stopPropagation()}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <strong>Уведомления</strong>
        <button type="button" className="os-btn" onClick={clearNotifs}>
          Очистить
        </button>
      </div>
      <div className="grid-3" style={{ margin: "12px 0" }}>
        {tiles.map((t) => (
          <button
            key={t.key}
            type="button"
            className={`tile ${settings[t.key] ? "on" : ""}`}
            onClick={() => {
              const next = !settings[t.key];
              const extra: Partial<typeof settings> = { [t.key]: next } as Partial<typeof settings>;
              if (t.key === "airplane" && next) extra.wifi = false;
              if (t.key === "airplane" && !next) extra.wifi = true;
              if (t.key === "recording" && next) {
                useOS.getState().notify({ icon: "⏺", title: "Запись экрана", body: "Симуляция записи запущена" });
              }
              patch(extra);
            }}
          >
            <span>{t.icon}</span>
            <span style={{ fontSize: 11 }}>{t.label}</span>
          </button>
        ))}
      </div>
      <div className="muted" style={{ fontSize: 12, marginBottom: 4 }}>
        Звук
      </div>
      <input
        className="os-range"
        type="range"
        min={0}
        max={100}
        value={settings.volume}
        onChange={(e) => patch({ volume: Number(e.target.value) })}
      />
      <div className="muted" style={{ fontSize: 12, margin: "10px 0 4px" }}>
        Яркость
      </div>
      <input
        className="os-range"
        type="range"
        min={20}
        max={100}
        value={settings.brightness}
        onChange={(e) => patch({ brightness: Number(e.target.value) })}
      />
      <div style={{ marginTop: 12, maxHeight: 220, overflow: "auto" }}>
        {notifications.length === 0 && <div className="muted" style={{ padding: 16, textAlign: "center" }}>Нет новых уведомлений</div>}
        {notifications.map((n) => (
          <div key={n.id} className="card" style={{ marginBottom: 8, display: "flex", gap: 8 }}>
            <span>{n.icon}</span>
            <div style={{ minWidth: 0 }}>
              <div style={{ fontWeight: 600 }}>{n.title}</div>
              <div className="muted">{n.body}</div>
              <div className="subtle" style={{ fontSize: 11 }}>
                {new Date(n.time).toLocaleTimeString("ru-RU", { hour: "2-digit", minute: "2-digit" })}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function WifiFlyout() {
  const settings = useOS((s) => s.settings);
  const patch = useOS((s) => s.patchSettings);
  const nets = ["Aether-5G", "Vizor Home", "CoffeeLab", "Aether Guest"];
  return (
    <div className="flyout" style={{ right: 110, width: 280, padding: 14 }} onPointerDown={(e) => e.stopPropagation()}>
      <div style={{ fontWeight: 600, marginBottom: 8 }}>Сеть</div>
      {nets.map((n, i) => (
        <button
          key={n}
          type="button"
          className="os-btn"
          style={{ width: "100%", textAlign: "left", marginBottom: 6, display: "flex", justifyContent: "space-between" }}
          onClick={() => patch({ wifi: true, airplane: false })}
        >
          <span>📶 {n}</span>
          {i === 0 && settings.wifi && <span className="muted">подкл.</span>}
        </button>
      ))}
      <button type="button" className="os-btn" style={{ width: "100%" }} onClick={() => patch({ wifi: !settings.wifi })}>
        {settings.wifi ? "Отключить Wi-Fi" : "Включить Wi-Fi"}
      </button>
    </div>
  );
}

function BatteryFlyout() {
  return (
    <div className="flyout" style={{ right: 90, width: 240, padding: 14 }} onPointerDown={(e) => e.stopPropagation()}>
      <div style={{ fontWeight: 600 }}>Батарея</div>
      <div style={{ fontSize: 28, margin: "8px 0" }}>87%</div>
      <div className="muted">Осталось ≈ 4 ч 20 мин</div>
      <div style={{ height: 8, borderRadius: 99, background: "var(--hover)", marginTop: 10, overflow: "hidden" }}>
        <div style={{ width: "87%", height: "100%", background: "var(--ok)" }} />
      </div>
    </div>
  );
}

export function ContextMenuLayer() {
  const menu = useOS((s) => s.contextMenu);
  const setContextMenu = useOS((s) => s.setContextMenu);
  const openApp = useOS((s) => s.openApp);
  const closeWin = useOS((s) => s.closeWin);
  const minimizeWin = useOS((s) => s.minimizeWin);
  const toggleMax = useOS((s) => s.toggleMax);
  const restoreWin = useOS((s) => s.restoreWin);
  const notify = useOS((s) => s.notify);
  if (!menu) return null;
  const x = Math.min(menu.x, window.innerWidth - 210);
  const y = Math.min(menu.y, window.innerHeight - 48 - menu.items.length * 36);

  const run = (action?: string) => {
    const p = menu.payload ?? "";
    if (action === "open" || action === "open-app") openApp(p as AppId);
    if (action === "props") {
      notify({ icon: "ℹ️", title: "Свойства", body: `Объект: ${p}` });
    }
    if (action === "min") minimizeWin(p);
    if (action === "max") toggleMax(p);
    if (action === "restore") restoreWin(p);
    if (action === "close") closeWin(p);
    if (action === "refresh") notify({ icon: "💻", title: "Рабочий стол", body: "Обновлено" });
    if (action === "personalize") openApp("settings");
    if (action === "new-note") openApp("notepad");
    if (action === "term") openApp("terminal");
    setContextMenu(null);
  };

  return (
    <div className="ctx" style={{ left: x, top: y }} onPointerDown={(e) => e.stopPropagation()}>
      {menu.items.map((it, i) =>
        it.sep ? (
          <div key={i} className="sep" />
        ) : (
          <button
            key={i}
            type="button"
            className={it.danger ? "danger" : ""}
            disabled={it.disabled}
            onClick={() => run(it.action)}
          >
            {it.label}
          </button>
        ),
      )}
    </div>
  );
}

export function Toasts() {
  const toasts = useOS((s) => s.toasts);
  const dismiss = useOS((s) => s.dismissToast);
  return (
    <div className="toast-stack">
      {toasts.map((t) => (
        <button key={t.id} type="button" className="toast" onClick={() => dismiss(t.id)}>
          <span style={{ fontSize: 20 }}>{t.icon}</span>
          <div style={{ textAlign: "left" }}>
            <div style={{ fontWeight: 600 }}>{t.title}</div>
            <div className="muted">{t.body}</div>
          </div>
        </button>
      ))}
    </div>
  );
}

export function SnapPreview() {
  const zone = useOS((s) => s.snap.zone);
  if (!zone) return null;
  const h = window.innerHeight - 48;
  const style =
    zone === "left"
      ? { left: 8, top: 8, width: window.innerWidth / 2 - 12, height: h - 16 }
      : zone === "right"
        ? { left: window.innerWidth / 2 + 4, top: 8, width: window.innerWidth / 2 - 12, height: h - 16 }
        : { left: 8, top: 8, width: window.innerWidth - 16, height: h - 16 };
  return <div className="snap-preview" style={style} />;
}

void dayName;
