import { APP_MAP } from "./config";
import { useOS } from "./store";

export function Desktop() {
  const pins = useOS((s) => s.settings.desktopPins);
  const selected = useOS((s) => s.selectedIcon);
  const selectIcon = useOS((s) => s.selectIcon);
  const openApp = useOS((s) => s.openApp);
  const setContextMenu = useOS((s) => s.setContextMenu);
  const closeOverlays = useOS((s) => s.closeOverlays);
  const size = useOS((s) => s.settings.iconSize);

  return (
    <div
      className="desktop"
      onPointerDown={(e) => {
        if (e.target === e.currentTarget || (e.target as HTMLElement).classList.contains("icon-grid")) {
          selectIcon(null);
          closeOverlays();
        }
      }}
      onContextMenu={(e) => {
        if ((e.target as HTMLElement).closest(".desk-icon")) return;
        e.preventDefault();
        setContextMenu({
          x: e.clientX,
          y: e.clientY,
          items: [
            { label: "Обновить", action: "refresh" },
            { label: "Параметры", action: "personalize" },
            { sep: true, label: "" },
            { label: "Создать заметку", action: "new-note" },
            { label: "Терминал", action: "term" },
          ],
        });
      }}
    >
      <div className="icon-grid">
        {pins.map((id) => {
          const app = APP_MAP[id];
          if (!app) return null;
          return (
            <button
              key={id}
              type="button"
              className={`desk-icon size-${size} ${selected === id ? "selected" : ""}`}
              onClick={(e) => {
                e.stopPropagation();
                selectIcon(id);
              }}
              onDoubleClick={() => openApp(id)}
              onContextMenu={(e) => {
                e.preventDefault();
                e.stopPropagation();
                selectIcon(id);
                setContextMenu({
                  x: e.clientX,
                  y: e.clientY,
                  payload: id,
                  items: [
                    { label: "Открыть", action: "open" },
                    { sep: true, label: "" },
                    { label: "Свойства", action: "props" },
                  ],
                });
              }}
            >
              <span className="glyph">{app.icon}</span>
              <span className="label">{app.name}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
}
